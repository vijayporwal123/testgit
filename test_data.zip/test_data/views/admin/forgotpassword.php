<?php //include('header.php');
$this->load->view('admin/header');
?>
<style>
.error{color:#FF0000;
}
</style>

<body>
<!--<h3 align="center"><img src="<?php echo base_url();?>assets/images/logo_fiscon.png"  style="background-color:#62656a;"></h3>
-->
<hr style="background-color:#3366FF;">
   <div class="container">
        <div class="row">
            <div class="col-md-4 col-md-offset-4">
                <div class="login-panel panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Forgot Password</h3>
                    </div>
                    <div class="panel-body">
                        <form role="form" action="<?php echo base_url(); ?>admin/login/forgot_password_verify" method="post">
                            <fieldset>
                                <div class="form-group">
<input class="form-control " placeholder="EmailId" name="email" type="email" autofocus value="<?php //echo set_value('userName'); ?>"  required>
                                </div>
                               
                               <div class="form-group">
<button type="submit" name="submit" class="btn btn-sm btn-primary ">Submit</button>
<a href="<?php echo base_url(); ?>admin/login"><button type="button" name="cancel" class="btn btn-sm btn-danger ">Cancel</button></a>

</div>
                                
                            </fieldset>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

 
</body>

</html>
