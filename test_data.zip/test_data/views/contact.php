<?php $this->load->view('header');?>

<div class="tp-page-header"><!--tp-page-header-->
  <div class="container">
    <div class="row">
      <div class="col-md-7">
        <div class=""> <!-- page header  -->
        <br>
          <h2>Contact us</h2>
        </div>
        <!--/.page header  --> 
      </div>
      <!--<div class="col-md-5 header-pic">
        <img src="images/page-head-agent.jpg" alt="" class="img-responsive"> </div>-->
      <!--/.page header pic --> 
    </div>
  </div>
</div>

<style>
.error{color:#FF0000;
}
</style>


<!-- /.tp-page-header--> 
<div class="tp-breadcrumb"><!--tp-breadcrumb-->
  <div class="container">
    <div class="row">
      <div class="col-md-8">
        <ol class="breadcrumb">
          <li><a href="<?php echo base_url(); ?>front/index">Home</a></li>
          <li class="active">Contact Us</li>
        </ol>
      </div>
      <div class="col-md-4">

      </div>
    </div>
  </div>
</div><!--/.tp-breadcrumb-->
<div class="main-container" id="main-container"><!--Main container start-->
  <div class="tp-contact" id="tp-contact"><!--tp-contact-->
    <div class="container">
      <div class="row">
        <div class="col-md-12 tp-title"><!--tp-title-->
          <h2>Get in Touch With Us</h2>
          <p>We're just an email away to help, use the email form to send a message.</p>
        </div><!--/.tp-title-->
        
      </div>
      <div class="row">
          <div class="col-md-offset-1 col-md-10 contact-form">
            <form class="form-horizontal" method="post" action="<?php echo base_url();?>front/contactsubmit">
              <p><span class="error">* required field.</span></p>     

              <!-- Text input-->
              <div class="col-md-6">
                <label class="control-label sr-only" for="firstname">First Name<span class="error">* </span></label>
                <input id="firstname" name="firstname" type="text" placeholder="First Name" class="form-control input-md" required value="<?php echo set_value('firstname'); ?>">
                
               <?php echo form_error('firstname'); ?>
 
                
              </div>
              <div class="col-md-6">
                <label class="control-label sr-only" for="lastname">Last Name<span class="error">* </span></label>
                <input id="lastname" name="lastname" type="text" placeholder="Last Name" class="form-control input-md" required value="<?php echo set_value('lastname'); ?>">
                <?php echo form_error('lastname'); ?>

              </div>
              
              <div class="col-md-6">
                <label class="control-label sr-only" for="email">E-Mail<span class="error">* </span></label>
                <input id="email" name="email" type="email" placeholder="E-Mail Address" class="form-control input-md" required value="<?php echo set_value('email'); ?>">
                   <?php echo form_error('email'); ?>
              </div>
              
              <div class="col-md-6">
                <label class="control-label sr-only" for="phone">Mobile Number<span class="error">* </span></label>
                <input id="mobile_no" name="mobile_no" type="text" placeholder="Mobile Number" class="form-control input-md" required value="<?php echo set_value('mobile_no'); ?>">
                
<?php echo form_error('mobile_no'); ?>

              </div>
                            
<div class="col-md-12">
<label class="control-label sr-only" for="message">Message<span class="error">* </span></label>
<textarea class="form-control" id="message" name="message" placeholder="Message"><?php echo set_value('message'); ?></textarea>
<?php echo form_error('message'); ?>
</div>
                           
<div class="col-md-6" style="float:left">
<label class="control-label" for="city">Captcha<span class="error">* </span></label>
<div class="g-recaptcha" data-sitekey="6LcntyUTAAAAAMiyaegXBpvPB4OhAcMFGm4mm9AE"></div>
<?php echo form_error('g-recaptcha-response'); ?>
</div>
      
<div class="col-md-12" style="margin:50px;">
<button type="submit" id="submit" name="submit" class="btn tp-btn tp-btn-orange">Submit</button>
</div>
</form>

</div>
</div>

    </div>
    <div class="support-section section-space" id="support-section"><!--support-section-->
      <div class="container">
        <div class="row">
          <div class="col-md-12 tp-title"><!--tp-title-->
            <h2>Customers Support</h2>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elitauris lacinia nunc urna, ac sollicitudin tortor facilisis sed. In vel tempus ipsum.</p>
          </div><!--/.tp-title-->
        </div>
        <div class="row">
          <div class="col-md-6 support-box"><!--support-box-->
            <div class="grey-box"> <i class="fa fa-map-marker"></i>
              <h3>Headquater Address</h3>
<!--              <p>The Wilson Selly Corporation 550 Helsey wings Rd. Vanfoyld Village, CA 44143</p>
-->   
<p> 207, 2nd Floor
            Capt. C.S. Nayadu Arcade,
            10/2, Old Palasia, 
            Near Greater Kailash Hospital,
            Indore- 452001 ,<br />
            MP.India</p>



         </div>
          </div><!--/.support-box-->
          <div class="col-md-6 support-box"><!-- support-box-->
            <div class="grey-box"> <i class="fa fa-clock-o"></i>
              <h3>Office Hour Timing</h3>
              <p> Monday to Friday  9.00 am  to  6.00 pm <br>
                Saturday  10.00 am  to  4.00 pm</p>
            </div>
          </div><!--/.support-box-->
        </div>
        <div class="row">
          <div class="col-md-12 support-box"><!-- support-box-->
            <div class="grey-box">
              <h1>982  - Fiscon - Claim /(982 - 609 - 8751)</h1>
              <a href="#" class="btn tp-btn tp-btn-orange">Visit A Claim center</a> </div>
          </div><!--/.support-box-->
        </div>
      </div>
    </div><!--/.support-section-->
  </div><!--/.tp-contact-->
</div>
<!-- /.Main container start-->
<?php /*?><div class="tp-newsletter"><!-- Newsletter -->
  <div class="container">
    <div class="row">
      <div class="col-md-5 news-title"><!-- section title -->
        <h2><i class="fa fa-envelope-o"></i> Register to Peace Newsletter</h2>
      </div>
      <div class="col-md-7 newsletter"><!-- Newsletter form -->
        <form method="post" action="newsletter.php">
          <div class="input-group">
            <label class="sr-only control-label" for="newsletter">Newsletter</label>
            <input type="email" id="newsletter" name="newsletter" class="form-control" placeholder="E-mail Address">
            <span class="input-group-btn">
            <button class="btn tp-btn-orange" type="submit">Submit</button>
            </span> </div>
        </form>
        <!-- /input-group --> 
        </div>
      <!-- Newsletter form -->
    </div>
  </div>
</div><?php */?>

<?php  $this->load->view('footer'); ?>
