
        
   <?php
if(!empty($userhistory)){
echo"<pre>";
print_r($userhistory);
   /*$id = $userhistory[0]['id'];
   $username = $executivedata[0]['username'];
   $email = $executivedata[0]['email'];
   $mobile_no = $executivedata[0]['mobile_no'];
  */
  
}
?>     
        
 


<div class="panel-body">
                            <div class="dataTable_wrapper">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                    
                                  <tr>
							          <th>S.No.</th>
								      <th>Previous Summery</th>
                                       <th>Updated By</th>
                                        <th>Updated Date(DD-MM-YY)</th>
							  </tr>
                                        
                                    </thead>
                                    <tbody>
<?php
date_default_timezone_set('Asia/Kolkata');

				if(!empty($userhistory)){
				 $i= 1;
				 foreach($userhistory as $key =>$val){
			  ?>
                    
							<tr>
								<td><?php echo $i++;?></td>
								<td class="center"><?php echo $val['user_history'];?></td>
                               <td class="center"><?php echo $val['admin_name'];?></td>
							  <td class="center"><?php if(!empty($val['create_date'])){
							  }else{
							  
							   echo $val['create_date'];
							  }?></td>
							</tr>
                            
                                    <?php
                                         }
                                      }
									  
                                    ?>                                       
                            </tbody>
                            </table>

                        </div>
                    <!-- /.table-responsive -->
                     </div>


<!--
    <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
                responsive: true
        });
    });
    </script>
-->



</body>
</html>
