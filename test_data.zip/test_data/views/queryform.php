<?php $this->load->view('user_header');
//echo $this->session->userdata('id');?>
<div class="tp-page-header"><!--tp-page-header-->
  <div class="container">
    <div class="row">
      <div class="col-md-7">
        <div class=""> <!-- page header  -->
        <br>
          <h1>Query Form</h1>
        </div>
        <!--/.page header  --> 
      </div>
      
    </div>
  </div>
</div>

<style>
.error{color:#FF0000;
}
</style>


<!-- /.tp-page-header--> 
<div class="tp-breadcrumb"><!--tp-breadcrumb-->
  <div class="container">
    <div class="row">
      <div class="col-md-8">
        <ol class="breadcrumb">
          <li><a href="<?php echo base_url(); ?>login/userinbox">Home</a></li>
          <li class="active">Queryform</li>
        </ol>
        
      </div>
      <div class="col-md-4">
      </div>
    </div>
  </div>
</div><!--/.tp-breadcrumb-->
<div class="main-container" id="main-container"><!--Main container start-->
  <div class="tp-contact" id="tp-contact"><!--tp-contact-->
    <div class="container">
      <div class="row">
        <div class="col-md-12 tp-title"><!--tp-title-->
          <h2>Post Query Form</h2>
          <!--<p>.</p>-->
        </div><!--/.tp-title-->
        
      </div>
      <div class="row">
          <div class="col-md-offset-1 col-md-10 contact-form">
            <form class="form-horizontal" method="post" action="<?php echo base_url();?>login/querysubmit" enctype="multipart/form-data">
              <p><span class="error">* required field.</span></p>     

<input id="" name="user_id" type="hidden"  class="form-control input-md"  value="<?php echo $this->session->userdata('id'); ?>">

           <div class="form-group">
              <div class="col-md-6">
                <label class="control-label" for="firstname">Subject<span class="error">* </span></label>
                <input id="subject" name="subject" type="text" placeholder="subject *" class="form-control input-md" required value="<?php echo set_value('subject'); ?>">
               <?php echo form_error('subject'); ?>
              </div>
              </div>
              
              <div class="form-group">
              <div class="col-md-6">
                <label class="control-label" for="lastname">Attachment</label>
                <input id="attach" name="attach" type="file"  class="form-control input-md" onChange="ValidateSingleInput1(this);" >
                <?php //echo form_error('attach'); ?>
            </div></div>
            
            
           <div class="form-group">               
            <div class="col-md-6">
            <label class="control-label " for="query">Query<span class="error">* </span></label>
            <textarea class="form-control" id="query" name="query" placeholder="Query *"><?php echo set_value('query'); ?></textarea>
            <?php echo form_error('query'); ?>
            </div></div>
            
            
          <div class="form-group">
            <div class="col-md-12" style="margin:10px;">
            <button type="submit" id="submit" name="submit" class="btn btn-small btn-primary">Submit</button>&nbsp;&nbsp;&nbsp;
            <a  href="<?php echo base_url(); ?>login/managequery"><button type="button" class="btn btn-small btn-danger">Back</button></a> 
            </div></div>
            
            </form>
</div>
</div>
</div>    
<!--/.support-section-->
</div><!--/.tp-contact-->
</div>

<script>
	//[".jpg", ".jpeg", ".gif", ".png", ".mp4", ".3gp", ".ogg", ".avi", ".mkv", ".mpeg"]
 var _validFileExtensions1 = [".jpg", ".jpeg", ".gif", ".png", ".doc", ".docx", ".pdf"];    
function ValidateSingleInput1(oInput) {
    if (oInput.type == "file") {
        var sFileName = oInput.value;
         if (sFileName.length > 0) {
            var blnValid = false;
            for (var j = 0; j < _validFileExtensions1.length; j++) {
                var sCurExtension = _validFileExtensions1[j];
                if (sFileName.substr(sFileName.length - sCurExtension.length, sCurExtension.length).toLowerCase() == sCurExtension.toLowerCase()) {
                    blnValid = true;
                    break;
                }
            }
             
            if (!blnValid) {
                alert("Sorry, " + sFileName + " is invalid file extension, allowed file type extensions are only: " + _validFileExtensions1.join(", "));
                oInput.value = "";
                return false;
            }
        }
    }
    return true;
}
 
 
 
 </script>

<!-- /.Main container start-->
<?php /*?><div class="tp-newsletter"><!-- Newsletter -->
  <div class="container">
    <div class="row">
      <div class="col-md-5 news-title"><!-- section title -->
        <h2><i class="fa fa-envelope-o"></i> Register to Peace Newsletter</h2>
      </div>
      <div class="col-md-7 newsletter"><!-- Newsletter form -->
        <form method="post" action="newsletter.php">
          <div class="input-group">
            <label class="sr-only control-label" for="newsletter">Newsletter</label>
            <input type="email" id="newsletter" name="newsletter" class="form-control" placeholder="E-mail Address">
            <span class="input-group-btn">
            <button class="btn tp-btn-orange" type="submit">Submit</button>
            </span> </div>
        </form>
        <!-- /input-group --> 
        </div>
      <!-- Newsletter form -->
    </div>
  </div>
</div><?php */?>

<?php  $this->load->view('user_footer'); ?>
