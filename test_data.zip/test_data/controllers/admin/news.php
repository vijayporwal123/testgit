<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class News extends CI_Controller{

 public function __construct(){
  parent::__construct();
  $this->load->model('admin/adminmodel');
  $this->load->library(array('form_validation','session','email'));
  $this->load->helper(array('url','html','form'));
  //$this->load->library('encrypt');
    $this->load->helper('security');


 }


public function index(){

$where  = "ORDER BY id DESC  ";
$data['show_news'] = $this->adminmodel->select('fis_news',$where);
$this->load->view('admin/newslist',$data);
}

public function addnews(){
$this->load->view('admin/addnews');
}



public function newssubmit(){
		
$this->form_validation->set_rules('title', 'News Title', 'trim|required|xss_clean');
$this->form_validation->set_rules('news', 'News Description', 'trim|required|min_length[5]|xss_clean');
          	   	   
$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
if($this->form_validation->run()==true){

$upload_dir = base_url();
$upload_dir= 'news/';

	$file_name = $_FILES['photo']['name'];
	
	if(!empty($file_name)){
	$temp_name = $_FILES['photo']['tmp_name'];
		
	$ext = @pathinfo($file_name, PATHINFO_EXTENSION);
	$file_name= time().rand(1000,99999).'.'.$ext;
   
	$file_path = $upload_dir.$file_name; 
	@move_uploaded_file($temp_name, $file_path);
	
	}else{
	$file_name = '';
	}



$data = array(
'news' =>$this->input->post('news'),
'title' =>$this->input->post('title'),
'image' =>$file_name,
'create_date'=>date('Y-m-d'),
'status'=>'1'
);
		
$result = $this->adminmodel->data_insert('fis_news',$data);
		
$msg= $this->session->set_flashdata('message', 'Your data inserted Successfully..');	
if($result){
redirect('admin/news/index',$msg);
}
}
		  
else{
//redirect('admin/news/addnews');
$this->load->view('admin/addnews'); 

}	
}

//edit action 
public function editnews(){
   
	   $id =  $this->uri->segment(4) ? $this->uri->segment(4) : 0;
	
	    $news = 'fis_news';
		$where  = "where id = $id  ";
	    $data['newsdata'] = $this->adminmodel->select($news,$where);	

        $this->load->view('admin/editnews',  $data);
	
   
    }


public function updatenews(){

//$id =  $this->uri->segment(4) ? $this->uri->segment(4) : 0;


if($this->input->post()){
	
$this->form_validation->set_rules('news', 'News Description', 'trim|required|min_length[5]|xss_clean'); 
    
$this->form_validation->set_rules('title', 'News Title', 'trim|required|xss_clean');       	
		
$this->form_validation->set_error_delimiters('<div class="error">', '</div>');


if($this->form_validation->run()==true){
	

if($_POST){
$upload_dir1 = base_url();
$upload_dir1= 'news/';

	$file_name1 = $_FILES['photo']['name'];
	
	if(!empty($file_name1)){
	$temp_name1 = $_FILES['photo']['tmp_name'];
		
	$ext1 = @pathinfo($file_name1, PATHINFO_EXTENSION);
	$file_name1= time().rand(1000,99999).'.'.$ext1;
   
	$file_path1 = $upload_dir1.$file_name1; 
	@move_uploaded_file($temp_name1, $file_path1);
	}		
	
	
	
	 $eid = $this->input->post("eid");
	 $news = $this->input->post("news");
	 $title = $this->input->post("title");
	 $status = $this->input->post("status");
	 //$youtube = $this->input->post("youtube");	 	 	 

if(!empty($file_name1)){

	    $data =array('news'=>$news,
					'title'=>$title,
					'image'=>$file_name1,
				     'status' =>$status
				);						
		
		
		}else{
		
		
		 $data =array('news'=>$news,
					'title'=>$title,
				     'status' =>$status
				);		
				
				
		}
		
		
		
		
		//print_r($data); 
	 $news =  'fis_news';
	 $id1 = $this->adminmodel->data_update(array("id"=>$eid),$news,$data);
		//print_r($id1);
    $msg1=$this->session->set_flashdata('message', 'Your data updated Successfully..');

			
		 if($id1){
		    redirect('admin/news/index',$msg1);
			
		}
	
	}
	
	}//validation if end
	else{
	$id =  $this->uri->segment(4) ? $this->uri->segment(4) : 0;
	    $news1 = 'fis_news';
		$where1  = "where id = $id  ";
	    $data['newsdata'] = $this->adminmodel->select($news1,$where1);	
        $this->load->view('admin/editnews',  $data);

	}
	
	}
	else{
	$id =  $this->uri->segment(4) ? $this->uri->segment(4) : 0;
	    $news1 = 'fis_news';
		$where1  = "where id = $id  ";
	    $data['newsdata'] = $this->adminmodel->select($news1,$where1);	
        $this->load->view('admin/editnews',  $data);

	}
	
	
	
}
	



 
public function deletenews($id)
{  
	
$id = $this->uri->segment(4) ? $this->uri->segment(4) : 0;	
$this->db->where('id', $id);
$this->db->delete('fis_news');
$this->session->set_flashdata('message', 'Your data deleted Successfully..');
redirect('admin/news/index');

}

 
 
 

}//last end
?>
