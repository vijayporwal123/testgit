<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
  <style type="text/css">
    .bg-border {
        border: 1px solid #ddd;
        border-radius: 4px 4px;
        padding: 15px 15px;
    }
    </style>
<div class="container">

 <?php if($this->session->flashdata('message')){?>
      <div class="alert alert-success">  
           <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>    
        <?php echo $this->session->flashdata('message')?>
      </div>
    <?php } ?>

<br>

<form class="form-inline" action="<?php echo base_url();?>welcome/search" method="post">
    <div class="form-group">
      <label for="email">Email:</label>
      <input type="text" class="form-control" id="email" placeholder="Enter any keyword" name="email">
    </div>
    <button type="submit" class="btn btn-default">Submit</button>
  </form>

  <br>
  <h2>Basic Table</h2>
  <p>The table: <span style="float: right;"><a href="<?php echo base_url();?>welcome/create_form">Add User</a> </span></p>  

<!-- <p>The table: <span style="float: right;"><a href="<?php echo base_url();?>40/41/42/43/44">Add URL</a> </span></p> 
 -->
<div class="row">
        <div class="col-md-12">
  <table class="table table-striped table-hover">
    <thead>
      <tr>
        <th>#</th>
        <th>email</th>
        <th>password</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
<?php 
$i=1;
foreach($results as $val){?>
      <tr>
        <td><?php echo ($page+$i++); ?></td>
        <td><?php echo $val['email'];?></td>
        <td><?php echo $val['password'];?></td>
         <td><a href="<?php echo base_url();?>welcome/deleteuser/<?php echo $val['id'];?>">Delete User</a>|<a href="<?php echo base_url();?>welcome/edituser/<?php echo $val['id'];?>">Edit User</a>

<!-- <a href="<?php echo base_url();?>edituser/<?php echo $val['id'];?>/<?php echo '3';?>">Edit User</a> -->


         </td>
      </tr>
     <?php } ?>
    </tbody>
  </table>
   </div></div>


<?php //echo $this->pagination->create_links(); ?>  

 <div class="row">
        <div class="col-md-12 text-center">
            <?php echo $pagination; ?>
        </div>
    </div>


<!-- pagination -->

</div>
</body>
</html>
