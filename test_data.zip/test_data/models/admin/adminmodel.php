<?php
class Adminmodel extends CI_Model {

 function __construct(){
  parent::__construct();
 }


 function processLogin($email,$password){
  $this->db->select("*");
  $whereCondition = $array = array('email' =>$email,'password'=>md5($password),'user_type' =>'admin');
  $this->db->where($whereCondition);
  $this->db->from('fis_users');
  $query = $this->db->get();
  return $query;
 }
 
 
 
 
 function result_getall()
  { 
   $this->db->select('*');  
   $this->db->from('fis_blog as b');
   $this->db->join('comment as c', 'b.id = c.post_blog_id', 'INNER');  
   //$this->db->where('c.status',$status);
   $query = $this->db->get();
   return  $query->result_array();
  }

 
 function result_userid($id)
  { 
  
   $this->db->select('*,u.id');  
   $this->db->from('fis_users as u');
   $this->db->join('fis_userinfo as ui', 'u.id = ui.user_id', 'left');  
   $this->db->where('u.id',$id);
   $this->db->order_by("ui.id", "desc");
   $query = $this->db->get();
   return  $query->result_array();
   
  }
  
  
  function result_userfiles($id)
  { 
  
   $this->db->select('*');  
   $this->db->from('fis_users as u');
   $this->db->join('fis_files as uf', 'u.id = uf.user_id', 'inner');  
   $this->db->where('u.id',$id);
   //$this->db->order_by("ui.id", "desc");
   $query = $this->db->get();
   
   return  $query->result_array();
   
  //$query->result_array());die;
   
  } 
  
  
  
 
 
 function update_data($table,$where,$data)
	{
		 $this->db->where($where);
	     $update = $this->db->update($table,$data);
		 if($update){ 
			return TRUE;
		 }
		 else
		 { 
			return FALSE;
		 }
	}
 
 
 
 
 
  function total_comments()
  { 
  $sql = "select count(cid) as totalcomment from  comment ";
  $query = $this->db->query($sql);
   if($query->num_rows() > 0)
    {
      return $query->result_array();
	}else{
	    return false;
	}
  }

 
 
 
 
/* function check_login()
	{
		if($this->session->userdata('id') == TRUE )
		{
			//$this->session->sess_destroy();
			$admin_url = 'http://localhost/codeig/login/admininbox';
			redirect($admin_url);
			exit();
		}else{
		
		$admin_url1 = 'http://localhost/codeig/admin/login';
			redirect($admin_url1);
		}
	}
 */
 
 
 public function getCategoryTreeForParentId($parent_id = 0){
  $categories = array();
  $this->db->from('category');
  $this->db->where('parent_id', $parent_id);
  $result = $this->db->get()->result();
  foreach ($result as $mainCategory){
    $category = array();
    $category['category_id'] = $mainCategory->id;
    $category['catname'] = $mainCategory->name;
    $category['parent_id'] = $mainCategory->parent_id;
    $category['sub_categories'] = $this->getCategoryTreeForParentId($category['id']);
    $categories[$mainCategory->id] = $category;
  }
  return $categories;
}

 
 
 
 
 function getcountry()
     {
        $this -> db ->select('*');
        $query = $this ->db ->get('countries');
        return $query->result();
     }


  function getstate($country_id='')
     {
        $this ->db ->select('*');
        $this ->db ->where('country_id', $country_id);
        $query =$this->db ->get('states');
        return $query->result();
     }
    
	
   function getcity($state_id='')
     {
        $this ->db->select('*');
        $this ->db->where('state_id', $state_id);
        $query = $this ->db->get('cities');
        return $query->result();
     }
 
 
 
 
 public function data_insert($table,$data)
	{		
		   $query = $this->db->insert($table, $data); 
		   $id = $this->db->insert_id();
		   return $id;			
	}
  
  public function data_delete($attribute_name, $attribute_value, $table_name){
		$this->db->where($attribute_name, $attribute_value);
		$this->db->delete($table_name);
		return true;
	}
	
  public function data_update($whereArray, $table, $update_array){
		
		if(is_array($whereArray)){
			foreach ($whereArray as $key => $value){
				$this->db->where($key, $value);
			}
		} 
		$this->db->update($table, $update_array);
		return true;
/*		if($this->db->affected_rows())
			return true;
		else
			return false;	 
*/	}

 public function get_account($USER_ID)
    {
        $this->db->select()->from('TRN_USER');
        $this->db->where('user_id', $USER_ID);

        $query = $this->db->get();

        return $query->result_array();
    }
 
 
 
 function select($table, $where ='')
     {
        $sql = "SELECT * FROM $table";
		if(!empty($where)){
		   $sql .= " $where";
		}
		
		$query = $this->db->query($sql);
        if($query->num_rows()>0)
        {
            return $query->result_array();
        }
        else{
            return false;
        }
    }

}
?>