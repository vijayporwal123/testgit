<?php  $this->load->view('header');?>
<?php
/*echo $id=$this->uri->segment(3) ? $this->uri->segment(3) : 0; 

$sql13="select * from fis_blog where tag='".$id."' ";
$result13=mysql_query($sql13);
$row12=mysql_fetch_array($result13);*/
//echo "<pre>";
//print_r($row12)	;	die; 
?>		  
		 
<div class="tp-page-header"><!-- full page header -->
  <div class="container">
    <div class="row">
      <div class="col-md-3">
        <div class=""> <!-- page header  -->
        <br />
          <h1>Blog Detail</h1>
          
        </div>
        <!-- page header  --> 
      </div>
      
    </div>
  </div>
</div>
<!-- /.full page header-->
<div class="tp-breadcrumb">
  <div class="container">
    <div class="row">
      <div class="col-md-8">
        <ol class="breadcrumb">
          <li><a href="<?php echo base_url(); ?>front/index">Home</a></li>
          <li class="active">Category Blog Detail</li>
        </ol>
      </div>
      <!--<div class="col-md-4">
        <div class="font-option"> Select font size : <a href="#" id="incfont">A+</a><a href="#" id="decfont">A-</a></div>
      </div>-->
    </div>
  </div>
</div>
<div class="main-container" id="main-container"><!--Main container start-->
  <div class="tp-blog-details" id="tp-blog-details"><!-- blog details -->
    <div class="container">
      <div class="row">
        <div class="col-md-8 tp-blog-left">
          <div class="row">
              <?php 
				if(!empty($category_details)){
				 $i= 1;
				 foreach($category_details as $key =>$val){
			  ?> 
              
<div class="col-md-12 tp-blog-post"><!-- blog post start-->
<h1><a href="<?php echo base_url();?>front/blog_details/<?php echo $val['id']; ?>"><?php echo $val['title']; ?></a></h1>
<p class="meta"> <span class="meta-date"><i class="fa fa-calendar"></i><?php echo date('d-M-Y',strtotime($val['post_date'])); ?></span><!--<span class="meta-comments"> <i class="fa fa-comments"></i><a href="#">(20) Comments</a></span>-->  </p>
             
 <?php											
$file_name=$val['photo'];

$tmp = explode('.', $file_name);
$file_extension = end($tmp);

if($file_extension=="mp4" || $file_extension=="3gp" || $file_extension=="ogg" || $file_extension=="avi" || $file_extension=="mpeg" || $file_extension=="mkv")
{
//echo "its an mp4 movie";
?>
<video  controls class="img-responsive">
<source src="<?php echo base_url();?>uploads/<?php echo $val['photo']; ?>" type="video/mp4" alt="" >
</video> 

<?php
}else if($file_extension=="gif" || $file_extension=="jpeg" || $file_extension=="png" || $file_extension=="jpg"){

/*if(strtolower(end(explode(".",$ff))) =="jpg"){*/
?>
<a href="#"><image src="<?php echo base_url();?>uploads/<?php echo $val['photo']; ?>"  alt="" class="img-responsive"></a>
<?php
}else{
?>
<image src="<?php echo base_url();?>uploads/imageNotFound.jpg"  type="image/jpg" alt="" class="img-responsive">
<?php
}
?>                                    
<p><?php echo substr($val['desc'],0,300); ?></p>
<a href="<?php echo base_url();?>front/blog_details/<?php echo $val['id']; ?>" class="btn tp-btn tp-btn-grey">Read More</a>
</div>
<?php
}
}else{
?>
<div>
<p>No Blog Post Found</p>
</div>    
<?php
}
?>                
<!-- /.blog post start--> 
          </div>
          <!--<div class="row">
            <div class="col-md-12 author-block">
              <div class="author-bg">
                <div class="row">
                  <div class="col-md-3 auhtor-thumb"><a href="#"><img src="images/author-pic.jpg" alt="author profile" class="img-responsive"></a></div>
                  <div class="col-md-9 author-dec">
                    <h3><a href="#" class="name-author">Nishant Shah (Author)</a></h3>
                    <p>Lorem Ipsum which looks reasona therefore always free from repetition, injected humour, or non-characteristic words etc.</p>
                    <a href="#" class="btn tp-btn tp-btn-orange">All posts by Mark Mathon</a> </div>
                </div>
              </div>
            </div>
          </div>-->
          <!--<div class="row pre-next-post">
            <div class="col-md-6 blog-prv-link"> <a href="#"><i class="fa fa-long-arrow-left"></i> Previous Post</a>
              <h3><a href="#">Previous Heading title for post</a></h3>
            </div>
            <div class="col-md-6 blog-nxt-link"> <a href="#">Next Post <i class="fa fa-long-arrow-right"></i></a>
              <h3><a href="#">Previous Heading title for post</a></h3>
            </div>
          </div>-->
          
          
        </div>
        <div class="col-md-4 tp-blog-right"><!-- tp blog right -->
          <div class="row">
            <div class="col-md-12">
              <div class="widget search-widget"><!--search widget start-->
              <h2 class="widget-title">Search</h2>
            <form action="<?php echo base_url();?>front/blog_search" method="post">
                <div class="input-group"><!-- search input start -->
                  <input type="text" class="form-control" name="blog_name" placeholder="search blog by blog name or category">
                  <span class="input-group-btn">
                  <button class="btn btn-search" type="submit" name="submit"><i class=" fa fa-search "></i></button>
                  </span> </div></form>
                <!-- search input end -->
              </div>
              <!--search widget end-->
            </div>
            <div class="col-md-12">
<div class="widget categories-widget"><!--Categories widget start-->
<h2 class="widget-title">Categories</h2>
<?php
$sql5="select count(fb.tag) as cattotal,fb.tag from fis_blog fb  group by fb.tag ";
$result5=mysql_query($sql5);
if(mysql_num_rows($result5)>0){
while($row5=mysql_fetch_array($result5)){
?>
                <ul class="angle-double-right">
                  <li><a href="<?php echo base_url(); ?>front/category_details/<?php echo $row5['tag'];?>"><?php echo $row5['tag'];?><span>(<?php echo $row5['cattotal'];?>)</span></a></li>
                 
                </ul>
                <?php
				}
				}else{?>
                <ul>
                <li>No Categories Found</li>
                </ul>
                <?php
				}
				?>
                
              </div>
              <!--Categories widget end--> 
            </div>
            <div class="col-md-12">
              <div class="widget archive-widget"><!--Categories widget start-->
                <h2 class="widget-title">Archive</h2>
<?php
$sql6="SELECT *,YEAR(post_date), MONTH(post_date), COUNT(id) as pid from fis_blog GROUP BY YEAR(post_date), MONTH(post_date) order by YEAR(post_date), MONTH(post_date) asc  ";
$result6=mysql_query($sql6);
if(mysql_num_rows($result6)>0){
while($row6=mysql_fetch_array($result6)){
?>       
                <ul class="angle-double-right">
                  <li><a href="<?php echo base_url(); ?>front/archieve_details/<?php echo $row6['post_date'];?>"><?php echo date('M-Y',strtotime($row6['post_date']));?></a></li>
                </ul>
               <?php
			   }
			   }else{
			   ?> 
              <ul>
                <li>No Archive Found</li>
              </ul>
                <?php
				}
				?>  
                
              </div>
              <!--Categories widget end--> 
            </div>
            <div class="col-md-12">
              <div class="widget recent-post-widget"><!--Recent post widget start-->
                <h2 class="widget-title">Recent post</h2>
<?php
$sql1="select * from fis_blog  order by id desc limit 3 ";
$result1=mysql_query($sql1);
if(mysql_num_rows($result1)>0){
while($row1=mysql_fetch_array($result1)){
?>                               
                
  <ul>
<li>
<h3 class="recent-title"><a href="<?php echo base_url();?>front/blog"><?php echo $row1['title'];?></a></h3>
<span class="meta-date"><i class="fa fa-calendar"></i><?php echo date('d-M-Y',strtotime($row1['post_date'])); ?></span>
</li>

</ul>
<?php
    }
    }else{
?>
<ul>
<li>No Recent post Found</li>
</ul>
<?php
}
?>                
    </div>
<!--Recent post widget end--> 
            </div>
            <div class="col-md-12">
              <div class="widget tags-widget"><!--Tags widget start-->
                <h2 class="widget-title">Tags</h2>
<?php
$sql7="select count(fb.tag) as cattotal,fb.tag from fis_blog fb  group by fb.tag ";
$result7=mysql_query($sql7);
if(mysql_num_rows($result7)>0){
while($row7=mysql_fetch_array($result7)){
?>       
<a href="<?php echo base_url(); ?>front/category_details/<?php echo $row7['tag'];?>" class="btn tp-btn tp-btn-grey"><?php echo $row7['tag'];?></a>
<?php
}
}else{?>
<p>No Tags Found</p>
<?php
}
?>
</div>
              <!--Categories widget end--> 
            </div>
          </div>
        </div>
        <!-- /.tp blog right --> 
      </div>
    </div>
  </div><!-- /.blog details -->
</div>
<?php /*?><!-- /.Main container start-->
<div class="tp-newsletter"><!-- Newsletter -->
  <div class="container">
    <!--<div class="row">
      <div class="col-md-5 news-title"><!-- section title -->
        <h2><i class="fa fa-envelope-o"></i> Register to Peace Newsletter</h2>
      </div>
      <div class="col-md-7 newsletter">
        <form method="post" action="newsletter.php">
          <div class="input-group">
            <label class="sr-only control-label" for="newsletter">Newsletter</label>
            <input type="email" id="newsletter" name="newsletter" class="form-control" placeholder="E-mail Address">
            <span class="input-group-btn">
            <button class="btn tp-btn-orange" type="submit">Submit</button>
            </span> </div>
        </form>
        <!-- /input-group 
        </div>
      <!-- Newsletter form 
    </div>-->
  </div>
</div><?php */?>
<!-- Newsletter -->
<?php  $this->load->view('footer');?>
