<?php $this->load->view('user_header');
//echo $this->session->userdata('id');?>
<div class="tp-page-header"><!--tp-page-header-->
  <div class="container">
    <div class="row">
      <div class="col-md-7">
        <div class=""> <!-- page header  -->
        <br>
          <h1>Query Reply</h1>
        </div>
        <!--/.page header  --> 
      </div>
    </div>
  </div>
</div>

<style>
.error{color:#FF0000;
}
</style>
<?php
if(!empty($query_reply)){
//$i= 1;	
//$questid=$query_reply[0]['id'];	
$user_id=$query_reply[0]['user_id'];	
$unique_no=$query_reply[0]['unique_no'];	
$query=$query_reply[0]['query'];	
	
	
}
?>

<!-- /.tp-page-header--> 
<div class="tp-breadcrumb"><!--tp-breadcrumb-->
  <div class="container">
    <div class="row">
      <div class="col-md-8">
        <ol class="breadcrumb">
          <li><a href="<?php echo base_url(); ?>login/userinbox">Home</a></li>
          <li class="active">Query reply</li>
        </ol>
        
      </div>
    </div>
  </div>
</div><!--/.tp-breadcrumb-->

<div class="main-container" id="main-container"><!--Main container start-->
  <div class="tp-blog-details" id="tp-blog-details"><!-- blog details -->
    <div class="container">
      <div class="row">
        <div class="col-md-12 tp-blog-left">
          <div class="row">
           <p><b>GUN-<?php echo $unique_no; ?></b></p>&nbsp;&nbsp;&nbsp;<b>#<?php echo $query; ?> ?</b>
<!-- /.blog post start--> 
</div>
        
          <div class="row">
            <div class="col-md-10 blog-comments">
              <h2>Query</h2>
              
              <?php if($this->session->flashdata('message')){?>
		  <div class="alert alert-success">  
           <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>    
		    <?php echo $this->session->flashdata('message')?>
		  </div>
		<?php } ?>	           
                       
              
              
              
              <div class="comments">
                <!--<div class="media"><!-- comments block start
                  <a class="media-left" href="#"> <img src="images/comments-user.jpg" alt="" class="img-circle"> </a>
                  <div class="media-body">
                    <h3 class="media-heading"><a href="#">Michelle J. Parsons</a>
                    <span class="cmt-meta"><i class="fa fa-calendar"></i> 10 May, 2015</span>
                    <small>2 Min Ago</small>
                    </h3>
                    <p>Cras sit amet nibh liberoin gravida nulla. Nulla vel metus scelerisque ante sollicitudin commodo. Cras purus odio, vestibulum in vulputate atin faucibus.</p>
                    <a href="#" class="btn tp-btn tp-btn-grey">Reply <i class="fa fa-mail-forward"></i></a> </div>
                </div>-->
                <!-- comments block end-->
                                
<div class="media"><!-- comments block start--> 
<!--<a class="media-left" href="#"> <img src="" alt="" class="img-circle"> </a>
<div class="media-body">-->
<?php
			  
function get_time_ago( $time )
{
    $time_difference = time() - $time;

    if( $time_difference < 1 ) { return 'less than 1 second ago'; }
    $condition = array( 12 * 30 * 24 * 60 * 60 =>  'year',
                30 * 24 * 60 * 60       =>  'month',
                24 * 60 * 60            =>  'day',
                60 * 60                 =>  'hour',
                60                      =>  'minute',
                1                       =>  'second'
    );

    foreach( $condition as $secs => $str )
    {
        $d = $time_difference / $secs;

        if( $d >= 1 )
        {
            $t = round( $d );
            return ' ' . $t . ' ' . $str . ( $t > 1 ? 's' : '' ) . ' ago';
        }
    }
}		  
		  
///date_default_timezone_set('Asia/Kolkata');			  
$qid1=$this->uri->segment(3) ? $this->uri->segment(3) : 0;

$sql5="select *,fqa.id as fid from fis_query fq inner join fis_query_ans fqa on(fq.id=fqa.quest_id) inner join fis_users fs
on(fs.id=fqa.user_id) where fqa.quest_id='".$qid1."' ";
$result5=mysql_query($sql5);
if(mysql_num_rows($result5)>0){
while($row3=mysql_fetch_array($result5)){
          
    if($row3['reply_type']=='fiscon'){
	?>
          
    <div class="media nested-media">
    <!-- Nested comments block start--> 
    <a class="media-left" href="#">
    <image src="<?php echo base_url();?>user_file/fiscon_icon.png" alt="User" class="img-circle" style="width:50px; height:50px;"></a>
    <div class="media-body">
    <h3 class="media-heading"><a href="#"><?php echo $row3['reply_type'];?></a>
    <span class="cmt-meta"><i class="fa fa-calendar"></i><?php echo date('d-M-Y',strtotime($row3['ans_date']));?></span>
    <small><?php 
		$date=$row3['ans_date'];
		echo get_time_ago(strtotime($date));?></small>
    </h3>
<p><?php echo $row3['answer'];?></p>

<p>&nbsp;&nbsp;   
 <?php
	if(!empty($row3['doc_file'])) {?>            
	<a class="fa fa-download" href="<?php echo base_url(); ?>login/download/<?php echo $row3['fid']; ?>"  title="Download Attachment"></a>
	<?php
	}else{
	}?>
</p>

<!--<a href="#" class="btn tp-btn tp-btn-grey">Reply <i class="fa fa-mail-forward"></i></a>-->

</div>
</div>
<?php
}else if($row3['reply_type']=='user'){
	?>    
<div class="media nested-media">
<!-- Nested comments block start--> 
<a class="media-left" href="#">
<?php
if(!empty($row3['photo'])){
?>
<image src="<?php echo base_url();?>user_file/<?php echo $row3['photo'];?>"  alt="User" class="img-circle" style="width:50px; height:50px;">
<?php
}else{
?>
<image src="<?php echo base_url();?>user_file/default_user.png" alt="User" class="img-circle">
<?php
}
?>         
    
</a>
    <div class="media-body">
    <h3 class="media-heading"><a href="#"><?php echo $row3['reply_type'];?></a>
    <span class="cmt-meta"><i class="fa fa-calendar"></i><?php echo date('d-M-Y',strtotime($row3['ans_date']));?></span>
    <small><?php 
	$date=$row3['ans_date'];
	echo get_time_ago(strtotime($date));?></small>
    </h3>
<p><?php echo $row3['answer'];?>  </p>
 <p>&nbsp;&nbsp;   
 <?php
if(!empty($row3['doc_file'])){?>            
<a class="fa fa-download" href="<?php echo base_url(); ?>login/download/<?php echo $row3['fid']; ?>"  title="Download Attachment"></a>
<?php
}else{
}?>

</p>
</div>
</div>

<?php
}else{
}?>    
<!-- Nested  comments block end-->                     
<?php
}
}else{?>
<div>
<p>Not Record Found</p>
</div>
<?php
}
?>  
                                           
</div>
</div>                             
</div>
</div>
</div>

<style>
.error{color:#FF0000;
}
</style>
<div class="row">
<div class="col-md-12 leave-comments">
<h2>Query Reply</h2>
<form role="form" class="leave-form" method="post" action="<?php echo base_url(); ?>login/submitquery" enctype="multipart/form-data">					  
<input type="hidden" name="user_id" value="<?php echo $user_id; ?>" >
<input type="hidden" name="uquery" value="<?php echo $query; ?>" >

<input type="hidden" name="quest_id" value="<?php echo  $this->uri->segment(3) ? $this->uri->segment(3) : 0; ?>" >
<input type="hidden" name="unique_no" value="<?php echo $unique_no; ?>" >

 <div class="form-group">
                <label class="control-label" for="">Attachment</label>
                   <input id="attach" name="attach_file" type="file"  class="form-control input-md" onChange="return ValidateSingleInput(this)">
                </div>

                <div class="form-group">
                  <label class="control-label">Query Reply<span class="error">*</span></label>
                  <textarea class="form-control textarea"  name="reply" rows="4" placeholder="Query Answer:" required></textarea>
              <?php echo form_error('reply'); ?> 
                </div>
                
<button type="submit"  name="submit" class="btn btn-small btn-primary">Reply</button>
	    <a  href="<?php echo base_url(); ?>login/managequery"><button type="button" class="btn btn-small btn-danger">Back</button></a> 
			
              </form>
            </div>
          </div>
        </div>
        <!-- /.tp blog right --> 
      </div>
    </div>
  </div><!-- /.blog details -->
</div>
<!-- /.Main container start-->
<?php /*?><div class="tp-newsletter"><!-- Newsletter -->
  <div class="container">
    <div class="row">
      <div class="col-md-5 news-title"><!-- section title -->
        <h2><i class="fa fa-envelope-o"></i> Register to Peace Newsletter</h2>
      </div>
      <div class="col-md-7 newsletter"><!-- Newsletter form -->
        <form method="post" action="newsletter.php">
          <div class="input-group">
            <label class="sr-only control-label" for="newsletter">Newsletter</label>
            <input type="email" id="newsletter" name="newsletter" class="form-control" placeholder="E-mail Address">
            <span class="input-group-btn">
            <button class="btn tp-btn-orange" type="submit">Submit</button>
            </span> </div>
        </form>
        <!-- /input-group --> 
        </div>
      <!-- Newsletter form -->
    </div>
  </div>
</div><?php */?>

<?php  $this->load->view('user_footer'); ?>
<script>
 var _validFileExtensions = [".jpg", ".jpeg", ".png",".JPEG",".doc",".docx",".pdf"];    
function ValidateSingleInput(oInput) {
    if (oInput.type == "file") {
        var sFileName = oInput.value;
		 //var sFileSize = oInput.size;
       // var iConvert = (oInput.size /1024).toFixed(2);

		
         if (sFileName.length > 0) {
            var blnValid = false;
            for (var j = 0; j < _validFileExtensions.length; j++) {
                var sCurExtension = _validFileExtensions[j];
                if (sFileName.substr(sFileName.length - sCurExtension.length, sCurExtension.length).toLowerCase() == sCurExtension.toLowerCase()) {
                    blnValid = true;
                    break;
                }
				
            }
			
			
            if (!blnValid) {
                alert("Sorry,invalid file extension, allowed file type extensions are only: " + _validFileExtensions.join(", "));
                oInput.value = "";
                return false;
            }
        }
    }
    return true;
}
 
</script>