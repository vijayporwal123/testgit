<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Comment extends CI_Controller{

 public function __construct(){
  parent::__construct();
  $this->load->model('admin/adminmodel');
  $this->load->library(array('form_validation','session','email'));
  $this->load->helper(array('url','html','form'));
 }


public function index(){
//$status ="0";
$data['allcomment'] = $this->adminmodel->result_getall();
$this->load->view('admin/commentlist',$data);
}


public function changepassword(){
$this->load->view('admin/changepassword');
}


public function updatepassword(){

//$id =  $this->session->userdata();

  $email = $this->session->userdata('email');


$where  = "where email='".$email."' and user_type='admin' ";
$data['show_bloglist'] = $this->adminmodel->select('fis_users',$where);

 $password = $data['show_bloglist'][0]['password'];

	if($_POST){
	 
	 $currentpass = md5($this->input->post("current_password"));
	 $newpass = md5($this->input->post("new_pass"));
	 $confpass = md5($this->input->post("con_pass"));
	 

	    if($password!=$currentpass){
		echo "<script type='text/javascript'>
		alert('Current Password Does not match!');
        window.location.href='changepassword';
        </script>";
		}
				
		else{
		 
		$data = array('password'=>$newpass);		
		$table = 'fis_users';
		  
		$id2 = $this->adminmodel->data_update(array("email"=>$email),$table,$data);
		
		echo "<script type='text/javascript'>
		alert('Password Changed Successfully');
      window.location.href='changepassword';
      </script>";
	  
	  }
				
	}

}//end



 public function deletecomment($id)
    {  
	
	$id = $this->uri->segment(4) ? $this->uri->segment(4) : 0;
	
	//$id = $this->db->get('cid');
	
    $this->db->where('cid', $id);
    $this->db->delete('comment');
    $this->session->set_flashdata('message', 'Your data deleted Successfully..');
    redirect('admin/comment/index');
    }


public function approvecomment(){
   
	   $id =  $this->uri->segment(4) ? $this->uri->segment(4) : 0;
	
	    $table = 'comment';
		$where  = "where cid = $id  ";
	    $data['commentdata'] = $this->adminmodel->select($table,$where);	
        $this->load->view('admin/approvecomment',$data);
    }
	
	
	

	
	

public function updatecomment(){

$id =  $this->uri->segment(4) ? $this->uri->segment(4) : 0;

	if($_POST){
	 
	 $status = $this->input->post("status");
	 
	//if(!empty($file_name)){
	$data = array('status' =>$status);		
				
		//print_r($data); 
		  $table = 'comment';
		$id1 = $this->adminmodel->data_update(array("cid"=>$id),$table,$data);
		//print_r($id1);
    $msg1=$this->session->set_flashdata('message', 'Comment Updated  Successfully..');

		
		 if($id1){
		    redirect('admin/comment/index',$msg1);
			
		}
	
	}

}




}//last end
?>
