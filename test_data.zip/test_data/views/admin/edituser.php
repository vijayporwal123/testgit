<?php
$this->load->view('admin/header');
?>
<?php
$this->load->view('admin/session_check');
?>
<?php
if(!empty($userdata)){
//echo"<pre>";
//print_r($blogdata);

    $id = $userdata[0]['id'];
    $username = $userdata[0]['username'];
    $email = $userdata[0]['email'];
    $mobile_no = $userdata[0]['mobile_no'];
    $company_name = $userdata[0]['company_name'];
    $designation = $userdata[0]['designation'];
    $address = $userdata[0]['address'];
	$admin_verify_status = $userdata[0]['admin_verify_status'];
    $user_file = $userdata[0]['user_file']; 
	$user_photo = $userdata[0]['user_photo'];  
 
}
?>


<body>

<div id="wrapper">

<!-- Navigation -->
<?php 
$this->load->view('admin/navigation');
?> 
<style>
.error{color:#FF0000;
}
</style>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h3 class="page-header">Edit User</h3>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                           Edit Form
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-6">
                                
                                
<form role="form"  method="post" action="<?php echo base_url(); ?>admin/user/updateuser/<?php echo $id; ?>" enctype="multipart/form-data" >

                         
<p><span class="error">* required field.</span></p>     
                                        
<input type="hidden" name="uid" value="<?php echo $id; ?>">                                               
   
                                        
<div class="form-group">
                                            <label>User Name<span class="error">* </span></label>
<input class="form-control"  name="username" placeholder="Enter Username*"  type="text" value="<?php echo  $username; ?>">
                                            <?php echo form_error('username'); ?>
                                        </div>                                        
                                        

                                       
                                         
                                        <div class="form-group">
                                         <label>Upload Photo  [Allowed Only jpg, jpeg, png image]</label>
                                            <input type="file" name="photo" onChange="ValidateSingleInput(this);">
                                            <?php
                                            if(!empty($user_photo)){?>
                                      <image src="<?php echo base_url();?>user_photo/<?php echo $user_photo; ?>" style="width:100px; height:100px;" >      
                            <?php
							}else{?>                
                            <image src="<?php echo base_url();?>user_photo/default.png" style="width:100px; height:100px;" type="image/jpg">
                <?php
				}
				?>
                                        </div>
                                        
                                     
                                       
                                        
                                        <div class="form-group">
                                            <label>Comapany Name<span class="error">* </span></label>
              <input class="form-control"  name="company_name" placeholder="Enter Comapany Name*"  type="text" value="<?php echo $company_name; ?>"> 
                                            <?php echo form_error('company_name'); ?>
                                        </div>
                                         
                                        
                                        <div class="form-group">
                                            <label>Designation<span class="error">* </span></label>
              <input class="form-control"  name="designation" placeholder="Enter Designation*"  type="text" value="<?php echo $designation; ?>">
                                            <?php echo form_error('designation'); ?>
                                        </div>
                                        
                                        
                                          <div class="form-group">
                                            <label>Mobile Number<span class="error">* </span></label>
              <input class="form-control"  name="mobile_no" placeholder="Enter Mobile No*"  type="text" value="<?php echo $mobile_no; ?>">
                                            <?php echo form_error('mobile_no'); ?>
                                        </div>
                                        
                                        
                                         <div class="form-group">
                                            <label>Email ID.<span class="error">* </span></label>
              <input class="form-control"  name="email" placeholder="Enter Email ID*"  type="text" value="<?php echo $email; ?>">
                                            <?php echo form_error('email'); ?>
                                        </div>
                                        
                                        
                                        <div class="form-group">
                                            <label>Address</label>
<textarea class="form-control" placeholder="Enter Address* ..."  name="address" style="height:100px" ><?php echo $address; ?></textarea>

<?php //echo form_error('address'); ?>   
                      </div> 
                                           
<?php /*?><div class="form-group">
           <label>Upload Data  [Allowed Only Doc, Pdf, Excel File]</label>
            <input type="file" name="file_name" onChange="ValidateSingleInput1(this);" >
            <div align="center">
<?php
if(!empty($user_file)){
			?>                               
<a class="fa fa-download" href="<?php echo base_url(); ?>admin/user/download/<?php echo $id; ?>" title="Download File"></a><?php  
}else{
?>
<p style="color:#FF0000;">File Not Exist</p>
<?php
}
?>
</div>                                                     
</div><?php */?>



<div class="form-group">
<label>Status</label>
<select class="form-control" name="status">
<option value="0"<?php if($admin_verify_status=='0'){
echo 'selected="selected" ';
}?>>Not Approved</option>
<option value="1"<?php if($admin_verify_status=='1'){
echo 'selected="selected" ';
}?>>Approved</option>
</select>

<?php //echo form_error('tags'); ?>   
</div> 
                                        
<button type="submit"  name="submit" class="btn btn-primary btn-sm">Update</button>
<a  href="<?php echo base_url(); ?>admin/user/manageuser"><button type="button" class="btn btn-danger btn-sm">Cancel</button></a> 
</form>
                                    
</div>
                                <!-- /.col-lg-6 (nested) -->
                                <!-- /.col-lg-6 (nested) -->
</div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

<!--<link rel="stylesheet" type="text/css" href="<?php //echo base_url(); ?>assets/lib/css/bootstrap.min.css" />
--><link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/src/bootstrap-wysihtml5.css" />
    <script src="<?php echo base_url(); ?>assets/lib/js/wysihtml5-0.3.0.js"></script>
    <script src="<?php echo base_url(); ?>assets/lib/js/jquery-1.7.2.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/lib/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/src/bootstrap3-wysihtml5.js"></script>

<script>
    $('.textarea').wysihtml5();
</script>

   <style type="text/css" media="screen">
        .btn.jumbo {
            font-size: 20px;
            font-weight: normal;
            padding: 14px 24px;
            margin-right: 10px;
            -webkit-border-radius: 6px;
            -moz-border-radius: 6px;
            border-radius: 6px;
        }
    </style>


    <!-- jQuery -->
    
<!-- <script src="<?php echo base_url(); ?>assets/bower_components/jquery/dist/jquery.min.js"></script>
-->
    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo base_url(); ?>assets/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="<?php echo base_url(); ?>assets/bower_components/metisMenu/dist/metisMenu.min.js"></script>

   
    <!-- Custom Theme JavaScript -->
    <script src="<?php echo base_url(); ?>assets/dist/js/sb-admin-2.js"></script>

     <script>
 var _validFileExtensions1 = [".doc", ".docx", ".pdf",".xlsx"];    
function ValidateSingleInput1(oInput) {
    if (oInput.type == "file") {
        var sFileName = oInput.value;
         if (sFileName.length > 0) {
            var blnValid = false;
            for (var j = 0; j < _validFileExtensions1.length; j++) {
                var sCurExtension = _validFileExtensions1[j];
                if (sFileName.substr(sFileName.length - sCurExtension.length, sCurExtension.length).toLowerCase() == sCurExtension.toLowerCase()) {
                    blnValid = true;
                    break;
                }
            }
             
            if (!blnValid) {
                alert("Sorry, " + sFileName + " is invalid file extension, allowed file type extensions are only: " + _validFileExtensions1.join(", "));
                oInput.value = "";
                return false;
            }
        }
    }
    return true;
}
 
 </script>


<script>
 var _validFileExtensions = [".jpg", ".jpeg", ".png",".JPEG"];    
function ValidateSingleInput(oInput) {
    if (oInput.type == "file") {
        var sFileName = oInput.value;
         if (sFileName.length > 0) {
            var blnValid = false;
            for (var j = 0; j < _validFileExtensions.length; j++) {
                var sCurExtension = _validFileExtensions[j];
                if (sFileName.substr(sFileName.length - sCurExtension.length, sCurExtension.length).toLowerCase() == sCurExtension.toLowerCase()) {
                    blnValid = true;
                    break;
                }
            }
             
            if (!blnValid) {
                alert("Sorry, " + sFileName + " is invalid file extension, allowed file type extensions are only: " + _validFileExtensions.join(", "));
                oInput.value = "";
                return false;
            }
        }
    }
    return true;
}
 
 
 
 </script>


</body>

</html>
