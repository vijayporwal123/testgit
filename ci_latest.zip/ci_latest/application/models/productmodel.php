<?php
class Productmodel extends CI_Model{

/*common function for insert data*/
    public function insert($tbl,$data)
    {    
        $insert= $this->db->insert($tbl, $data);
        if($insert){
            return $this->db->insert_id();
        }else{
            return false;
        }

    }

/*common function for fetchall data*/
 public function select($tbl,$limit=null,$offset=NULL,$search = NULL){
    if ($search == "NIL") $search = "";

    $this->db->select("*");
    $this->db->from($tbl);
    $this->db->like('email',$search);
    $this->db->or_like('password',$search);
    $this->db->limit($limit, $offset);
    $query=$this->db->get();
    return $query->result_array();
 }
    
function totalusers(){
  return $this->db->count_all_results('user');
 }




/*common function for fetch data*/
public function find_id($tbl,$id){
    $query=$this->db->get_where($tbl, array('id' =>$id));
    return $query->result_array();
 }

/*common function for update data*/
public function update($tbl,$where,$data){
   $this->db->where($where);
  return  $this->db->update($tbl, $data);
   
 }

/*common function for delete data*/
public function delete($tbl,$id){
   $this->db->where($id);
  return  $this->db->delete($tbl);
   
 }


/*common function for fetchall and fetch data*/
function fetchdata($table, $where ='')
     {
        $sql = "SELECT * FROM $table";
    if(!empty($where)){
       $sql .= " $where";
    }
    
    $query = $this->db->query($sql);
        if($query->num_rows()>0)
        {
            return $query->result_array();
        }
        else{
            return false;
        }
    }



/*public function search_data($email){
$this->db->select('*');
$this->db->from('user');
$this->db->like('email',$email);
$this->db->or_like('password',$email);
$query=$this->db->get();

if ($query->num_rows()>0) {
   return $query->result_array();
}else{
 return $query->result_array();
 }

}*/



function usertotal($tbl,$search = NULL)
{

if ($search == "NIL") $search = "";

$this->db->select('*');
$this->db->from($tbl);
$this->db->like('email',$search);
$this->db->or_like('password',$search);
$query=$this->db->get();
return $query->num_rows();

//if ($query->num_rows()>0) {
  // return $query->num_rows();
//}else{
 //return $query->result_array();
 //}




    }


}

?>