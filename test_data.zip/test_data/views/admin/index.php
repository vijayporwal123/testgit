<?php 
$this->load->view('admin/header');
?>
<?php
//if($this->session->userdata('id')!=''){
//$this->load->view('http://localhost/codeig/admin/login/admininbox');
//}
?>

<style>
.error{color:#FF0000;
}
</style>

<body>

    <div class="container">
        <div class="row">
            <div class="col-md-4 col-md-offset-4">
                <div class="login-panel panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Fiscon Login </h3>
                    </div>
                    <div class="panel-body">
                        <form role="form" action="<?php echo base_url(); ?>admin/login/signin" method="post">
                            <fieldset>
                                <div class="form-group">
                                    <input class="form-control " placeholder="EmailId" name="email" type="email" autofocus value="">
                                    <?php echo form_error('email'); ?>     
                                </div>
                                
                                <div class="form-group">
<input class="form-control " placeholder="Password" name="password" type="password"  value="" >
									<?php echo form_error('password'); ?>   
                                      
                                </div>
                               
                               <div class="form-group">
                                <!-- Change this to a button or input when using this as a form -->
<!--<a href="index.html" class="btn btn-lg btn-success btn-block">Login</a>
--><button type="submit" name="submit" class="btn btn-sm btn-success ">Login</button>
<a href="<?php echo base_url(); ?>admin/login/forgotpassword"><button type="button" name="forgot" class="btn btn-sm btn-success ">Forgot Password</button></a>


                                </div>
                                
                            </fieldset>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

 
</body>

</html>
