<?php  $this->load->view('header');?>
<style>
.error{color:#FF0000;
}
</style>
<div class="main-container" id="main-container"><!--Main container start-->
  <div class="form-page" id="form-page"><!-- form section -->
  	<div class="container">
    	<div class="row">
        	<div class="col-md-offset-1 col-md-10">
            	<div class="row">
                	<div class="col-md-6">
                    	<div class="grey-box"><!-- greay box -->
                        	<h2 class="tp-title">Forgot Password</h2>
                            
                            <form action="<?php echo base_url(); ?>login/forgot_password_verify" method="post" >
                                <!-- Text input-->
                                <div class="form-group">
                                  <label class="control-label" for="email">E-mail</label>  
                                  <input id="email" name="email" type="email" placeholder="" class="form-control input-md" required>
                                      <?php echo form_error('email'); ?>     

                                </div>
                                
                                <!-- Text input-->
                                <!--<div class="form-group">
                                  <label class="control-label" for="password">Password</label>  
                                  <input id="password" name="password" type="password" placeholder="" class="form-control input-md" required>
                                     <?php //echo form_error('password'); ?>     

                                </div>
                                -->
                                <!-- Button -->
                                <div class="form-group">
                                  <label class="control-label" for="button"></label>
                                    <button id="button" name="button" type="submit" class="btn tp-btn tp-btn-orange">login</button>
                                </div>
<!--                                <small><a href="#">Forgot Password?</a></small>
-->                                </form>
                        </div><!-- /.greay box -->
                    </div>
                    <div class="col-md-6">
                    	
                    </div>
                </div>
            </div>
        </div>
    </div>
  </div>
  <!-- form section --> 
</div>
<!-- /.Main container start-->
<?php /*?><div class="tp-newsletter"><!-- Newsletter -->
  <div class="container">
    <div class="row">
      <div class="col-md-5 news-title"><!-- section title -->
        <h2><i class="fa fa-envelope-o"></i> Register to Peace Newsletter</h2>
      </div>
      <div class="col-md-7 newsletter"><!-- Newsletter form -->
        <form method="post" action="newsletter.php">
          <div class="input-group">
            <label class="sr-only control-label" for="newsletter">Newsletter</label>
            <input type="email" id="newsletter" name="newsletter" class="form-control" placeholder="E-mail Address">
            <span class="input-group-btn">
            <button class="btn tp-btn-orange" type="submit">Submit</button>
            </span> </div>
        </form>
        <!-- /input-group --> 
        </div>
      <!-- Newsletter form --> 
    </div>
  </div>
</div><?php */?>
<?php  $this->load->view('footer');?>
