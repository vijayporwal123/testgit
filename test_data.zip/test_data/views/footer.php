<!-- Newsletter -->
<div id="tp-footer-two" class="tp-footer-two"><!-- footer -->
  <div class="container">
    <div class="row ft-section">
      <div class="col-md-4 ft-logo"> <img src="<?php echo base_url(); ?>assets/front_end/images/logo_fiscon.png"    alt="Fiscon Consultant" class="img-responsive"></div>
      <div class="col-md-8 cta">+91 98260 98751 
    </div>
    
    </div>

<div class="row ft-section"> 
      <!-- ft aboutus -->
      <div class="col-md-2 ft-links"><!-- footer links -->
        <h2>Services</h2>
        <ul>
          <li><i class="fa fa-angle-double-right"></i><a href="#">Retail Assets</a></li>
          <li><i class="fa fa-angle-double-right"></i><a href="#">Working Capital</a></li>
          <li><i class="fa fa-angle-double-right"></i><a href="#">Project Finance</a></li>
          <li><i class="fa fa-angle-double-right"></i><a href="#">Agricultire Loan</a></li>
          <li><i class="fa fa-angle-double-right"></i><a href="#">Government Subsidies</a></li>
          <li><i class="fa fa-angle-double-right"></i><a href="#">Land allotment</a></li>
          <li><i class="fa fa-angle-double-right"></i><a href="#">Others</a></li>
        </ul>
      </div>
      <!-- /.footer links -->
      
      <div class="col-md-2 ft-links"><!-- footer links -->
        <h2>Quick Links</h2>
        <ul>
          <li><i class="fa fa-angle-double-right"></i><a href="#">Home</a></li>
          <li><i class="fa fa-angle-double-right"></i><a href="#">About us</a></li>
          <li><i class="fa fa-angle-double-right"></i><a href="#">Services</a></li>
          <li><i class="fa fa-angle-double-right"></i><a href="#">Career</a></li>
          <li><i class="fa fa-angle-double-right"></i><a href="#">Blog</a></li>
          <li><i class="fa fa-angle-double-right"></i><a href="#">Contacts</a></li>
        </ul>
      </div>
      
      <!-- /.footer links -->
      <div class="col-md-5 ft-aboutus">
      <p><span class="addrs">Address :</span><br /> 207, 2nd Floor
            Capt. C.S. Nayadu Arcade,
            10/2, Old Palasia, 
            Near Greater Kailash Hospital,
            Indore- 452001 ,
            MP.India</p>
        <p><span class="addrs">Phone : </span>+91 98260 98751</p>
        <p><span class="addrs">Email : </span>info@fiscon.in</p>
       <!-- <a href="#" class="btn tp-btn tp-btn-orange">Get A Quote</a>--> </div>
      <div class="col-md-3 ft-links-social"><!-- footer social links -->
        <h2>Social</h2>
        <ul class="social-menu">
          <li><a href="https://www.facebook.com/sharer/sharer.php?u=http://fiscon.in/fiscon2" class="social-box facebook" target="_blank"><i class="fa fa-facebook-square"></i>Facebooks</a></li>
          <li><a href="https://plus.google.com/share?url=http://fiscon.in/fiscon2" class="social-box google" target="_blank"><i  class="fa fa-google-plus-square"></i>Google</a></li>
          <li><a href="https://twitter.com/home?status=http://fiscon.in/fiscon2" class="social-box twitter" target="_blank"><i class="fa fa-twitter-square"></i>Twitter</a></li>
<!--<li><a href="#" class="social-box linkedin"><i class="fa fa-linkedin-square"></i>Linkedin</a></li>
-->        </ul>
      </div>
      <!-- /.footer social links --> 
    </div>
    <div class="row">
      <div class="col-md-6 copyright-text"><!-- copyright text --> 
        Copyright&copy;2016 . Fiscon Consultants Pvt. Ltd.</div>
      <!-- /.copyright text -->
      <div class="col-md-6 tiny-ft-links"><!-- tiny ft links -->
        <ul>
          <li>Designed by: <a href="http://www.oxygenwebtech.com" target="_blank" title=""> OXYGEN WEBTECH</a></li>
          <!--<li><a href="#">Privacy Policy</a></li>
          <li><a href="#">Terms of Use Security</a></li>-->
        </ul>
      </div>
      <!-- /.tiny ft links --> 
    </div>
  </div>
</div>
<!-- /.footer --> 

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
<script src="<?php echo base_url(); ?>assets/front_end/js/jquery-1.11.3.min.js"></script> 
<!-- Include all compiled plugins (below), or include individual files as needed --> 
<script src="<?php echo base_url(); ?>assets/front_end/js/bootstrap.min.js"></script> 
<script src="<?php echo base_url(); ?>assets/front_end/js/nav-menu.js"></script> 
<script src="<?php echo base_url(); ?>assets/front_end/js/owl.carousel.min.js"></script> 
<!--slider jquery --> 
 <script type="text/javascript" src="<?php echo base_url(); ?>assets/front_end/js/slider.js"></script>
 <script type="text/javascript" src="<?php echo base_url(); ?>assets/front_end/js/product-carousel.js"></script>
 <script type="text/javascript" src="<?php echo base_url(); ?>assets/front_end/js/testimonial.js"></script>
<!-- search open--> 
<script type="text/javascript" src="<?php echo base_url(); ?>assets/front_end/js/search.js"></script> 
<script type="text/javascript" src="<?php echo base_url(); ?>assets/front_end/js/font-size.js"></script> 
<script type="text/javascript" src="<?php echo base_url(); ?>assets/front_end/js/jquery.easing.min.js"></script>
</body>
</html>