<?php
$this->load->view('admin/header');
?>

<?php
$this->load->view('admin/session_check');
?>
<body>

<div id="wrapper">

<!-- Navigation -->
<?php 
$this->load->view('admin/navigation');
?> 
<style>
.error{color:#FF0000;
}
</style>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
            <?php include("session_msg.php"); ?>

                
                
                    <h3 class="page-header">Add Blog</h3>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                           Blog Form
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-6">
                                
                                

<form role="form"  method="post" action="<?php echo base_url(); ?>admin/blog/blogsubmit" enctype="multipart/form-data" >
                                  
                                <p><span class="error">* required field.</span></p>     
                                        
                                        <div class="form-group">
                                            <label>Title<span class="error">* </span></label>
              <input class="form-control"  name="title" placeholder="Enter Title*" required type="text">
                                            <?php echo form_error('title'); ?>
                                        </div>
                                        
                                        
                                        <div class="form-group">
                                            <label>Description<span class="error">* </span></label>
<!--<textarea class="form-control" id="txtEditor" name="desc" rows="3"></textarea>-->
<textarea class="textarea form-control" placeholder="Enter Description* ..."  name="desc" style="height: 200px" required></textarea>


                                            <?php echo form_error('desc'); ?>   

                                        </div>
                                        
                                        
                                        <div class="form-group">
                                            <label>Tags<span class="error">* </span></label>
                                            <select class="form-control" name="tags" required>
                                             <option value="">--Please-Select Tags--</option>
                                                <option value="A">A</option>
                                                <option value="B">B</option>
                                                <option value="C">C</option>
                                            </select>
                                            
                                           <?php echo form_error('tags'); ?>  
                                            
                                        </div>
                                        
                                         
                                        <!--<div class="form-group">
                                            <label>Youtube Url</label>
                       <input class="form-control"  name="youtube" placeholder="Enter Youtube Url"  type="text">
                                            
                                        </div>-->
                                        
                                        <div class="form-group">
                                            <label>Upload Video or Image <p>Allowed File type only [mp4,3gp, avi, mkv, jpeg, png, jpg] </p></label>
                                            <input type="file" name="photo" onChange="ValidateSingleInput1(this);" >
                                        </div>
                                        
                                        <button type="submit"  name="submit" class="btn btn-primary btn-sm">Submit</button>
                                        <a  href="<?php echo base_url(); ?>admin/blog/bloglist"><button type="button" class="btn btn-danger btn-sm">Cancel</button></a> 
                                    </form>
                                    
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                                <!-- /.col-lg-6 (nested) -->
                                
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

<!--<link rel="stylesheet" type="text/css" href="<?php //echo base_url(); ?>assets/lib/css/bootstrap.min.css" />
--><link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/src/bootstrap-wysihtml5.css" />
    <script src="<?php echo base_url(); ?>assets/lib/js/wysihtml5-0.3.0.js"></script>
    <script src="<?php echo base_url(); ?>assets/lib/js/jquery-1.7.2.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/lib/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/src/bootstrap3-wysihtml5.js"></script>

<script>
    $('.textarea').wysihtml5();
</script>

   <style type="text/css" media="screen">
        .btn.jumbo {
            font-size: 20px;
            font-weight: normal;
            padding: 14px 24px;
            margin-right: 10px;
            -webkit-border-radius: 6px;
            -moz-border-radius: 6px;
            border-radius: 6px;
        }
    </style>





    <!-- jQuery -->
    
<!--    <script src="<?php echo base_url(); ?>assets/bower_components/jquery/dist/jquery.min.js"></script>
-->
    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo base_url(); ?>assets/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="<?php echo base_url(); ?>assets/bower_components/metisMenu/dist/metisMenu.min.js"></script>

   
    <!-- Custom Theme JavaScript -->
    <script src="<?php echo base_url(); ?>assets/dist/js/sb-admin-2.js"></script>



    <script>
	//[".jpg", ".jpeg", ".gif", ".png", ".mp4", ".3gp", ".ogg", ".avi", ".mkv", ".mpeg"]
 var _validFileExtensions1 = [".jpg", ".jpeg", ".gif", ".png", ".mp4", ".3gp", ".ogg", ".avi", ".mkv", ".mpeg"];    
function ValidateSingleInput1(oInput) {
    if (oInput.type == "file") {
        var sFileName = oInput.value;
         if (sFileName.length > 0) {
            var blnValid = false;
            for (var j = 0; j < _validFileExtensions1.length; j++) {
                var sCurExtension = _validFileExtensions1[j];
                if (sFileName.substr(sFileName.length - sCurExtension.length, sCurExtension.length).toLowerCase() == sCurExtension.toLowerCase()) {
                    blnValid = true;
                    break;
                }
            }
             
            if (!blnValid) {
                alert("Sorry, " + sFileName + " is invalid file extension, allowed file type extensions are only: " + _validFileExtensions1.join(", "));
                oInput.value = "";
                return false;
            }
        }
    }
    return true;
}
 
 
 
 </script>

</body>

</html>
