<?php
class User_model extends CI_Model {

 function __construct(){
  parent::__construct();
 }


 
function processLogin($email,$password,$userstatus,$adminstatus){
  $this->db->select("*");
  $whereCondition = $array = array('email' =>$email,
  'password'=>md5($password),
  'user_verify_status' =>$userstatus,
  'admin_verify_status' =>$adminstatus
  );
  $this->db->where($whereCondition);
  $this->db->from('fis_users');
  $query = $this->db->get();
  return $query;
 }
  



 function getMovies($limit=null,$offset=NULL){
  $this->db->select("*");
  $this->db->from('fis_blog');
  $this->db->order_by("id", "desc");
  $this->db->limit($limit, $offset);
  $query = $this->db->get();
  return $query->result();
 }

 function totalMovies(){
  return $this->db->count_all_results('fis_blog');
 }



function getQuery($limit=null,$offset=NULL){
  $this->db->select("*");
  $this->db->from('fis_query');
  $this->db->where('user_id',$this->session->userdata('id'));
  $this->db->order_by("id", "desc");
  $this->db->limit($limit, $offset);
  $query = $this->db->get();
  return $query->result();
 }

 function totalQuery(){
  return $this->db->count_all_results('fis_query');
 }






function category_count()
  { 
  $sql = "select count(fb.tag) as cattotal,fb.tag from fis_blog fb  group by fb.tag ";
  $query = $this->db->query($sql);
   if($query->num_rows() > 0)
    {
      return $query->result_array();
	}else{
	    return false;
	}
  }
 
 
 function result_userfiles($id)
  { 
  
   $this->db->select('*');  
   $this->db->from('fis_users as u');
   $this->db->join('fis_files as uf', 'u.id = uf.user_id', 'inner');  
   $this->db->where('u.id',$id);
   //$this->db->order_by("ui.id", "desc");
   $query = $this->db->get();
   return  $query->result_array();
      
  } 
 
 
 
 function getcountry()
     {
        $this -> db ->select('*');
        $query = $this ->db ->get('countries');
        return $query->result();
     }


  function getstate($country_id='')
     {
        $this ->db ->select('*');
        $this ->db ->where('country_id', $country_id);
        $query =$this->db ->get('states');
        return $query->result();
     }
    
	
   function getcity($state_id='')
     {
        $this ->db->select('*');
        $this ->db->where('state_id', $state_id);
        $query = $this ->db->get('cities');
        return $query->result();
     }
 
 
 
 
 public function data_insert($table,$data)
	{		
		   $query = $this->db->insert($table, $data); 
		   $id = $this->db->insert_id();
		   return $id;			
	}
  
  public function data_delete($attribute_name, $attribute_value, $table_name){
		$this->db->where($attribute_name, $attribute_value);
		$this->db->delete($table_name);
		return true;
	}
	
  public function data_update($whereArray, $table, $update_array){
		
		if(is_array($whereArray)){
			foreach ($whereArray as $key => $value){
				$this->db->where($key, $value);
			}
		} 
		$this->db->update($table, $update_array);
		return true;
/*		if($this->db->affected_rows())
			return true;
		else
			return false;	 
*/	}

 public function get_account($USER_ID)
    {
        $this->db->select()->from('TRN_USER');
        $this->db->where('user_id', $USER_ID);

        $query = $this->db->get();

        return $query->result_array();
    }
 
 
 
 function select($table, $where ='')
     {
        $sql = "SELECT * FROM $table";
		if(!empty($where)){
		   $sql .= " $where";
		}
		
		$query = $this->db->query($sql);
        if($query->num_rows()>0)
        {
            return $query->result_array();
        }
        else{
            return false;
        }
    }

}
?>