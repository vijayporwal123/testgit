<?php  $this->load->view('header');?>

<div id="myCarousel" class="carousel slide" data-ride="carousel"> 
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
    <li data-target="#myCarousel" data-slide-to="1"></li>
    <li data-target="#myCarousel" data-slide-to="2"></li>
  </ol>
  
  <div class="carousel-inner">
    <div class="item active"> <img src="<?php echo base_url(); ?>assets/front_end/images/slider.jpg" style="width:100%" alt="First slide">
      <div class="container">
        <div class="carousel-caption">
         <h2><span class="change-color">Be Successful, It's easy!</span></h2>
<p>Dummy Text Dummy Text Dummy Text</p>
        </div>
      </div>
    </div>
    
    <div class="item"> <img src="<?php echo base_url(); ?>assets/front_end/images/slider-2.jpg" style="width:100%" data-src="" alt="Second    slide">
      <div class="container">
        <div class="carousel-caption">
            <h2><span class="change-color">Be Successful, It's easy!</span></h2>
          <p>Dummy Text  Dummy Text Dummy Text</p>
        </div>
      </div>
    </div>
    
    <div class="item"> <img src="<?php echo base_url(); ?>assets/front_end/images/slider-3.jpg" style="width:100%" data-src="" alt="Third slide">
      <div class="container">
        <div class="carousel-caption">
          <h2><span class="change-color">Be Successful, It's easy!</span></h2>
          <p>Dummy Text Dummy Text Dummy Text</p>
       </div>
      </div>
    </div>
  </div>
  
  <a class="left carousel-control" href="#myCarousel" data-slide="prev"><span class="glyphicon glyphicon-chevron-left"></span>
</a> <a class="right carousel-control" href="#myCarousel" data-slide="next"><span class="glyphicon glyphicon-chevron-right"></span></a> </div>

<!-- Template Slider End -->

<div id="tp-select-opt" class="tp-select-opt"><!-- Products start-->
  <div class="container">
    <div class="row">
      <div class="col-md-12 tp-title"><!-- section title-->
        <h1>Behind success, is a brillient consultants!</h1>
      </div>
      
      </div>
      <div class="row">
        <div class="col-md-6 insurance-block">
          <div class=""> <i class="fa fa-eye"></i>
            <h2><a href="#">Vision</a></h2>
            <p> Dummy Text  Dummy Text  Dummy Text  Dummy Text  Dummy Text  Dummy Text  Dummy Text  Dummy Text   </p>
            <a href="#" class="btn tp-btn tp-btn-orange"> Read More</a> </div>
        </div>
        <div class="col-md-6 agent-block">
          <div class=""><i class="fa fa-dot-circle-o "></i>
            <h2><a href="#">Mission </a></h2>
            <p> Dummy Text  Dummy Text  Dummy Text  Dummy Text  Dummy Text  Dummy Text  Dummy Text  Dummy Text   </p>
            <a href="#" class="btn tp-btn tp-btn-orange"> Read More</a> </div>
        </div>
      </div>
    
  </div>
</div>
<!-- /.Select option close-->
<div id="tp-product" class="tp-product section-space"><!-- Products start-->
  <div class="container">
    <div class="row">
      <div class="col-md-12 tp-title"><!-- section title-->
        <h1>FISCON, COUNTS EVERYTHING!</h1>
        
      </div>
      </div>
<div id="product">
        <div class="col-md-12 product-thumb item">
          <div class="grey-box">
            <h2><a href="#">Retail Assets Consumer Loan</a></h2></div>
            </div>
            <div class="col-md-12 product-thumb item">
          <div class="grey-box">
            <h2><a href="#">Working Capital Services</a></h2></div>
        </div>
        <div class="col-md-12 product-thumb item">
          <div class="grey-box">
            <h2><a href="#">Project Finance Services</a></h2></div>
        </div>
        <div class="col-md-12 product-thumb item">
          <div class="grey-box">
            <h2><a href="#">Agriculture Loan &nbsp;  Services</a></h2></div>
        </div>
        <div class="col-md-12 product-thumb item">
          <div class="grey-box">
            <h2><a href="#">Government Subsidies and Schemes</a></h2></div>
        </div>
      </div>
  </div>
</div>
<!-- /.Products close-->
<div id="tp-latest-news" class="tp-latest-news section-space"><!-- template news -->
  <div class="container">
    <div class="row">
      <div class="col-md-12 tp-title">
        <h1>Latest Updates</h1>
      </div>
    </div>
    <div class="row">
      
      
	<?php 
    if(!empty($show_news)){
    $i= 1;
    foreach($show_news as $key =>$val){
    ?>
    <div class="col-md-4 thumb-box">                        
<!-- thumb box-->
<div class="tp-pic"><!-- blog pic --> 
<!--<a href="#"><img src="<?php echo base_url(); ?>news/front_end/images/blog-pic.jpg" alt=""></a> </div>
-->       
   <?php
    if(!empty($val['image'])){?>
    <a href="<?php echo base_url();?>front/news_details/<?php echo $val['id']; ?>"><image src="<?php echo base_url();?>news/<?php echo $val['image']; ?>" style="width:360px; height:241px;" alt=""></a>      
    <?php
    }else{?>                
    <a href="<?php echo base_url();?>front/news_details/<?php echo $val['id']; ?>"><image src="<?php echo base_url();?>uploads/imageNotFound.jpg"  style="width:360px; height:241px;" alt=""></a>
    <?php
    }
    ?>    
</div>  
        <!-- /.blog pic -->
        <div class="thumb-info"><!-- thumb info -->
          <h2><?php echo substr($val['title'],0,22); ?></h2>
          <p> <?php echo substr($val['news'],0,110); ?>&nbsp;&nbsp;<a href="<?php echo base_url();?>front/news_details/<?php echo $val['id']; ?>" class="btn tp-btn tp-btn-orange"> Read More</a> </p>
          <div class="tp-meta"><!-- meta --> 
            <span class="meta-date">Posted on <a href="#"><?php echo date('d-M-Y',strtotime($val['create_date'])); ?></a></span> </div>
          <!-- /.meta --> 
        </div>
        <!-- thumb info --> 
        </div>
		<?php
        }
        }else{
        ?>   
        <div>
        <p>No News Found</p>
        </div>
      <?php
		}
		?>
      </div>
      
      <?php /*?><!-- /.thumb box-->
      <div class="col-md-4 thumb-box"><!-- thumb box-->
        <div class="tp-pic"><!-- blog pic --> 
          <a href="#"><img src="<?php echo base_url(); ?>assets/front_end/images/blog-pic-1.jpg" alt=""></a> </div>
        <!-- /.blog pic -->
        <div class="thumb-info"><!-- thumb info -->
          <h2><a href="#">Post Heading Title</a></h2>
          <p> Dummy Text  Dummy Text  Dummy Text  Dummy Text  Dummy Text  Dummy Text  Dummy Text  Dummy Text   </p>
          <div class="tp-meta"><!-- meta --> 
            <span class="meta-date">Posted on <a href="#">May 1,2016</a></span> </div>
          <!-- /.meta --> 
        </div>
        <!-- /.thumb info --> 
      </div>
      <!-- /.thumb box-->
      <div class="col-md-4 thumb-box"><!-- thumb box-->
        <div class="tp-pic"><!-- blog pic --> 
          <a href="#"><img src="<?php echo base_url(); ?>assets/front_end/images/blog-pic-2.jpg" alt=""></a> </div>
        <!-- /.blog pic -->
        <div class="thumb-info"><!-- thumb info -->
          <h2><a href="#">Title for Blog Heading </a></h2>
          <p> Dummy Text  Dummy Text  Dummy Text  Dummy Text  Dummy Text  Dummy Text  Dummy Text  Dummy Text   </p>
          <div class="tp-meta"><!-- meta --> 
            <span class="meta-date">Posted on <a href="#">May 3,2016</a></span> </div>
          <!-- /.meta --> 
        </div>
        <!-- /.thumb info --> 
        <!-- /.thumb box--> 
      </div><?php */?>
    </div>
  </div>
</div>
<!-- /.template news -->

<div class="tp-testimonial-two section-space"><!-- Testimonial -->
  <div class="container">
    <div class="row">
      <div class="col-md-12 circle-icon text-center"><!-- circle icon -->
        <p><span class="quote-circle blue-quote"><i class="fa fa-quote-left"> </i> </span> <h1>Testimonials</h1> <span class=" quote-circle blue-quote"><i class="fa fa-quote-right"></i></span></p>
      </div>
      <!-- /.circle icon -->
    </div>

<div id="testimonial">
        <div class="col-md-12 quote-ct item"><!-- quote content -->
          <p class="quote-text">"I have only good things to say, service was very good and professional. I will refer this Fiscon to everyone I know. Keep up the good work. In this economy great and professional service is hard to find."</p>
          <p class="name">Akhilesh Gupta</p>
          <span class="location">Mumbai,India</span> </div>
        <!-- /.quote content -->
        <div class="col-md-12 quote-ct item"><!-- quote content -->
          <p class="quote-text">"I have only good things to say, service was very good and professional. I will refer this Fiscon to everyone I know. Keep up the good work. In this economy great and professional service is hard to find."</p>
          <p class="name">Akhilesh Gupta</p>
          <span class="location">Mumbai,India</span> </div>
        <!-- /.quote content -->
        <div class="col-md-12 quote-ct item"><!-- quote content -->
          <p class="quote-text">"I have only good things to say, service was very good and professional. I will refer this Fiscon to everyone I know. Keep up the good work. In this economy great and professional service is hard to find."</p>
          <p class="name">Akhilesh Gupta</p>
          <span class="location">Mumbai,India</span> </div>
        <!-- /.quote content -->
        <div class="col-md-12 quote-ct item"><!-- quote content -->
          <p class="quote-text">"I have only good things to say, service was very good and professional. I will refer this Fiscon to everyone I know. Keep up the good work. In this economy great and professional service is hard to find."</p>
          <p class="name">Akhilesh Gupta</p>
          <span class="location">Mumbai,India</span> </div>
        <!-- /.quote content -->
        <div class="col-md-12 quote-ct item"><!-- quote content -->
          <p class="quote-text">"I have only good things to say, service was very good and professional. I will refer this Fiscon to everyone I know. Keep up the good work. In this economy great and professional service is hard to find."</p>
          <p class="name">Akhilesh Gupta</p>
          <span class="location">Mumbai,India</span> </div>
        <!-- /.quote content --> 
      </div>

  </div>
</div>
<!-- /.Testimonial -->
<!-- Newsletter -->
<div class="tp-newsletter-section">
  <div class="container">
    <div class="row">
      <div class="col-md-5">
       <!-- <p class="name">Subscribe to Our Newsletter</p>
        <p>Dummy Text  Dummy Text  Dummy Text  Dummy Text  Dummy Text</p>-->
        <div class="newsletter-form">
          <!--<form method="post" action="newsletter.php" role="form">
            
            <div class="form-group">
              <div class="row">
                <label class="col-md-4 sr-only control-label" for="newsletter">Newsletter</label>
                <div class="col-md-12">
                  <input id="newsletter" name="newsletter" type="email" placeholder="Your E-mail id" class="form-control input-md" required>
                </div>
              </div>
            </div>
            <input type="submit" value="Subscribe" class="btn tp-btn tp-btn-orange" />
          </form>-->
        </div>
        <!-- /input-group --> 
      </div>
      <!-- Newsletter form -->
      <div class="col-md-offset-1 col-md-5 select-products"><!-- select products -->
        <p class="name">Select A Service For Quote</p>
        <div class="row">
          <div class="col-md-6">
            <ul>
              <li><i class="fa fa-paper-plane"></i> <a href="#">Consumer Loan</a></li>
              <li><i class="fa fa-paper-plane"></i> <a href="#"> Working Capital</a></li>
              <li><i class="fa fa-paper-plane"></i> <a href="#">Project Finance</a></li>
            </ul>
          </div>
          <div class="col-md-6">
            <ul>
              <li><i class="fa fa-paper-plane"></i> <a href="#">Agricultire Loan</a></li>
              <li><i class="fa fa-paper-plane"></i> <a href="#"> Government Subsidies</a></li>
              <li><i class="fa fa-paper-plane"></i> <a href="#"> Other</a></li>
            </ul>
          </div>
          <div class="col-md-12"> <a href="#" class="btn tp-btn tp-btn-orange">Get A Quote</a> </div>
        </div>
      </div>
      <!-- /.select products --> 
    </div>
  </div>
</div>

<?php  $this->load->view('footer');?>

