<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Blog extends CI_Controller{

 public function __construct(){
  parent::__construct();
  $this->load->model('admin/adminmodel');
  $this->load->library(array('form_validation','session','email'));
  $this->load->helper(array('url','html','form'));
 
 }


public function bloglist(){

$where  = "ORDER BY id DESC ";
$data['show_bloglist'] = $this->adminmodel->select('fis_blog',$where);
$this->load->view('admin/bloglist',$data);

}

public function addblog(){
$this->load->view('admin/addblog');
}



public function blogsubmit(){
		//if (isset($_POST['submit'])){
		
            $this->form_validation->set_rules('title', 'Title', 'required');
            $this->form_validation->set_rules('desc', 'Description', 'required');
		    $this->form_validation->set_rules('tags', 'Tags', 'required');
            $this->form_validation->set_error_delimiters('<div class="error">', '</div>');
			$this->form_validation->set_message('required', 'Enter %s');



$upload_dir = base_url();
$upload_dir= 'uploads/';

	$file_name = $_FILES['photo']['name'];
	
	if(!empty($file_name)){
	$temp_name = $_FILES['photo']['tmp_name'];
		
	$ext = @pathinfo($file_name, PATHINFO_EXTENSION);
	$file_name= time().rand(1000,99999).'.'.$ext;
   
	$file_path = $upload_dir.$file_name; 
	@move_uploaded_file($temp_name, $file_path);
	}else{
	$file_name = '';
	}

		// check for validation
	     	if ($this->form_validation->run() == FALSE){ 
		  $msg = array('msg' =>validation_errors(),'res' => 0);
			$this->session->set_userdata($msg);
		     redirect('admin/blog/addblog');
		     }
		
		else{
		
		$data = array(
			'title' => $this->input->post('title'),
			'desc' => $this->input->post('desc'),
			'tag' => $this->input->post('tags'),
			'post_date'=>date('Y-m-d'),
			//'Youtube_url'=>$this->input->post('youtube'),
			'photo'=>$file_name,
			'status'=>'1'
		);
		
	$result = $this->adminmodel->data_insert('fis_blog',$data);
	//$msg=array('msg' =>'Your data inserted Successfully..');
	//$this->session->set_userdata($msg);
	
		$msg= $this->session->set_flashdata('message', 'Your data inserted Successfully..');

	//$msg = array('msg' =>'<strong>Success!</strong> Your Account is created.','res' => 1);
	
	if($result){
    redirect('admin/blog/bloglist',$msg);
	}
}
	
	
}

//edit action 
public function editblog() {
   
	   $id =  $this->uri->segment(4) ? $this->uri->segment(4) : 0;
	
	    $blog = 'fis_blog';
		$where  = "where id = $id  ";
	    $data['blogdata'] = $this->adminmodel->select($blog,$where);	
       $this->load->view('admin/editblog',  $data);
	
    
    }


public function updateblog(){
	//$admin_url = $this->config->item('admin_url');
	 	   $id =  $this->uri->segment(4) ? $this->uri->segment(4) : 0;

		

	if($_POST){
	 
	 
	 $title = $this->input->post("title");
	 $desc = $this->input->post("desc");
	 $tags = $this->input->post("tags");
	 $status = $this->input->post("status");
	 //$youtube = $this->input->post("youtube");	 
	 
	 
	 	 
$upload_dir = base_url();
$upload_dir= 'uploads/';

	$file_name = $_FILES['photo']['name'];
	
	if(!empty($file_name)){
	$temp_name = $_FILES['photo']['tmp_name'];
		
	$ext = @pathinfo($file_name, PATHINFO_EXTENSION);
	$file_name= time().rand(1000,99999).'.'.$ext;
   
	$file_path = $upload_dir.$file_name; 
	@move_uploaded_file($temp_name, $file_path);
	}
	
	
	if(!empty($file_name)){
	$data = array('title' => $title,
					'desc' => $desc,
							   'tag' =>$tags,
							    'photo' =>$file_name,
							  // 'Youtube_url' =>$youtube,
							     'status' =>$status
							   );		
	
		} else{
		$data = array('title' =>$title,
					'desc' => $desc,
							  'tag'=>$tags,
							    //'Youtube_url'=>$youtube,
							     'status' =>$status
							   );
		}
				
		
		//print_r($data); 
	 $blog =  'fis_blog';
	 $id1 = $this->adminmodel->data_update(array("id"=>$id),$blog,$data);
		//print_r($id1);
    $msg1=$this->session->set_flashdata('message', 'Your data updated Successfully..');

			
		 if($id1){
		    redirect('admin/blog/bloglist',$msg1);
			
		}
	
	}

}

 

}//last end
?>
