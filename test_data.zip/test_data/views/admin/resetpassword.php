<?php //include('header.php');
$this->load->view('admin/header');
error_reporting(0);
?>
<style>
.error{color:#FF0000;
}
</style>

<body>

    <div class="container">
        <div class="row">
            <div class="col-md-4 col-md-offset-4">
                <div class="login-panel panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Reset Password</h3>
                    </div>
                    <div class="panel-body">
<form role="form" action="<?php echo base_url(); ?>admin/login/update_pass/<?php echo $this->uri->segment(4) ? $this->uri->segment(4) : 0;?>" method="post">
                        
                            <fieldset>
                                <div class="form-group">
                                   <label>*New Password</label>
          <input type="password" name="newpassword" class="form-control" pattern=".{8,}" onChange="this.setCustomValidity(this.validity.patternMismatch ? 'Must have at least 8 characters' : ''); if(this.checkValidity()) form.password.pattern = this.value;" required>                          
                                                                        
                                </div>
                                
                                <div class="form-group">
                           <label>*Confirm Password</label>                                
 <input type="password" name="password" class="form-control" pattern=".{8,}" onChange="this.setCustomValidity(this.validity.patternMismatch ? 'Please enter the same Password as above' : '');" required>
                                      </div>
                               
                               <div class="form-group">
<button type="submit" name="submit" class="btn btn-sm btn-primary ">Submit</button>
<a href="<?php echo base_url(); ?>login/index"><button type="button" name="cancel" class="btn btn-sm btn-danger ">Cancel</button></a>
</div>                                
</fieldset>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

 
</body>

</html>