<?php
$this->load->view('admin/header');
?>

<?php
$this->load->view('admin/session_check');

?>
<body>

<div id="wrapper">

<!-- Navigation -->
<?php 
$this->load->view('admin/navigation');
?> 

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">           
        <?php if($this->session->flashdata('message')){?>
		  <div class="alert alert-success">  
           <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>    
		    <?php echo $this->session->flashdata('message')?>
		  </div>
		<?php } ?>
        
                    <h3 class="page-header">Blog List<p style="float:right;"><a href="<?php echo base_url(); ?>admin/blog/addblog"><button type="button" class="btn btn-primary btn-sm">Add Blog</button></a></p></h3>
                    
                  
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                           Blog List
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="dataTable_wrapper">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>S.No</th>
                                            <th>Post Date</th>
                                            <th>Title</th>
                                            <th>Description</th>
                                            <th>Tags</th>
                                           <!-- <th>Youtube</th>-->
                                            <th>Image</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php 
				if(!empty($show_bloglist)){
				 $i= 1;
				 foreach($show_bloglist as $key =>$val){
			  ?>
                                    
                                        <tr class="odd gradeX">
                                            <td><?php echo $i++; ?></td>
                                            <td><?php echo date('d-m-Y',strtotime($val['post_date'])); ?></td>
                                            <td><?php echo $val['title']; ?></td>
                                            <td><?php echo substr($val['desc'],0,70); ?></td>
                                            <td><?php echo $val['tag']; ?></td>
                                            <!--<td>
                                            <?php //if(!empty($val['youtube_url'])){
											?>
 <embed width="100" height="100" src="<?php //echo $val['youtube_url']; ?>" frameborder="0" allowfullscreen></embed>	
                                        <?php
										//}
										//else { 
?>                                            
<image src="<?php //echo base_url();?>uploads/default.png" style="width:100px; height:100px;" type="image/jpg">
<?php
//}		                            
?>                                            
</td>-->
 
                                            
<td>
<?php											
$file_name=$val['photo'];

$tmp = explode('.', $file_name);
$file_extension = end($tmp);

if($file_extension=="mp4" || $file_extension=="3gp" || $file_extension=="ogg" || $file_extension=="avi" || $file_extension=="mpeg" || $file_extension=="mkv")
{
//echo "its an mp4 movie";
?>
<video width="150" height="150" controls>
	<source src="<?php echo base_url();?>uploads/<?php echo $val['photo']; ?>" type="video/mp4">
	</video> 

<?php
}else if($file_extension=="gif" || $file_extension=="jpeg" || $file_extension=="png" || $file_extension=="jpg"){

/*if(strtolower(end(explode(".",$ff))) =="jpg"){*/
?>
<image src="<?php echo base_url();?>uploads/<?php echo $val['photo']; ?>" style="width:150px; height:150px;" >
<?php
}else{
?>
<image src="<?php echo base_url();?>uploads/imageNotFound.jpg" style="width:150px; height:150px;" type="image/jpg">
<?php
}
?>

</td>

<td ><?php if($val['status'] == '1'){ 
?>
<span class="label label-sm label-success">Active</span>
<?php
}else{
?>
<span class="label label-sm label-danger">De Active</span>
<?php
}
?>
</td>

<td>
<a class="fa fa-pencil" href="<?php echo base_url(); ?>admin/blog/editblog/<?php echo $val['id']; ?>" onClick="return confirm('Are you sure you want to edit this item?');"></a>&nbsp;
</td>
</tr>
<?php
     }
  }
?>                                       
</tbody>
</table>

</div>
<!-- /.table-responsive -->
                            
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="<?php echo base_url(); ?>assets/bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo base_url(); ?>assets/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="<?php echo base_url(); ?>assets/bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="<?php echo base_url(); ?>assets/bower_components/datatables/media/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/bower_components/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/bower_components/datatables-responsive/js/dataTables.responsive.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="<?php echo base_url(); ?>assets/dist/js/sb-admin-2.js"></script>

    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
    <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
                responsive: true
        });
    });
    </script>

</body>

</html>
