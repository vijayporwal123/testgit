<?php  $this->load->view('header');?>
<?php
if(!empty($blog_details)){
	
$bid1=$blog_details[0]['id'];
//$tid=$blog_details[0]['id'];
$bid=$this->uri->segment(3) ? $this->uri->segment(3) : 0;	
}
	
	

/*$id=$this->uri->segment(3) ? $this->uri->segment(3) : 0; 
$sql13="select * from fis_blog where id='".$id."' ";
$result13=mysql_query($sql13);
$row12=mysql_fetch_array($result13);*/
//echo "<pre>";
//print_r($row12);die; 
?>		  		 
<div class="tp-page-header"><!-- full page header -->
  <div class="container">
    <div class="row">
      <div class="col-md-7">
        <div class=""> <!-- page header  -->
        <br />
          <h2>Blog Detail</h2>
        </div>
        <!-- page header  --> 
      </div>
    </div>
  </div>
</div>

  <?php if($this->session->flashdata('message')){?>
		  <div class="alert alert-success">  
           <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>    
		    <?php echo $this->session->flashdata('message')?>
		  </div>
		<?php } ?>	
        
      

<!-- /.full page header-->
<div class="tp-breadcrumb">
  <div class="container">
    <div class="row">
      <div class="col-md-8">
        <ol class="breadcrumb">
          <li><a href="<?php echo base_url(); ?>front/index">Home</a></li>
          <li class="active">Blog Detail</li>
        </ol>
      </div>
      <!--<div class="col-md-4">
        <div class="font-option"> Select font size : <a href="#" id="incfont">A+</a><a href="#" id="decfont">A-</a></div>
      </div>-->
    </div>
  </div>
</div>
<div class="main-container" id="main-container"><!--Main container start-->
  <div class="tp-blog-details" id="tp-blog-details"><!-- blog details -->
    <div class="container">
      <div class="row">
        <div class="col-md-8 tp-blog-left">
          <div class="row">
           <?php 
if(!empty($blog_details)){
// $i= 1;
//foreach($show_blog as $key =>$val){
?>
<div class="col-md-12 tp-blog-post"><!-- blog post start-->
<h1><?php echo $blog_details[0]['title']; ?></h1>
<p class="meta"> <span class="meta-date"><i class="fa fa-calendar"></i><?php echo date('d-M-Y',strtotime($blog_details[0]['post_date'])); ?></span><!--<span class="meta-comments"> <i class="fa fa-comments"></i><a href="#">(20) Comments</a></span> --> </p>
                  
                  
<?php											
$file_name=$blog_details[0]['photo'];

$tmp = explode('.', $file_name);
$file_extension = end($tmp);

if($file_extension=="mp4" || $file_extension=="3gp" || $file_extension=="ogg" || $file_extension=="avi" || $file_extension=="mpeg" || $file_extension=="mkv")
{
//echo "its an mp4 movie";
?>
<video  controls  height="400" width="400">
	<source src="<?php echo base_url();?>uploads/<?php echo $blog_details[0]['photo']; ?>" type="video/mp4" alt="" >
	</video> 

<?php
}else if($file_extension=="gif" || $file_extension=="jpeg" || $file_extension=="png" || $file_extension=="jpg"){

/*if(strtolower(end(explode(".",$ff))) =="jpg"){*/
?>
<a href="#"><image src="<?php echo base_url();?>uploads/<?php echo $blog_details[0]['photo']; ?>"  alt="" class="img-responsive"></a>
<?php
}else{
?>
<image src="<?php echo base_url();?>uploads/imageNotFound.jpg"  type="image/jpg" alt="" class="img-responsive">
<?php
}
?>                                      
<p><?php echo $blog_details[0]['desc']; ?></p>
</div>
<?php
}else{
?>
<div>
<p>No Blog Post Found</p>
</div>    
<?php
}
?>                          
<!-- /.blog post start--> 
</div>
          <!--<div class="row">
            <div class="col-md-12 author-block">
              <div class="author-bg">
                <div class="row">
                  <div class="col-md-3 auhtor-thumb"><a href="#"><img src="images/author-pic.jpg" alt="author profile" class="img-responsive"></a></div>
                  <div class="col-md-9 author-dec">
                    <h3><a href="#" class="name-author">Nishant Shah (Author)</a></h3>
                    <p>Lorem Ipsum which looks reasona therefore always free from repetition, injected humour, or non-characteristic words etc.</p>
                    <a href="#" class="btn tp-btn tp-btn-orange">All posts by Mark Mathon</a> </div>
                </div>
              </div>
            </div>
          </div>-->
          <!--<div class="row pre-next-post">
            <div class="col-md-6 blog-prv-link"> <a href="#"><i class="fa fa-long-arrow-left"></i> Previous Post</a>
              <h3><a href="#">Previous Heading title for post</a></h3>
            </div>
            <div class="col-md-6 blog-nxt-link"> <a href="#">Next Post <i class="fa fa-long-arrow-right"></i></a>
              <h3><a href="#">Previous Heading title for post</a></h3>
            </div>
          </div>-->
          <div class="row">
            <div class="col-md-12 blog-comments">
              <h2>Comments</h2>
              <div class="comments">
                <!--<div class="media"><!-- comments block start
                  <a class="media-left" href="#"> <img src="images/comments-user.jpg" alt="" class="img-circle"> </a>
                  <div class="media-body">
                    <h3 class="media-heading"><a href="#">Michelle J. Parsons</a>
                    <span class="cmt-meta"><i class="fa fa-calendar"></i> 10 May, 2015</span>
                    <small>2 Min Ago</small>
                    </h3>
                    <p>Cras sit amet nibh liberoin gravida nulla. Nulla vel metus scelerisque ante sollicitudin commodo. Cras purus odio, vestibulum in vulputate atin faucibus.</p>
                    <a href="#" class="btn tp-btn tp-btn-grey">Reply <i class="fa fa-mail-forward"></i></a> </div>
                </div>-->
                <!-- comments block end-->
                                
<div class="media"><!-- comments block start--> 
<a class="media-left" href="#"> <img src="" alt="" class="img-circle"> </a>
<div class="media-body">
<?php
			  
function get_time_ago( $time )
{
    $time_difference = time() - $time;

    if( $time_difference < 1 ) { return 'less than 1 second ago'; }
    $condition = array( 12 * 30 * 24 * 60 * 60 =>  'year',
                30 * 24 * 60 * 60       =>  'month',
                24 * 60 * 60            =>  'day',
                60 * 60                 =>  'hour',
                60                      =>  'minute',
                1                       =>  'second'
    );

    foreach( $condition as $secs => $str )
    {
        $d = $time_difference / $secs;

        if( $d >= 1 )
        {
            $t = round( $d );
            return ' ' . $t . ' ' . $str . ( $t > 1 ? 's' : '' ) . ' ago';
        }
    }
}		  
		  
date_default_timezone_set('Asia/Kolkata');			  
$sql3="select * from comment where post_blog_id='".$bid."' and status='1' order by cid desc  ";
$result3=mysql_query($sql3);
if(mysql_num_rows($result3)>0){
while($row3=mysql_fetch_array($result3)){
?>          
    <!-- <h3 class="media-heading"><a href="#">Nareema nair</a>
    <span class="cmt-meta"><i class="fa fa-calendar"></i> 13 May, 2015</span>
    <small>2 Min Ago</small></h3>
    <p>Cras sit amet nibh liberoin gravida nulla. Nulla vel metus scelerisque ante sollicitudin commodo. Cras purus odio, vestibulum in vulputate atin faucibus.</p>
    <a href="#" class="btn tp-btn tp-btn-grey">Reply <i class="fa fa-mail-forward"></i></a>-->
    <div class="media nested-media">
    <!-- Nested comments block start--> 
    <a class="media-left" href="#"><img src="<?php echo base_url();?>assets/front_end/images/comments-user-2.jpg" alt="" class="img-circle"> </a>
    <div class="media-body">
    <h3 class="media-heading"><a href="#"><?php echo $row3['name'];?></a>
    <span class="cmt-meta"><i class="fa fa-calendar"></i><?php echo date('d-M-Y',strtotime($row3['create_date']));?></span>
    <small><?php $date=$row3['create_date'];
  echo get_time_ago( strtotime($date));?></small>
    </h3>
<p><?php echo $row3['comment'];?>  </p>
  <!--<a href="#" class="btn tp-btn tp-btn-grey">Reply <i class="fa fa-mail-forward"></i></a>-->
   </div>
    </div>
   <!-- Nested  comments block end-->                     
<?php
}
}else{?>
<div>
<p>No Comments Found</p>
</div>
<?php
}
?>  
                    
                       
</div>
</div>
                <?php /*?><!-- comments block end-->
                <div class="media"><!-- comments block start--> 
                  <a class="media-left" href="#"> <img src="images/comments-user.jpg" alt="" class="img-circle"> </a>
                  <div class="media-body">
                    <h3 class="media-heading"><a href="#">Jenish Deptorn</a>
                    <span class="cmt-meta"><i class="fa fa-calendar"></i> 19 Oct, 2014</span>
                    <small>2 Min Ago</small>
                    </h3>
                    <p>Pellentesque nisi ante, porta a sem non, scelerisque commodo ex. Aenean et auctor lorem. </p>
                    <a href="#" class="btn tp-btn tp-btn-grey">Reply <i class="fa fa-mail-forward"></i></a> </div>
                </div>
                <!-- comments block end--> <?php */?>
                
              </div>
            </div>
          </div>
<style>
.error{color:#FF0000;
}
</style>
          <div class="row">
            <div class="col-md-12 leave-comments">
              <h2>Leave Comments</h2>
              
<form role="form" class="leave-form" method="post" action="<?php echo base_url();?>front/commentsubmit">

 <p><span class="error">* required field.</span></p>     

					  
<input type="hidden" name="tagid" value="<?php //echo $this->uri->segment(3) ? $this->uri->segment(3) : 0;	
 ?>">
<input type="hidden" name="blog_id" value="<?php echo $this->uri->segment(3) ? $this->uri->segment(3) : 0; ?>">

                <div class="form-group">
                  <label class="control-label" for="exampleInputPassword1">Name<span class="error">* </span></label>
                  <input type="text"  name="uname" class="form-control" id="exampleInputPassword1" placeholder="Name" required>
             <?php echo form_error('uname'); ?>

                </div>
				
                <div class="form-group">
<label class="control-label" for="exampleInputEmail2">Email address<span class="error">* </span></label>
<input type="email"  name="email" class="form-control" id="exampleInputEmail2" placeholder="E-Mail" required>
<?php echo form_error('email'); ?>
                </div>
				
                <div class="form-group">
                  <label class="control-label">Comments<span class="error">* </span></label>
                  <textarea class="form-control textarea"  name="comments" rows="8" placeholder="Comment:"></textarea>
<?php echo form_error('comments'); ?>
                </div>
                
                
               <div class="form-group">
<label class="control-label" >Captcha<span class="error">* </span></label>
<div class="g-recaptcha" data-sitekey="6LcntyUTAAAAAMiyaegXBpvPB4OhAcMFGm4mm9AE"></div>
  <?php echo form_error('g-recaptcha-response'); ?>
</div> 
                               
                
<button type="submit"  name="submit" class="btn tp-btn tp-btn-orange">Submit Comments</button>
				
              </form>
            </div>
          </div>
          
          
        </div>
        <div class="col-md-4 tp-blog-right"><!-- tp blog right -->
          <div class="row">
            <div class="col-md-12">
              <div class="widget search-widget"><!--search widget start-->
                <h2 class="widget-title">Search</h2>
                <form action="<?php echo base_url();?>front/blog_search" method="post">
                <div class="input-group"><!-- search input start -->
                  <input type="text" class="form-control" name="blog_name" placeholder="search blog by blog name or category">
                  <span class="input-group-btn">
                  <button class="btn btn-search" type="submit" name="submit"><i class=" fa fa-search "></i></button>
                  </span> </div></form>
                <!-- search input end --> 
              </div>
              <!--search widget end--> 
            </div>
<div class="col-md-12">
<div class="widget categories-widget"><!--Categories widget start-->
<h2 class="widget-title">Categories</h2>
<?php
$sql5="select count(fb.tag) as cattotal,fb.tag from fis_blog fb  group by fb.tag ";
$result5=mysql_query($sql5);
if(mysql_num_rows($result5)>0){
while($row5=mysql_fetch_array($result5)){
?>
                <ul class="angle-double-right">
                  <li><a href="<?php echo base_url(); ?>front/category_details/<?php echo $row5['tag'];?>"><?php echo $row5['tag'];?><span>(<?php echo $row5['cattotal'];?>)</span></a></li>
                 
                </ul>
                <?php
				}
				}else{?>
                <ul>
                <li>No Categories Found</li>
                </ul>
                <?php
				}
				?>
                
              </div>
              <!--Categories widget end--> 
            </div>
            <div class="col-md-12">
<div class="widget archive-widget"><!--Categories widget start-->
<h2 class="widget-title">Archive</h2>
<?php
$sql6="SELECT *,YEAR(post_date), MONTH(post_date), COUNT(id) as pid from fis_blog GROUP BY YEAR(post_date), MONTH(post_date) order by YEAR(post_date), MONTH(post_date) asc ";
$result6=mysql_query($sql6);
if(mysql_num_rows($result6)>0){
while($row6=mysql_fetch_array($result6)){
?>       
                <ul class="angle-double-right">
                  <li><a href="<?php echo base_url(); ?>front/archieve_details/<?php echo $row6['post_date'];?>"><?php echo date('M-Y',strtotime($row6['post_date']));?></a></li>
                </ul>
               <?php
			   }
			   }else{
			   ?> 
              <ul>
                <li>No Archive Found</li>
              </ul>
                <?php
				}
				?>  
                
              </div>
              <!--Categories widget end--> 
            </div>
            <div class="col-md-12">
              <div class="widget recent-post-widget"><!--Recent post widget start-->
                <h2 class="widget-title">Recent post</h2>
<?php
$sql1="select * from fis_blog  order by id desc limit 3 ";
$result1=mysql_query($sql1);
if(mysql_num_rows($result1)>0){
while($row1=mysql_fetch_array($result1)){
?>                               
                
                <ul>
                
                  <li>
                    
                    
<h3 class="recent-title"><a href="<?php echo base_url();?>front/blog"><?php echo $row1['title'];?></a></h3>
<span class="meta-date"><i class="fa fa-calendar"></i><?php echo date('d-M-Y',strtotime($row1['post_date'])); ?></span>
</li>
</ul>
<?php
    }
    }else{
    ?>
    <ul>
    <li>No Recent post Found</li>
    </ul>
    <?php
    }
    ?>                
    </div>
<!--Recent post widget end--> 
            </div>
            
            <div class="col-md-12">
              <div class="widget tags-widget"><!--Tags widget start-->
                <h2 class="widget-title">Tags</h2>
<?php
$sql7="select count(fb.tag) as cattotal,fb.tag from fis_blog fb  group by fb.tag ";
$result7=mysql_query($sql7);
if(mysql_num_rows($result7)>0){
while($row7=mysql_fetch_array($result7)){
?>       
<a href="<?php echo base_url(); ?>front/category_details/<?php echo $row7['tag'];?>" class="btn tp-btn tp-btn-grey"><?php echo $row7['tag'];?></a>
<?php
}
}else{?>
<p>No Tags Found</p>
<?php
}
?> </div>
<!--Categories widget end--> 
</div>
            
            
            
            
            
          </div>
        </div>
        <!-- /.tp blog right --> 
      </div>
    </div>
  </div><!-- /.blog details -->
</div>
<?php  $this->load->view('footer');?>
