<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Front extends CI_Controller {

public function __construct(){
  parent::__construct();
  $this->load->model('user_model');
  $this->load->library(array('form_validation','session','email'));
  $this->load->helper(array('url','html','form')); 
 }

	
public function index()
{
$where  = "ORDER BY id DESC limit 3 ";
$data['show_news'] = $this->user_model->select('fis_news',$where);
$this->load->view('index',$data);		
//$this->load->view('index');
}


public function blog()
{

$where  = "ORDER BY id DESC ";
$data['show_blog'] = $this->user_model->select('fis_blog',$where);
$this->load->view('blog',$data);
}



/*public function news(){

$where  = "ORDER BY id DESC ";
$data['show_news'] = $this->user_model->select('fis_news',$where);
$this->load->view('index',$data);
}
*/

public function news_details()
{
$id =  $this->uri->segment(3) ? $this->uri->segment(3) : 0;	
$table = 'fis_news';
$where  = "where id = '".$id."' ";
$data['news_details'] = $this->user_model->select($table,$where);	
$this->load->view('newsdetail',$data);
}



public function blog_search()
{
	
$blog_name = $this->input->post('blog_name');	
	
//$id =  $this->uri->segment(3) ? $this->uri->segment(3) : 0;	
$table = 'fis_blog';
$where  = "where title like '%".$blog_name."%' or tag='".$blog_name."' ";
$data['show_blog'] = $this->user_model->select($table,$where);	
$this->load->view('blog',$data);
}



public function blog_details()
{
$id =  $this->uri->segment(3) ? $this->uri->segment(3) : 0;	
$table = 'fis_blog';
$where  = "where id = '".$id."' ";
$data['blog_details'] = $this->user_model->select($table,$where);	
$this->load->view('blogdetail',$data);
}

public function category_details()
{
$tag =  $this->uri->segment(3) ? $this->uri->segment(3) : 0;	
$table = 'fis_blog';
$where  = "where tag = '".$tag."'  order by id desc";
$data['category_details'] = $this->user_model->select($table,$where);	
$this->load->view('category',$data);
}


public function archieve_details()
{
$arch =  $this->uri->segment(3) ? $this->uri->segment(3) : 0;	
$table1 = 'fis_blog';
$where1  = "where date_format(post_date, '%m%Y') = date_format('".$arch."', '%m%Y')";
$data['archieve_details'] = $this->user_model->select($table1,$where1);	
$this->load->view('archieve',$data);

}

public function careerform()
{
$this->load->view('careerform');
}

public function contactform()
{
$this->load->view('contact');
}

/*
function alpha_dash_space($str1)
{
    return ( ! preg_match("/^([-a-z_ ])+$/i", $str1)) ? FALSE : TRUE;
} 
*/


public function recaptcha($str='')
  {
    $google_url="https://www.google.com/recaptcha/api/siteverify";
    $secret='6LcntyUTAAAAABpV2GwR6JWXVigw0rJZ_UHaLJA';
    $ip=$_SERVER['REMOTE_ADDR'];
    $url=$google_url."?secret=".$secret."&response=".$str."&remoteip=".$ip;
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($curl, CURLOPT_TIMEOUT, 10);
    curl_setopt($curl, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.2.16) Gecko/20110319 Firefox/3.6.16");
    $res = curl_exec($curl);
    curl_close($curl);
    $res= json_decode($res, true);
    //reCaptcha success check
    if($res['success'])
    {
      return TRUE;
    }
    else
    {
      $this->form_validation->set_message('recaptcha', 'The reCAPTCHA field is telling me that you are a robot. Shall we give it another try?');
      return FALSE;
    }
  }


public function careersubmit(){
   error_reporting(0);        
  $this->form_validation->set_rules('firstname', 'First Name', 'trim|required|callback_alpha_dash_space|xss_clean');
  $this->form_validation->set_rules('lastname', 'Last Name', 'trim|required|xss_clean');
  $this->form_validation->set_rules('email', 'E-mail', 'trim|required|valid_email|xss_clean');
  $this->form_validation->set_rules('mobile_no', 'Mobile Number', 'trim|required|numeric|min_length[10]|max_length[10]|xss_clean');
  
  $this->form_validation->set_rules('quali', 'Qualification', 'trim|required|xss_clean');
  $this->form_validation->set_rules('applied_for', 'Applied For', 'trim|required|xss_clean');
  $this->form_validation->set_rules('g-recaptcha-response','Captcha','required|callback_recaptcha');

  $this->form_validation->set_error_delimiters('<div class="error">', '</div>');
  if($this->form_validation->run()==false){			
	$this->load->view('careerform'); 
}

else{


$upload_dir = base_url();
$upload_dir= 'attachement/';

	$file_name = $_FILES['cv']['name'];
	
	if(!empty($file_name)){
	$temp_name = $_FILES['cv']['tmp_name'];
	//$ext = @pathinfo($file_name, PATHINFO_EXTENSION);
	//$file_name= time().rand(1000,99999).'.'.$ext;
	$file_path = $upload_dir.$file_name; 
	@move_uploaded_file($temp_name, $file_path);
	}else{
	$file_name = '';
	}

	//if($result){
	$emailid = $this->input->post('email');
	$firstname = $this->input->post('firstname');
	$lastname = $this->input->post('lastname');
	$mobile_no = $this->input->post('mobile_no');
	$quali = $this->input->post('quali');
	$applied_for = $this->input->post('applied_for');

	if(!empty($emailid)){
				$config['mailtype'] = 'html';
				   $config['charset'] = 'iso-8859-1';
				   $config['priority'] = 1;
				   $this->email->initialize($config);
				   $this->email->clear();
				   $message="<html>
						<head>
								<title>Career Attachement</title>
								</head>
								<body>";
							$message .= "Hello ".$firstname." ".$lastname."<br/>
								<br/>";
							
							$message .="</body></html>";
							$this->email->from($emailid, 'Fiscon Consultant PVT LTD');
							$this->email->to('vijay.porwal@oxygenwebtech.com');
							$this->email->message($message);
							$this->email->subject("".ucwords($firstname)." Job Applied for ".$applied_for." ");
							$this->email->attach($file_name);
							$mail1=$this->email->send();


$message1="<html>
						<head>
								<title>Career Attachement</title>
								</head>
								<body>";
							$message1 .= "Hello ".$firstname." ".$lastname."<br/>
								<br/>";
								
$message1 .= "<p>Thank You for applying at Fiscon Consultant PVT LTD! Re: apply for '".$applied_for."'</p><br/>";			
							
							$message1 .="</body></html>";
							$this->email->from('info@fiscon.in', 'Fiscon Consultant PVT LTD');
							$this->email->to($emailid);
							$this->email->message($message1);
							$this->email->subject('Confirmation Mail From fiscon.in');
                            $mail=$this->email->send();
					


					if($mail1){
					
					$msg='Thanks for applying job. We will contact back to soon ';
					echo "<script type='text/javascript'>
					alert('$msg');
					 window.location.href='http://fiscon.in/fiscon/front/careerform'
					</script>";
					}
													
					else{
					$msg='email not sent ';
					echo "<script type='text/javascript'>
					alert('$msg');
					 window.location.href='http://fiscon.in/fiscon/front/careerform'
					</script>";
					}
					
       }
	
    }	
}//end carrer action 
	



//contact page
public function contactsubmit(){
error_reporting(0);        
  $this->form_validation->set_rules('firstname', 'First Name', 'trim|required|callback_alpha_dash_space|xss_clean');
  $this->form_validation->set_rules('lastname', 'Last Name', 'trim|required|xss_clean');
  $this->form_validation->set_rules('email', 'E-mail', 'trim|required|valid_email|xss_clean');
  $this->form_validation->set_rules('mobile_no', 'Mobile Number', 'trim|required|numeric|min_length[10]|max_length[10]|xss_clean');
  
  //$this->form_validation->set_rules('quali', 'Qualification', 'trim|required|xss_clean');
  $this->form_validation->set_rules('message', 'Message', 'trim|required|xss_clean');
  $this->form_validation->set_rules('g-recaptcha-response','Captcha','required|callback_recaptcha');

  $this->form_validation->set_error_delimiters('<div class="error">', '</div>');
  if($this->form_validation->run()==false){			
	$this->load->view('contact'); 
}

else{


/*$upload_dir = base_url();
$upload_dir= 'attachement/';

	$file_name = $_FILES['cv']['name'];
	
	if(!empty($file_name)){
	$temp_name = $_FILES['cv']['tmp_name'];
	//$ext = @pathinfo($file_name, PATHINFO_EXTENSION);
	//$file_name= time().rand(1000,99999).'.'.$ext;
	$file_path = $upload_dir.$file_name; 
	@move_uploaded_file($temp_name, $file_path);
	}else{
	$file_name = '';
	}*/

	//if($result){
	$emailid = $this->input->post('email');
	$firstname = $this->input->post('firstname');
	$lastname = $this->input->post('lastname');
	$mobile_no = $this->input->post('mobile_no');
	$content = $this->input->post('message');
	//$applied_for = $this->input->post('applied_for');

	if(!empty($emailid)){
				$config['mailtype'] = 'html';
				   $config['charset'] = 'iso-8859-1';
				   $config['priority'] = 1;
				   $this->email->initialize($config);
				   $this->email->clear();
				   $message="<html>
						<head>
								<title>Contact-us Enquiry</title>
								</head>
								<body>";
							$message .= "Hello ".$firstname." ".$lastname."<br/><br>";
							
							
							
					$message.='
		<table width="80%" border="2" align="center" cellpadding="0" cellspacing="0" bordercolor="#003333" style="border:1px solid #820202">
		   <tr>
		    <td width="29%" bgcolor="#999999"><blockquote><strong>Name:</strong></blockquote></td>
		    <td height="30" align="left" valign="top" nowrap="nowrap" bgcolor="#E1F8FF"><blockquote>'.$firstname." ".$lastname.'</blockquote></td>
		  </tr>
		  
		  
		  <tr>
		    <td width="29%" bgcolor="#999999"><blockquote><strong>Mobile No.</strong>:</blockquote></td>
		    <td height="30" align="left" valign="top" nowrap="nowrap" bgcolor="#E1F8FF"><blockquote>'.$mobile_no.'</blockquote></td>
		  </tr>
		  		  
		  
		  <tr>
		    <td width="29%" bgcolor="#999999"><blockquote><strong>Email</strong>:</blockquote></td>
		    <td height="30" align="left" valign="top" nowrap="nowrap" bgcolor="#E1F8FF"><blockquote>'.$emailid.'</blockquote></td>
		  </tr>
		   
		  <tr>
		    <td valign="top" bgcolor="#999999"><blockquote><strong>Message:</strong></blockquote></td>
		    <td height="30" align="left" valign="top" bgcolor="#E1F8FF"><blockquote>'.$content.'</blockquote></td>
		  </tr>
		  </table>
		';			
							
							$message .="</body></html>";
							$this->email->from($emailid, 'Fiscon Consultant PVT LTD');
							$this->email->to('vijay.porwal@oxygenwebtech.com');
							$this->email->message($message);
							$this->email->subject('Contact-us Enquiry Report from fiscon.in');
							//$this->email->attach($file_name);
                          $mailresult=$this->email->send();

$message1="<html>
						<head>
								<title>Contact-us Enquiry</title>
								</head>
								<body>";
							$message1 .= "Hello ".$firstname." ".$lastname."<br/>
								<br/>";
								
$message1 .= "<p>Thank You for enquiry at Fiscon Consultant PVT LTD!</p><br/>";			
							
							$message1 .="</body></html>";
							$this->email->from('info@fiscon.in', 'Fiscon Consultant PVT LTD');
							$this->email->to($emailid);
							$this->email->message($message1);
							$this->email->subject('Confirmation Mail From fiscon.in');
                            $mail=$this->email->send();
					
					
					if($mailresult){
					
					$msg='Thanks for Enquiry. We will contact back to soon ';
					echo "<script type='text/javascript'>
					alert('$msg');
					 window.location.href='http://fiscon.in/fiscon/front/contact'
					</script>";
					}
													
					else{
					$msg='email not sent ';
					echo "<script type='text/javascript'>
					alert('$msg');
					 window.location.href='http://fiscon.in/fiscon/front/contact'
					</script>";
					}
					
       }
	
    }	
}//end contact action 
	
//add comment
public function commentsubmit(){
		//print_r($_POST);
		error_reporting(0);
$this->form_validation->set_rules('uname', 'Name', 'trim|required|xss_clean');

$this->form_validation->set_rules('email', 'Email address', 'trim|required|valid_email|xss_clean');

$this->form_validation->set_rules('comments', 'Comments', 'trim|required|xss_clean');
  $this->form_validation->set_rules('g-recaptcha-response','Captcha','required|callback_recaptcha');

      
$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
if($this->form_validation->run()==true){
//redirect('admin/news/addnews');


$data = array(
'name' =>$this->input->post('uname'),
'email_id' =>$this->input->post('email'),
'post_blog_id' =>$this->input->post('blog_id'),
'comment' =>$this->input->post('comments'),
'create_date'=>date('Y-m-d h:i:s'),
//'create_date'=>date('Y-m-d h:i:s'),

'status'=>'0',
);

$blogid=$this->input->post('blog_id');
	
$result = $this->user_model->data_insert('comment',$data);
//echo $result;	die;	
$msg= $this->session->set_flashdata('message', 'Your comment submitted Successfully..You can see your comment only after admin  approval');	
if($result){
$this->load->view('front/blog_details/'.$blogid, $msg);
}
}
		  
else{
$this->load->view('front/blog_details/'.$blogid); 
}	
}



}//contoller  end

