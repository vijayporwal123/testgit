<?php
//print_r($this->session->all_userdata()
//$this->session->set_userdata('login_user');
if($this->session->userdata('id') && $this->session->userdata('id')!=''){
}
else{
echo redirect('http://localhost/fiscon_admin/login/index');
}

?>