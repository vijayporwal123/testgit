<?php
error_reporting(0);
$this->load->view('admin/header');
?>

<?php
$this->load->view('admin/session_check');
?>

<body>

<div id="wrapper">

<!-- Navigation -->
<?php 
$this->load->view('admin/navigation');
?> 

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">           
       
        
   <?php
if($executivedata){
//echo"<pre>";
//print_r($executivedata);
   $id = $executivedata[0]['id'];
   $username = $executivedata[0]['username'];
   $email = $executivedata[0]['email'];
   $mobile_no = $executivedata[0]['mobile_no'];  
}
?>     
        
<h3 class="page-header">User List<p style="float:right;"><a href="<?php echo base_url(); ?>admin/news/addnews"><!--<button type="button" class="btn btn-primary btn-sm">Add User</button>--></a></p></h3>
</div>
<!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                                 <b><?php echo $username."-".$mobile_no."-".$email; ?></b>

                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="dataTable_wrapper">
                                <table class="table table-striped table-bordered table-hover" >
                                    <thead>
                                    
                                        <tr>
                                           
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Mobile No.</th>
                                        </tr>
                                        
                                    </thead>
                                    <tbody>
                                    
             <?php 
				/*if(!empty($executivedata)){
				 $i= 1;
				 foreach($executivedata as $key =>$val){*/
			  ?>
                            
                                <tr class="odd gradeX">
                                  <!--  <td><?php echo $i++; ?></td>-->
                                    <td><?php echo  $username; ?></td>
                                    <td><?php echo  $email; ?></td>
                                    <td><?php echo  $mobile_no; ?></td>
                                   
                                    
                                    <!--<td>
                                    <a class="fa fa-pencil" href="<?php //echo base_url(); ?>admin/news/editnews/<?php //echo $val['id']; ?>" onClick="return confirm('Are you sure you want to edit this item?');" title="edit news "></a>&nbsp;<a class="fa fa-trash" href="<?php //echo base_url(); ?>admin/news/deletenews/<?php //echo $val['id']; ?>" title="delete news " onClick="return confirm('Are you sure you want to delete this item?');"></a>
</td>
</td>-->

                                    </tr>
                                    <?php
                                        // }
                                     // }
									  
                                    ?>                                       
                            </tbody>
                            </table>

                        </div>
                    <!-- /.table-responsive -->
                     </div>
                  <!-- /.panel-body -->                  
                   </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            
    <style>
.error{color:#FF0000;
}
</style>        
<form role="form"  method="post" action="<?php echo base_url(); ?>admin/user/executivesubmit">
                                        
              <input type="hidden" name="user_id" value="<?php echo $id; ?>" />
              <input type="hidden" name="admin_name" value="<?php echo $this->session->userdata('user_type');?>" />
              
<input type="hidden" name="exid" value="<?php echo $id; ?>">                                               

              
              
                                        <div class="form-group">
                                            <label>Update</label>
                    <textarea class="form-control"   name="talk"  required></textarea>
                    <?php echo form_error('talk'); ?>
                                        </div>
                                        
<button type="submit"  name="submit" class="btn btn-primary btn-sm">Submit</button>
<a  href="<?php echo base_url(); ?>admin/user/manageuser"><button type="button" class="btn btn-danger btn-sm">Cancel</button></a> 
                                    </form>
<br>
<br>
 <?php if($this->session->flashdata('message')){?>
		  <div class="alert alert-success">  
           <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>    
		    <?php echo $this->session->flashdata('message')?>
		  </div>
		<?php } ?>

<div class="panel-body">
                            <div class="dataTable_wrapper">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                    
                                  <tr>
							          <th>S.No.</th>
								      <th>Previous Summery</th>
                                       <th>Updated By</th>
                                        <th>Updated Date(YYYY-MM-DD)</th>
							  </tr>
                                        
                                    </thead>
                                    <tbody>
<?php
//print_r($executivedata);
date_default_timezone_set('Asia/Kolkata');

				if(!empty($executivedata)){
				 $i=1;
				 foreach($executivedata as $key =>$val){
			  ?>
                    
							<tr>
								<td><?php echo $i++;?></td>
								<td class="center"><?php echo $val['user_history'];?></td>
                               <td class="center"><?php echo $val['admin_name'];?></td>
							  <td class="center"><?php 
							   echo $val['create_date'];
							 // echo   date('d-m-Y', strtotime($val['create_date']));
							  ?></td>
							</tr>
                            
                                    <?php
                                         }
                                      }else{
									  ?>
                                      
                                      <tr><td>No Record Found</td></tr>
                                      <?php
									  }
									  
                                    ?>                                       
                            </tbody>
                            </table>

                        </div>
                    <!-- /.table-responsive -->
                     </div>



           <?php /*?><table class="table table-striped table-bordered table-hover" id="dataTables-example1">
						  <thead>
							  <tr>
							          <th>S.No.</th>
								      <th>Previous Summery</th>
                                      <th>Updated By</th>
                                      <th>Updated Date(DD-MM-YY)</th>
							  </tr>
				         </thead>   
				<tbody>
 <?php 
 
 print_r($userhistory);
 
 
				if(!empty($userhistory)){
				 $s= 1;
				 foreach($userhistory as $key =>$val1){
			  ?>
							<tr class="odd gradeX">
								<td><?php echo $s++;?></td>
								<td class="center"><?php echo $val1['user_history'];?></td>
                                <td class="center"><?php echo $val1['admin_name'];?></td>
								<td class="center"><?php echo date('d-m-Y h:i:s',strtotime($val1['create_date']));?></td>
							</tr>
							<?php
							}
							}
							?>
					  </tbody>
					  </table><?php */?>
            
        </div>
        <!-- /#page-wrapper -->
    </div>
    <!-- /#wrapper -->
    <!-- jQuery -->
    <script src="<?php echo base_url(); ?>assets/bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo base_url(); ?>assets/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="<?php echo base_url(); ?>assets/bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="<?php echo base_url(); ?>assets/bower_components/datatables/media/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/bower_components/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="<?php echo base_url(); ?>assets/dist/js/sb-admin-2.js"></script>

    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
    
    <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
                responsive: true
        });
    });
    </script>

<script>
    $(document).ready(function() {
        $('#dataTables-example1').DataTable({
                responsive: true
        });
    });
    </script>



</body>
</html>
