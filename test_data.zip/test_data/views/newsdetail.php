<?php  $this->load->view('header');?>
<?php
if(!empty($news_details)){	
$bid1=$news_details[0]['id'];
//$tid=$blog_details[0]['id'];
//$bid=$this->uri->segment(3) ? $this->uri->segment(3) : 0;	
}
?>		  		 
<div class="tp-page-header"><!-- full page header -->
  <div class="container">
    <div class="row">
      <div class="col-md-7">
        <div class=""> <!-- page header  -->
        <br />
          <h1>News Detail</h1>
        </div>
        <!-- page header  --> 
      </div>
    </div>
  </div>
</div>

  <?php if($this->session->flashdata('message')){?>
		  <div class="alert alert-success">  
           <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>    
		    <?php echo $this->session->flashdata('message')?>
		  </div>
		<?php } ?>	
        
<!-- /.full page header-->
<div class="tp-breadcrumb">
  <div class="container">
    <div class="row">
      <div class="col-md-8">
        <ol class="breadcrumb">
          <li><a href="<?php echo base_url(); ?>front/index">Home</a></li>
          <li class="active">News Detail</li>
        </ol>
      </div>
      <!--<div class="col-md-4">
        <div class="font-option"> Select font size : <a href="#" id="incfont">A+</a><a href="#" id="decfont">A-</a></div>
      </div>-->
    </div>
  </div>
</div>
<div class="main-container" id="main-container"><!--Main container start-->
  <div class="tp-blog-details" id="tp-blog-details"><!-- blog details -->
    <div class="container">
      <div class="row">
        <div class="col-md-8 tp-blog-left">
          <div class="row">
           <?php 
if(!empty($news_details)){

?>
<div class="col-md-12 tp-blog-post"><!-- blog post start-->
<h1><?php echo $news_details[0]['title']; ?></h1>
<p class="meta"> <span class="meta-date"><i class="fa fa-calendar"></i><?php echo date('d-M-Y',strtotime($news_details[0]['create_date'])); ?></span><!--<span class="meta-comments"> <i class="fa fa-comments"></i><a href="#">(20) Comments</a></span> --> </p>
                  
<?php
    if(!empty($news_details[0]['image'])){?>
    <a href="#"><image src="<?php echo base_url();?>news/<?php echo $news_details[0]['image']; ?>" class="img-responsive" alt=""></a>      
    <?php
    }else{?>                
    <a href="#"><image src="<?php echo base_url();?>uploads/imageNotFound.jpg"  class="img-responsive" alt=""></a>
    <?php
    }
    ?>                      
<p><?php echo $news_details[0]['news']; ?></p>
</div>
<?php
}else{
?>
<div>
<p>No News Post Found</p>
</div>    
<?php
}
?>                          
<!-- /.blog post start--> 
</div>
</div>
<!-- /.tp blog right --> 
</div>
</div>
</div><!-- /.blog details -->
</div>
<?php  $this->load->view('footer');?>
