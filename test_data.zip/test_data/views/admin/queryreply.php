<?php
$this->load->view('admin/header');
?>

<?php
$this->load->view('admin/session_check');
?>
<body>

<div id="wrapper">

<!-- Navigation -->
<?php 
$this->load->view('admin/navigation');
?> 
<style>
.error{color:#FF0000;
}
.msg{color:#337ab7;
}
</style>
<?php
if(!empty($query_reply)){
$user_id=$query_reply[0]['user_id'];	
$unique_no=$query_reply[0]['unique_no'];	
$query=$query_reply[0]['query'];	
$file=$query_reply[0]['file_doc'];	
$qid=$query_reply[0]['id'];			
}
?>
<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
          <h3 class="page-header">Query Reply</h3>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                          GUN-<?php echo $unique_no; ?>
                        </div>
                        
                        <div class="panel-body">
                            <div class="row">
                          <div class="col-lg-6">
                         <div class="form-group">
                        <b>#<?php echo $query; ?> ?</b>
                        <p>&nbsp;&nbsp;   
 <?php
	if(!empty($file)){?>            
	<a class="fa fa-download" href="<?php echo base_url(); ?>admin/query/download/<?php echo $qid; ?>"  title="Download Attachment"></a>
	<?php
	}else{
	}?>
</p>

</div>   
<?php if($this->session->flashdata('message')){?>
<div class="alert alert-success">  
<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>    
<?php echo $this->session->flashdata('message')?>
</div>
<?php } ?>
	                                                       
<div class="panel-body">
<?php
function get_time_ago( $time )
{
    $time_difference = time() - $time;

    if( $time_difference < 1 ) { return 'less than 1 second ago'; }
    $condition = array( 12 * 30 * 24 * 60 * 60 =>  'year',
                30 * 24 * 60 * 60       =>  'month',
                24 * 60 * 60            =>  'day',
                60 * 60                 =>  'hour',
                60                      =>  'minute',
                1                       =>  'second'
    );

    foreach( $condition as $secs => $str )
    {
        $d = $time_difference / $secs;

        if( $d >= 1 )
        {
            $t = round( $d );
            return ' ' . $t . ' ' . $str . ( $t > 1 ? 's' : '' ) . ' ago';
        }
    }
}

$qid1=$this->uri->segment(4) ? $this->uri->segment(4) : 0;

$sql5="select *,fqa.id as fid from fis_query fq inner join fis_query_ans fqa on(fq.id=fqa.quest_id) inner join fis_users fs
on(fs.id=fqa.user_id) where fqa.quest_id='".$qid1."'  ";
$result5=mysql_query($sql5);
if(mysql_num_rows($result5)>0){
while($row5=mysql_fetch_array($result5)){
?>

<ul class="chat">
<?php
if($row5['reply_type']=='fiscon'){
?>                    
<li class="left clearfix">
<span class="chat-img pull-left">
<image src="<?php echo base_url();?>user_file/fiscon_icon.png" alt="User" class="img-circle" style="width:50px; height:50px;">

  
                                    </span>
                                    <div class="chat-body clearfix">
                                        <div class="header">
                                            <strong class="primary-font"><?php echo $row5['reply_type'];?>..</strong>
                                            <small class="pull-right text-muted">
                                                <i class="fa fa-clock-o fa-fw"></i><?php 
											 $date1=date("d-M-Y",strtotime($row5['ans_date'])); 
												$date=$row5['ans_date'];
												echo $date1."  ".get_time_ago(strtotime($date));?>
                                            </small>
                                        </div>
                                        <p>
                              <?php echo $row5['answer'];?></p>
                              <p>&nbsp;&nbsp;   
 <?php
	if(!empty($row5['doc_file'])){?>            
	<a class="fa fa-download" href="<?php echo base_url(); ?>admin/query/download1/<?php echo $row5['fid']; ?>"  title="Download Attachment"></a>
	<?php
	}else{
	}?>
</p>
                                    </div>
                                </li>
                                
                                <?php
}else if($row5['reply_type']=='user'){
	?>    
                                <li class="right clearfix">
                                    <span class="chat-img pull-right">
<?php
if(!empty($row5['photo'])){
?>
<image src="<?php echo base_url();?>user_file/<?php echo $row5['photo'];?>"  alt="User" class="img-circle" style="width:50px; height:50px;" >
<?php
}else{
?>
<image src="<?php echo base_url();?>user_file/default_user.png" alt="User" class="img-circle">
<?php
}
?>                                   </span>
                                    <div class="chat-body clearfix">
                                        <div class="header">
                                            <small class=" text-muted">
                                                <i class="fa fa-clock-o fa-fw"></i> <?php 
											 $date1=date("d-M-Y",strtotime($row5['ans_date'])); 
												$date=$row5['ans_date'];
												echo $date1."  ".get_time_ago(strtotime($date));?></small>
                                            <strong class="pull-right primary-font"><?php echo $row5['reply_type'];?>..</strong>
                                        </div>
                                        <p>
                                    <?php echo $row5['answer'];?></p>
                                     <p>&nbsp;&nbsp;   
 <?php
	if(!empty($row5['doc_file'])){?>            
	<a class="fa fa-download" href="<?php echo base_url(); ?>admin/query/download1/<?php echo $row5['fid']; ?>"  title="Download Attachment"></a>
	<?php
	}else{
	}?>
</p>
                                    
                                    
                                    </div>
                                </li>
                             <?php
}else{
}?>                                                                
</ul>
    
    <?php
    }
    }else{?>
    <ul>
    <li>Not Found</li>
    </ul> 
    <?php
    }
    ?>   
</div>                 
                      
                       
                                
<form role="form"  method="post" action="<?php echo base_url(); ?>admin/query/querysubmit" enctype="multipart/form-data" >
    <input type="hidden" name="uquery" value="<?php echo $query; ?>" >
                                                  
<input type="hidden" name="user_id" value="<?php echo $user_id; ?>" >
<input type="hidden" name="quest_id" value="<?php echo  $this->uri->segment(4) ? $this->uri->segment(4) : 0; ?>" >
<input type="hidden" name="unique_no" value="<?php echo $unique_no; ?>" >

                              
                                                                          
                                       <div class="form-group">
                <label >Attachment</label>
                   <input id="attach" name="attach_file" type="file"  class="form-control"  onChange="return ValidateSingleInput(this)">
                </div>
                              
                                                                                 
                                      <div class="form-group">
                                            <label>Query Reply<span class="error">*</span></label>
<textarea class="form-control" placeholder="Query Answer"  name="reply" style="height:100px"  required></textarea>
                                            <?php echo form_error('reply'); ?> 
                                        </div>
                                        
                                                                                                                        
                                        <button type="submit"  name="submit" class="btn btn-primary btn-sm">Reply</button>
    <a  href="<?php echo base_url(); ?>admin/query/managequery"><button type="button" class="btn btn-danger btn-sm">Cancel</button></a> 
                                        
                                    </form>
                                    
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                                <!-- /.col-lg-6 (nested) -->
                                
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

<!--<link rel="stylesheet" type="text/css" href="<?php //echo base_url(); ?>assets/lib/css/bootstrap.min.css" />
--><link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/src/bootstrap-wysihtml5.css" />
    <script src="<?php echo base_url(); ?>assets/lib/js/wysihtml5-0.3.0.js"></script>
    <script src="<?php echo base_url(); ?>assets/lib/js/jquery-1.7.2.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/lib/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/src/bootstrap3-wysihtml5.js"></script>

<script>
    $('.textarea').wysihtml5();
</script>

   <style type="text/css" media="screen">
        .btn.jumbo {
            font-size: 20px;
            font-weight: normal;
            padding: 14px 24px;
            margin-right: 10px;
            -webkit-border-radius: 6px;
            -moz-border-radius: 6px;
            border-radius: 6px;
        }
    </style>





    <!-- jQuery -->
    
<!--    <script src="<?php echo base_url(); ?>assets/bower_components/jquery/dist/jquery.min.js"></script>
-->
    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo base_url(); ?>assets/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="<?php echo base_url(); ?>assets/bower_components/metisMenu/dist/metisMenu.min.js"></script>

   
    <!-- Custom Theme JavaScript -->
    <script src="<?php echo base_url(); ?>assets/dist/js/sb-admin-2.js"></script>



<script>
 var _validFileExtensions = [".jpg", ".jpeg", ".png",".JPEG",".doc",".docx",".pdf"];    
function ValidateSingleInput(oInput) {
    if (oInput.type == "file") {
        var sFileName = oInput.value;
		 //var sFileSize = oInput.size;
       // var iConvert = (oInput.size /1024).toFixed(2);

		
         if (sFileName.length > 0) {
            var blnValid = false;
            for (var j = 0; j < _validFileExtensions.length; j++) {
                var sCurExtension = _validFileExtensions[j];
                if (sFileName.substr(sFileName.length - sCurExtension.length, sCurExtension.length).toLowerCase() == sCurExtension.toLowerCase()) {
                    blnValid = true;
                    break;
                }
				
            }
			
			
            if (!blnValid) {
                alert("Sorry,invalid file extension, allowed file type extensions are only: " + _validFileExtensions.join(", "));
                oInput.value = "";
                return false;
            }
        }
    }
    return true;
}
 
</script>












</body>

</html>
