<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class User extends CI_Controller{

 public function __construct(){
  parent::__construct();
  $this->load->model('admin/adminmodel');
  $this->load->library(array('form_validation','session','email'));
  $this->load->helper(array('url','html','form'));
  $this->load->helper('date');
  $this->load->helper('security');
  $this->load->library('encrypt');
  $this->load->helper('download');

 }

/*function index()
 {
$this->load->view('admin/form_validation');
 }

function check_validation()
 {
  $this->form_validation->set_rules('name', 'Name', 'trim|required|min_length[5]|xss_clean');
  $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email|xss_clean');
  $this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[5]|xss_clean|matches[cpassword]');
  $this->form_validation->set_rules('cpassword', 'Confrim password', 'trim|required|min_length[5]|xss_clean');
  $this->form_validation->set_rules('website_url', 'Url', 'trim|required|xss_clean|callback_checkwebsiteurl'); //modify this line
  $this->form_validation->set_error_delimiters('<div class="error">', '</div>');
  if($this->form_validation->run()==true){
   echo "<pre>";
   print_r($this->input->post());
  }else{
   $this->load->view('admin/form_validation');
  }
 }
*/

/*function testencrypting(){
  $str = '123';
  $key = 'my-secret-key';
  echo $encrypted = $this->encrypt->encode($str, $key);
// echo $this->encrypt->decode($str, $key);
  exit;
}*/




function output_file($file, $name, $mime_type='')
{
 if(!is_readable($file)) die('File not found or inaccessible!');
 $size = filesize($file);
 $name = rawurldecode($name);
 
 /* Figure out the MIME type | Check in array */
 $known_mime_types=array(
 	"htm" => "text/html",
	"exe" => "application/octet-stream",
	"zip" => "application/zip",
	"doc" => "application/msword",
	"jpg" => "image/jpg",
	"php" => "text/plain",
	"xls" => "application/vnd.ms-excel",
	"ppt" => "application/vnd.ms-powerpoint",
	"gif" => "image/gif",
	"pdf" => "application/pdf",
 	"txt" => "text/plain",
 	"html"=> "text/html",
 	"png" => "image/png",
	"jpeg"=> "image/jpg"
 );
 
 if($mime_type==''){
	 $file_extension = strtolower(substr(strrchr($file,"."),1));
	 if(array_key_exists($file_extension, $known_mime_types)){
		$mime_type=$known_mime_types[$file_extension];
	 } else {
		$mime_type="application/force-download";
	 };
 };
 
 //turn off output buffering to decrease cpu usage
 @ob_end_clean(); 
 
 // required for IE, otherwise Content-Disposition may be ignored
 if(ini_get('zlib.output_compression'))
 ini_set('zlib.output_compression', 'Off');
 header('Content-Type: ' . $mime_type);
 header('Content-Disposition: attachment; filename="'.$name.'"');
 header("Content-Transfer-Encoding: binary");
 header('Accept-Ranges: bytes');
 
 // multipart-download and download resuming support
 if(isset($_SERVER['HTTP_RANGE']))
 {
	list($a, $range) = explode("=",$_SERVER['HTTP_RANGE'],2);
	list($range) = explode(",",$range,2);
	list($range, $range_end) = explode("-", $range);
	$range=intval($range);
	if(!$range_end) {
		$range_end=$size-1;
	} else {
		$range_end=intval($range_end);
	}

	$new_length = $range_end-$range+1;
	header("HTTP/1.1 206 Partial Content");
	header("Content-Length: $new_length");
	header("Content-Range: bytes $range-$range_end/$size");
 } else {
	$new_length=$size;
	header("Content-Length: ".$size);
 }
 
 /* Will output the file itself */
 $chunksize = 1*(1024*1024); //you may want to change this
 $bytes_send = 0;
 if ($file = fopen($file, 'r'))
 {
	if(isset($_SERVER['HTTP_RANGE']))
	fseek($file, $range);
 
	while(!feof($file) && 
		(!connection_aborted()) && 
		($bytes_send<$new_length)
	      )
	{
		$buffer = fread($file, $chunksize);
		echo($buffer); 
		flush();
		$bytes_send += strlen($buffer);
	}
 fclose($file);
 } else
 //If no permissiion
 die('Error - can not open file.');
 //die
die();
}





public function download(){
 // $this->load->helper('file');
/*$where  = "ORDER BY id DESC ";
$data['show_user'] = $this->adminmodel->select('fis_users',$where);*/


$id =  $this->uri->segment(4) ? $this->uri->segment(4) : 0;
$users = 'fis_users';
$where = "where id = $id ";
$data['show_user'] = $this->adminmodel->select($users,$where);	
//$this->load->view('admin/edituser',$data);

if(!empty($data)){

$userfile=$data['show_user'][0]['user_file'];
$file_path=base_url();
$file_path="user_file/".$userfile;
//echo $file_path;
$this->output_file($file_path, ''.$userfile.'', 'application/msword');
}

}

public function manageuser(){

$where  = "ORDER BY id DESC ";
$data['show_user'] = $this->adminmodel->select('fis_users',$where);
$this->load->view('admin/userlist',$data);
}

public function adduser(){
$this->load->view('admin/addusers');
}


public function viewuser(){
   
	    $id =  $this->uri->segment(4) ? $this->uri->segment(4) : 0;
	    $users = 'fis_users';
		$where = "where id = $id ";
	    $data['userdetails'] = $this->adminmodel->select($users,$where);	
        $this->load->view('admin/viewuser',$data);
    }




public function edituser(){
   
	    $id =  $this->uri->segment(4) ? $this->uri->segment(4) : 0;
	    $users = 'fis_users';
		$where = "where id = $id ";
	    $data['userdata'] = $this->adminmodel->select($users,$where);	
        $this->load->view('admin/edituser',$data);
    }




function alpha_dash_space($str)
{
    return ( ! preg_match("/^([-a-z_ ])+$/i", $str)) ? FALSE : TRUE;
} 

//edit user code
public function updateuser(){
//$id =  $this->uri->segment(4) ? $this->uri->segment(4) : 0;
if($this->input->post()){

  $this->form_validation->set_rules('username', 'User Name', 'trim|required|callback_alpha_dash_space|xss_clean');
  $this->form_validation->set_rules('email', 'Email ID', 'trim|required|valid_email|xss_clean');
  //$this->form_validation->set_message('is_unique','Email Address Already Exist!');
  $this->form_validation->set_rules('mobile_no', 'Mobile Number', 'required|numeric|min_length[10]|max_length[10]|xss_clean');
  $this->form_validation->set_rules('company_name', 'Comapany Name', 'trim|required|xss_clean');
  $this->form_validation->set_rules('designation', 'Designation', 'trim|required|xss_clean');
  $this->form_validation->set_rules('address', 'Address', 'trim|required|xss_clean');
  $this->form_validation->set_error_delimiters('<div class="error">', '</div>');

if($this->form_validation->run()==true){
	
	
$upload_dir = base_url();
$upload_dir= 'user_file/';

	$file_name = $_FILES['file_name']['name'];
	
	if(!empty($file_name)){
	$temp_name = $_FILES['file_name']['tmp_name'];
		
	$ext = @pathinfo($file_name, PATHINFO_EXTENSION);
	$file_name= time().rand(1000,99999).'.'.$ext;
   
	$file_path = $upload_dir.$file_name; 
	@move_uploaded_file($temp_name, $file_path);
	
	}
	
	
$upload_dir1 = base_url();
$upload_dir1= 'user_photo/';

	$file_name1 = $_FILES['photo']['name'];
	
	if(!empty($file_name1)){
	$temp_name1 = $_FILES['photo']['tmp_name'];
		
	$ext1 = @pathinfo($file_name1, PATHINFO_EXTENSION);
	$file_name1= time().rand(1000,99999).'.'.$ext1;
   
	$file_path1 = $upload_dir1.$file_name1; 
	@move_uploaded_file($temp_name1, $file_path1);
	}		
	
	
$admin_status=$this->input->post('status');
//status check
$emailid=$this->input->post('email');
$username=$this->input->post('username');


	if($_POST){
	 $uid = $this->input->post("uid");
		
if(!empty($file_name)){
	$data = array(
			'username' =>$this->input->post('username'),
			'company_name' => $this->input->post('company_name'),
			'designation' => $this->input->post('designation'),
            'mobile_no' => $this->input->post('mobile_no'),
			'email' => $this->input->post('email'),
			'address' => $this->input->post('address'),
            'admin_verify_status' =>$this->input->post('status'),
			'user_file'=>$file_name
		);	
	
}else{
		
		$data = array(
			'username' =>$this->input->post('username'),
			'company_name' => $this->input->post('company_name'),
			'designation' => $this->input->post('designation'),
            'mobile_no' => $this->input->post('mobile_no'),
			'email' => $this->input->post('email'),
			'address' => $this->input->post('address'),
            'admin_verify_status' =>$this->input->post('status')
		);
		
}
		
		
		
//file 

if(!empty($file_name1)){
	$data = array(
			'username' =>$this->input->post('username'),
			'company_name' => $this->input->post('company_name'),
			'designation' => $this->input->post('designation'),
            'mobile_no' => $this->input->post('mobile_no'),
			'email' => $this->input->post('email'),
			'address' => $this->input->post('address'),
            'admin_verify_status' =>$this->input->post('status'),
			'user_photo'=>$file_name1
		);	
	
	
}else{
		
		   $data = array(
			'username' =>$this->input->post('username'),
			'company_name' => $this->input->post('company_name'),
			'designation' => $this->input->post('designation'),
            'mobile_no' => $this->input->post('mobile_no'),
			'email' => $this->input->post('email'),
			'address' => $this->input->post('address'),
            'admin_verify_status' =>$this->input->post('status')
		);
		
}		
		
		
		
if($admin_status=='1'){
//if(!empty($emailid)){
				$config['mailtype'] = 'html';
				   $config['charset'] = 'iso-8859-1';
				   $config['priority'] = 1;
				   $this->email->initialize($config);
				   $this->email->clear();
				   $message="<html>
						<head>
								<title>Approval Mail</title>
								</head>
								<body>";
							$message .= "Hello ".$username."<br/><br/>
							Your account is approved successfully by admin :you can login click below link<br/><br/>";
							$message .='<a href="http://fiscon.in/codeIgniter2/admin/login/" target="_blank">Click Here</a> 
							
								<br/>';
			
							
							$message .="</body></html>";
							$this->email->from('info@fiscon.in', 'Fiscon Consultant PVT LTD');
							$this->email->to($emailid);
							$this->email->message($message);
							$this->email->subject('Fiscon Consultant PVT LTD:Approval Mail');
						    $this->email->send();
	
       //}//end empty
	  }	
		
		
		
	
	 $user =  'fis_users';
	 $id1 = $this->adminmodel->data_update(array("id"=>$uid),$user,$data);
		//print_r($id1);
    $msg1=$this->session->set_flashdata('message', 'Your data updated Successfully..');

			
		 if($id1){
		    $this->load->view('admin/user/manageuser',$msg1);
			
		}
	
	}
	
	}//validation if end
	
	else{
	
	$id =  $this->uri->segment(4) ? $this->uri->segment(4) : 0;
	    $users = 'fis_users';
		$where = "where id = $id ";
	    $data['userdata'] = $this->adminmodel->select($users,$where);	
        $this->load->view('admin/edituser',$data);
	}
	
	}
	else{
	
	$id =  $this->uri->segment(4) ? $this->uri->segment(4) : 0;
	    $users = 'fis_users';
		$where = "where id = $id ";
	    $data['userdata'] = $this->adminmodel->select($users,$where);	
        $this->load->view('admin/edituser',$data);
	}
	
	
}//end 
	

public function usersubmit(){
            
  $this->form_validation->set_rules('username', 'User Name', 'trim|required|callback_alpha_dash_space|xss_clean');
  $this->form_validation->set_rules('email', 'Email ID', 'trim|required|valid_email|is_unique[fis_users.email]|xss_clean');
  $this->form_validation->set_message('is_unique','Email Address Already Exist!');
  $this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[8]|max_length[10]|xss_clean');
  $this->form_validation->set_rules('mobile_no', 'Mobile Number', 'required|numeric|min_length[10]|max_length[10]|xss_clean');
  $this->form_validation->set_rules('company_name', 'Comapany Name', 'trim|required|xss_clean');
  $this->form_validation->set_rules('designation', 'Designation', 'trim|required|xss_clean');
 // $this->form_validation->set_rules('address', 'Address', 'trim|required|xss_clean');

  //$this->form_validation->set_rules('website_url', 'Url', 'trim|required|xss_clean|callback_checkwebsiteurl'); //modify this line
  $this->form_validation->set_error_delimiters('<div class="error">', '</div>');
  if($this->form_validation->run()==false){			
	$this->load->view('admin/addusers'); 
	//redirect('admin/addusers');
}


else{

//upload doc file
		
$upload_dir = base_url();
$upload_dir= 'user_file/';

	$file_name = $_FILES['file_name']['name'];
	
	if(!empty($file_name)){
	$temp_name = $_FILES['file_name']['tmp_name'];
		
	$ext = @pathinfo($file_name, PATHINFO_EXTENSION);
	$file_name= time().rand(1000,99999).'.'.$ext;
   
	$file_path = $upload_dir.$file_name; 
	@move_uploaded_file($temp_name, $file_path);
	
	}else{
	$file_name = '';
	}
	
	
//upload photo	
	
$upload_dir1 = base_url();
$upload_dir1= 'user_photo/';

	$file_name1 = $_FILES['photo']['name'];
	
	if(!empty($file_name1)){
	$temp_name1 = $_FILES['photo']['tmp_name'];
		
	$ext1 = @pathinfo($file_name1, PATHINFO_EXTENSION);
	$file_name1= time().rand(1000,99999).'.'.$ext1;
   
	$file_path1 = $upload_dir1.$file_name1; 
	@move_uploaded_file($temp_name1, $file_path1);
	}else{
	$file_name1 = '';
	}	
	
	    $confirm_code=uniqid(rand()); 
		 $origional_pass =$this->input->post('password');
		 
		$data = array(
			'username' =>$this->input->post('username'),
			'password' =>md5($this->input->post('password')),
			'company_name' => $this->input->post('company_name'),
			'designation' => $this->input->post('designation'),
            'mobile_no' => $this->input->post('mobile_no'),
			'email' => $this->input->post('email'),
			'address' => $this->input->post('address'),
			'origional_pass' =>$origional_pass,
			'email_confirm_code' =>$confirm_code,
			'user_photo' =>$file_name1,
			'user_verify_status'=>'0',
            'admin_verify_status'=>'0',
			'user_type'=>'user',
			'user_file'=>$file_name,
			'date'=>date('Y-m-d')
		);
		
	$result = $this->adminmodel->data_insert('fis_users',$data);
	

	//$msg = array('msg' =>'<strong>Success!</strong> Your Account is created.','res' => 1);
	
	if($result){
	$emailid = $this->input->post('email');
	$username = $this->input->post('username');
  $origional_pass =$this->input->post('password');

	if(!empty($emailid)){
				$config['mailtype'] = 'html';
				   $config['charset'] = 'iso-8859-1';
				   $config['priority'] = 1;
				   $this->email->initialize($config);
				   $this->email->clear();
				   $message="<html>
						<head>
								<title>Verify email id</title>
								</head>
								<body>";
							$message .= "Hello ".$username."<br/><br/>
							
						Your login credentials are: username=".$username."<br/>
							password=".$origional_pass."<br/><br/>
							
							Your account is almost ready,but before can login you need to confirm your email id by visiting link below:<br/><br/>";
							$message .='<a href="http://fiscon.in/codeIgniter2/admin/user/verifyuser/'.$confirm_code.'" target="_blank">http://fiscon.in/codeIgniter2/admin/user/verifyuser/'.$confirm_code.'</a> 
								<br/><br/>Once you have visited the above verification URL, your account will be activated.<br/>
								<br/>';
			
							
							$message .="</body></html>";
							$this->email->from('info@fiscon.in', 'Fiscon Consultant PVT LTD');
							$this->email->to($emailid);
							$this->email->message($message);
							$this->email->subject('Fiscon Consultant PVT LTD:Sign Up');
							//if($this->email->send()){
	            // $msg= $this->session->set_flashdata('message', 'Your data inserted Successfully..');	
                 //redirect('admin/blog/bloglist',$msg);
	
	if($this->email->send()){
								//echo "email sent";
			$msg='Link has been sent to your emaild Please verify email id and login ';
			echo "<script type='text/javascript'>
			alert('$msg');
			 window.location.href='http://fiscon.in/codeIgniter2/admin/user/manageuser'
			</script>";
			}
											
			else{
			$msg='email not sent ';
			echo "<script type='text/javascript'>
			alert('$msg');
			 window.location.href='http://fiscon.in/codeIgniter2/admin/user/adduser'
			</script>";
			}
       }
	
    }
  }
	
}
	
	



public function verifyuser(){
		
	$eid =  $this->uri->segment(4) ? $this->uri->segment(4) : 0;


$table2 = 'fis_users';
$where = "where email_confirm_code = '".$eid."' ";
$data['email_confirm'] = $this->adminmodel->select($table2,$where);	

$confirmcode=$data['email_confirm'][0]['email_confirm_code'];

		if($confirmcode==$eid){
		//$passkey = $this->input->get('passkey');
		//$passkey = $_GET['passkey'];
		//$data = array('email_confirm_code'=>$eid);
		$data =array('user_verify_status'=>1);
		//$result = $this->adminmodel->update_data('fis_users',$where,$verify);
	$result = $this->adminmodel->data_update(array("email_confirm_code"=>$eid),'fis_users',$data);

		
		//echo $result;die;
		
		
		echo "<script type='text/javascript'>
			alert('email verified successfully,you can login after admin email approval');
			 window.location.href='http://fiscon.in/codeIgniter2/admin/login'
			</script>";			
		
		}else{
			echo "<script type='text/javascript'>
			alert('email not verified,please try again');
			 window.location.href='http://fiscon.in/codeIgniter2/admin/login'
			</script>";
		}
		
		
		
		
		
	}



public function executivelist(){
   
	    $id =  $this->uri->segment(4) ? $this->uri->segment(4) : 0;
	    //$user = 'fis_users';
		//$where  = "where id = $id  ";
	    $data['executivedata'] = $this->adminmodel->result_userid($id);	
		//print_r($data['executivedata']);die;
        $this->load->view('admin/executivelist',$data);
	
}





public function executivesubmit(){
		
if($_POST){
	
		$data = array(
			'user_id' =>$this->input->post('user_id'),
			'admin_name'=>$this->input->post('admin_name'),
			'user_history'=>$this->input->post('talk'),
			'create_date'=>date('Y-m-d h:i:s'),
		);
		
$result = $this->adminmodel->data_insert('fis_userinfo',$data);
//echo $result;die;
	if($result){
	
	$msg= $this->session->set_flashdata('message', 'Your data submitted Successfully..');	
	//$id1 = $this->uri->segment(4) ? $this->uri->segment(4) : 0;
	
    redirect('admin/user/manageuser',$msg);
	}
	
}
	
}


//resend email verification 

public function resend_email(){

      $id =  $this->uri->segment(4) ? $this->uri->segment(4) : 0;
	    $users = 'fis_users';
		$where = "where id = $id ";
	    $data['resendmail'] = $this->adminmodel->select($users,$where);	
        //$this->load->view('admin/edituser',$data);      
 
 
 if(!empty($data)){ 		
		$emailid= $data['resendmail'][0]['email'];
	    $username= $data['resendmail'][0]['username'];
		 $email_confirm_code= $data['resendmail'][0]['email_confirm_code'];
	
	//$emailid = $this->input->post('email');
	//$name = $this->input->post('username');
	
	if(!empty($emailid)){
				$config['mailtype'] = 'html';
				   $config['charset'] = 'iso-8859-1';
				   $config['priority'] = 1;
				   $this->email->initialize($config);
				   $this->email->clear();
				   $message="<html>
						<head>
								<title>Verify email id</title>
								</head>
								<body>";
							$message .= "Hello ".$username."<br/><br/>
							Your account is almost ready,but before can login you need to confirm your email id by visiting link below:<br/><br/>";
							$message .='<a href="http://fiscon.in/codeIgniter2/admin/user/verifyuser/?passkey='.$confirm_code.'" target="_blank">http://fiscon.in/codeIgniter2/admin/user/verifyuser/?passkey='.$confirm_code.'</a> 
								<br/><br/>Once you have visited the above verification URL, your account will be activated.<br/>
								<br/>';
			
							
							$message .="</body></html>";
							$this->email->from('info@fiscon.in', 'Fiscon Consultant PVT LTD');
							$this->email->to($emailid);
							$this->email->message($message);
							$this->email->subject('Fiscon Consultant PVT LTD:Resend Mail Again');
						
	
	if($this->email->send()){
								//echo "email sent";
			$msg='Link has been sent to your emaild Please verify email id and login ';
			echo "<script type='text/javascript'>
			alert('$msg');
			 window.location.href='http://fiscon.in/codeIgniter2/admin/user/manageuser'
			</script>";
			}
											
			else{
			$msg='email not sent ';
			echo "<script type='text/javascript'>
			alert('$msg');
			 window.location.href='http://fiscon.in/codeIgniter2/admin/user/manageuser'
			</script>";
			}
			
			
       }//end empty
	
    }
  }

//end email 


 
public function deleteuser($id)
{  
	
$id = $this->uri->segment(4) ? $this->uri->segment(4) : 0;	
$this->db->where('id', $id);
$this->db->delete('fis_users');
$this->session->set_flashdata('message', 'Your data deleted Successfully..');
redirect('admin/user/manageuser');

}

 
 
 

}//last end
?>
