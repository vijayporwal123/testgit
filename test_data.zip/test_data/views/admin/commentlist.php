<?php
$this->load->view('admin/header');
?>

<?php
$this->load->view('admin/session_check');

?>
<body>

    <div id="wrapper">

<!-- Navigation -->
<?php 
$this->load->view('admin/navigation');
?> 

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                
           
        <?php if($this->session->flashdata('message')){?>
		  <div class="alert alert-success">  
           <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>    
		    <?php echo $this->session->flashdata('message')?>
		  </div>
		<?php } ?>
        
                    <h3 class="page-header">Comment List<p style="float:right;"><!--<a href="<?php //echo base_url(); ?>admin/comment/index"><button type="button" class="btn btn-primary btn-sm">Add Blog</button></a></p>--></h3>
                    
                  
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                           Comment List
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="dataTable_wrapper">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>S.No</th>
                                            <th>Comment Post Date</th>
                                            <th>Name</th>
                                            <th>Post</th>
                                            <th>Comment on Post</th>
                                            <th>Comment Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
								<?php 
                                    if(!empty($allcomment)){
                                     $i= 1;
                                     foreach($allcomment as $key => $val){
                                  ?>
                                        <tr class="odd gradeX">
                                            <td><?php echo $i++; ?></td>
                                            <td><?php echo date('d-m-Y',strtotime($val['create_date'])); ?></td>
                                             <td><?php echo $val['name']; ?></td>
                                            <td ><?php echo $val['title'] ?></td>
                                            <td ><?php echo $val['comment']; ?></td>
                                            <td><?php if($val['status'] == '1'){ 
                                            ?>
                                            <span class="label label-sm label-success">Approved</span>
                                            <?php
                                            }else{
                                            ?>
                                            <span class="label label-sm label-danger">Pending</span>
                                            <?php
                                            }
                                            ?>
                                            </td>

<td>
<a class="fa fa-pencil" href="<?php echo base_url(); ?>admin/comment/approvecomment/<?php echo $val['cid']; ?>" title="approve comment here" onClick="return confirm('Are you sure you want to Approve this item?');"></a>&nbsp;<a class="fa fa-trash" href="<?php echo base_url(); ?>admin/comment/deletecomment/<?php echo $val['cid']; ?>" title="Delete comment " onClick="return confirm('Are you sure you want to delete this item?');"></a>
</td>

</tr>
<?php
     }
  }
?>                                       
</tbody>
</table>
</div>
<!-- /.table-responsive -->
                            
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="<?php echo base_url(); ?>assets/bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo base_url(); ?>assets/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="<?php echo base_url(); ?>assets/bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="<?php echo base_url(); ?>assets/bower_components/datatables/media/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/bower_components/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/bower_components/datatables-responsive/js/dataTables.responsive.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="<?php echo base_url(); ?>assets/dist/js/sb-admin-2.js"></script>

    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
    <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
                responsive: true
        });
    });
    </script>

</body>

</html>
