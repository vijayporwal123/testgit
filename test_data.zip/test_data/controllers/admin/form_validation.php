<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Form_validation extends CI_Controller {
 
 function __construct()
 {
  parent::__construct();
  
 $this->load->model('admin/adminmodel');
  $this->load->library(array('form_validation','session','email'));
  $this->load->helper(array('url','html','form'));
  $this->load->helper('date'); 
  
  
  
  
  
  
  
  
  //$this->load->library('form_validation');
//$this->load->helper('form');
 }

 function index()
 {
  $this->load->view('admin/form_validation');
 }

 function check_validation()
 {
  $this->form_validation->set_rules('name', 'Name', 'trim|required|min_length[5]|xss_clean');
  $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email|xss_clean');
  $this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[5]|xss_clean|matches[cpassword]');
  $this->form_validation->set_rules('cpassword', 'Confrim password', 'trim|required|min_length[5]|xss_clean');
  $this->form_validation->set_rules('website_url', 'Url', 'trim|required|xss_clean');
  
  if($this->form_validation->run()==true){
   print_r($this->input->post());
  }else{
   $this->load->view('admin/form_validation');
  }
 }
}