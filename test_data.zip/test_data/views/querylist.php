<?php $this->load->view('user_header');
//echo $this->session->userdata('id');?>
<div class="tp-page-header"><!--tp-page-header-->
  <div class="container">
    <div class="row">
      <div class="col-md-7">
        <div class=""> <!-- page header  -->
        <br>
          <h2>Query Form</h2>
        </div>
        <!--/.page header  --> 
      </div>
    </div>
  </div>
</div>

<style>
.error{color:#FF0000;
}
</style>


<!-- /.tp-page-header--> 
<div class="tp-breadcrumb"><!--tp-breadcrumb-->
  <div class="container">
    <div class="row">
      <div class="col-md-8">
        <ol class="breadcrumb">
          <li><a href="<?php echo base_url(); ?>login/userinbox">Home</a></li>
          <li class="active">Querylist</li>
        </ol>
        
      </div>
     
    </div>
  </div>
  
</div><!--/.tp-breadcrumb-->
<div class="main-container" id="main-container"><!--Main container start-->
<div class="tp-contact" id="tp-contact"><!--tp-contact-->
<div class="container">
<div class="row">
<div class="col-md-offset-1 col-md-9 contact-form">
 <?php if($this->session->flashdata('message')){?>
		  <div class="alert alert-success">  
           <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>    
		    <?php echo $this->session->flashdata('message')?>
		  </div>
		<?php } ?>     

<h2>Query List</h2>
<?php 
$sql5="select * from fis_query f  where f.user_id='".$this->session->userdata('id')."' ";
$result5=mysql_query($sql5);
$total=mysql_num_rows($result5);?>



<p><h4 style="color:red; float:left">Total Query Records:&nbsp;<?php echo $total;?></h4><a href="<?php echo base_url(); ?>login/addquery"><button class="btn btn-primary"  style="float:right;">Post Query</button></a></p>
 <br /> <br />
  
<table class="table table-bordered">
    <thead>
    
      <tr>
        <!--<th>S.No.</th>-->
        <th>Query</th>
        <th>Status</th>
        <th>Date</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
<?php 
/*$sql5="select count(f.user_id) as total from fis_query f  where f.user_id='".$this->session->userdata('id')."' ";
$result5=mysql_query($sql5);
$total=mysql_num_rows($result5);	
*/
	
if(!empty($show_query)){
	$i= 1;
foreach($show_query as $val){
		
$id=$val->id;
	//$id=1;	
		//$tid=$id++;
		
		
	?>
      <tr>
<!--       <td><?php //echo $val->id;?></td>
-->        <td><?php echo substr($val->query,0,100);?></td>
        <td><?php if($val->status == '0'){ 
        ?>
        <span class="label label-sm label-danger">Open</span>
        <?php
        }else{
        ?>
        <span class="label label-sm label-success">Closed</span>
        <?php
        }
        ?>
        </td>
  <td><?php echo date('d-M-Y',strtotime($val->create_date)); ?></td>   
                            
       <td>
<a class="fa fa-eye" href="<?php echo base_url(); ?>login/queryreply/<?php echo $val->id; ?>" onClick="return confirm('Are you sure you want to View Query ?');" title=" View Query"></a>                     
     </td>                             
                                   
      </tr>
<?php
$i++;
	}
	}else{?>
    <tr>
    <td>No Record Found</td>
    </tr>
    <?php
	}
	?>
    
</tbody>
</table>

  <div class="row">
        <div class="col-md-12" >
<?php echo $this->pagination->create_links(); ?>
        </div>
    </div>

</div>
</div>
</div>    
<!--/.support-section-->
</div><!--/.tp-contact-->
</div>
<!-- /.Main container start-->
<?php /*?><div class="tp-newsletter"><!-- Newsletter -->
  <div class="container">
    <div class="row">
      <div class="col-md-5 news-title"><!-- section title -->
        <h2><i class="fa fa-envelope-o"></i> Register to Peace Newsletter</h2>
      </div>
      <div class="col-md-7 newsletter"><!-- Newsletter form -->
        <form method="post" action="newsletter.php">
          <div class="input-group">
            <label class="sr-only control-label" for="newsletter">Newsletter</label>
            <input type="email" id="newsletter" name="newsletter" class="form-control" placeholder="E-mail Address">
            <span class="input-group-btn">
            <button class="btn tp-btn-orange" type="submit">Submit</button>
            </span> </div>
        </form>
        <!-- /input-group --> 
        </div>
      <!-- Newsletter form -->
    </div>
  </div>
</div><?php */?>

<?php  $this->load->view('user_footer'); ?>
