<?php
$this->load->view('admin/header');
?>

<?php
$this->load->view('admin/session_check');
?>

<body>
<div id="wrapper">
<!-- Navigation -->
<?php 
$this->load->view('admin/navigation');
?> 

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">           
        <?php if($this->session->flashdata('message')){?>
		  <div class="alert alert-success">  
           <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>    
		    <?php echo $this->session->flashdata('message')?>
		  </div>
		<?php } ?>        
<h3 class="page-header">Executive List<p style="float:right;"><a href="<?php echo base_url(); ?>admin/login/addexecutive"><button type="button" class="btn btn-primary btn-sm">Add Executive</button></a></p></h3>
</div>

<!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                           Executive List
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="dataTable_wrapper">
                                <table class="table table-striped table-bordered table-hover table-responsive" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>S.No.</th>
                                            <th>Executive Name</th>
                                            <th>Email</th>
                                            <th>Mobile</th>
                                            <th>Date</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    
             <?php 
				if(!empty($show_user)){
				 $i= 1;
				 foreach($show_user as $key =>$val){
			  ?>
                            
                                <tr class="odd gradeX">
                                    <td><?php echo $i++; ?></td>
                                    <td><?php echo $val['username']; ?><!--<a  href="<?php //echo base_url(); ?>admin/user/executivelist/<?php echo $val['id']; ?>" ></a>--></td>
                                    <td><?php echo $val['email']; ?></td>
                                    <td><?php echo $val['mobile_no']; ?></td>
                                     <td><?php echo $val['date']; ?></td>

                                    <td>
<!--<a class="fa fa-pencil" href="<?php echo base_url(); ?>admin/user/edituser/<?php echo $val['id']; ?>" onClick="return confirm('Are you sure you want to edit this item?');" title="edit user "></a>-->&nbsp;<a class="fa fa-trash" href="<?php echo base_url(); ?>admin/login/deleteuser/<?php echo $val['id']; ?>" title="delete user " onClick="return confirm('Are you sure you want to delete this user?');"></a>&nbsp;<!--<a class="fa fa-eye" href="<?php echo base_url(); ?>admin/user/viewuser/<?php echo $val['id']; ?>" title="Resend mail to user" onClick="return confirm('Are you sure you want to view detail this user?');"></a>-->&nbsp; 
                      
</td>

                                    </tr>
                                    <?php
                                         }
                                      }
                                    ?>                                       
                </tbody>
                </table>

    </div>
<!-- /.table-responsive -->
                            
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="<?php echo base_url(); ?>assets/bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo base_url(); ?>assets/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="<?php echo base_url(); ?>assets/bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="<?php echo base_url(); ?>assets/bower_components/datatables/media/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/bower_components/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/bower_components/datatables-responsive/js/dataTables.responsive.js"></script>
   <!-- DataTables JavaScript -->
  
  
    <!-- Custom Theme JavaScript -->
    <script src="<?php echo base_url(); ?>assets/dist/js/sb-admin-2.js"></script>

    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
    
    <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
                responsive: true
        });
    });
    </script>

</body>
</html>
