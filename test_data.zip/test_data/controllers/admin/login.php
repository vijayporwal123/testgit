<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Login extends CI_Controller{

public function __construct(){
parent::__construct();
  
  
$this->load->model('admin/adminmodel');
$this->load->library(array('form_validation','session','email'));
$this->load->helper(array('url','html','form'));
$this->load->library('encrypt');
  
$this->output->set_header('Last-Modified:'.gmdate('D, d M Y H:i:s').'GMT');
$this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate');
$this->output->set_header('Cache-Control: post-check=0, pre-check=0',false);
$this->output->set_header('Pragma: no-cache');	
  
 
 }


public function index(){

$this->load->view('admin/index');
}


/*public function forgotpassword(){
$this->load->view('admin/forgotpassword');
}*/


public function addexecutive(){
$this->load->view('admin/addexecutive');
}



public function manageexecutive(){

$where  = "where user_type='executive' ORDER BY id DESC ";
$data['show_user'] = $this->adminmodel->select('fis_users',$where);
$this->load->view('admin/manage_exe',$data);
}


public function executivesubmit(){
            
  $this->form_validation->set_rules('username', 'User Name', 'trim|required|callback_alpha_dash_space|xss_clean');
  $this->form_validation->set_rules('email', 'Email ID', 'trim|required|valid_email|is_unique[fis_users.email]|xss_clean');
  $this->form_validation->set_message('is_unique','Email Address Already Exist!');
  $this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[8]|max_length[10]|xss_clean');
  $this->form_validation->set_rules('mobile_no', 'Mobile Number', 'required|numeric|min_length[10]|max_length[10]|xss_clean');
  //$this->form_validation->set_rules('company_name', 'Comapany Name', 'trim|required|xss_clean');
 // $this->form_validation->set_rules('designation', 'Designation', 'trim|required|xss_clean');
 // $this->form_validation->set_rules('address', 'Address', 'trim|required|xss_clean');
  //$this->form_validation->set_rules('website_url', 'Url', 'trim|required|xss_clean|callback_checkwebsiteurl'); //modify this line
  $this->form_validation->set_error_delimiters('<div class="error">', '</div>');
  if($this->form_validation->run()==false){			
	$this->load->view('admin/addexecutive'); 
	//redirect('admin/addusers');
}


else{

//upload doc file
		
/*$upload_dir = base_url();
$upload_dir= 'user_file/';

	$file_name = $_FILES['file_name']['name'];
	
	if(!empty($file_name)){
	$temp_name = $_FILES['file_name']['tmp_name'];
		
	$ext = @pathinfo($file_name, PATHINFO_EXTENSION);
	$file_name= time().rand(1000,99999).'.'.$ext;
   
	$file_path = $upload_dir.$file_name; 
	@move_uploaded_file($temp_name, $file_path);
	
	}else{
	$file_name = '';
	}*/
	
	
//upload photo	
	
$upload_dir1 = base_url();
$upload_dir1= 'user_photo/';

	$file_name1 = $_FILES['photo']['name'];
	
	if(!empty($file_name1)){
	$temp_name1 = $_FILES['photo']['tmp_name'];
		
	$ext1 = @pathinfo($file_name1, PATHINFO_EXTENSION);
	$file_name1= time().rand(1000,99999).'.'.$ext1;
   
	$file_path1 = $upload_dir1.$file_name1; 
	@move_uploaded_file($temp_name1, $file_path1);
	}else{
	$file_name1 = '';
	}	
	
	    $confirm_code=uniqid(rand()); 
		 $origional_pass =$this->input->post('password');
		 
		$data = array(
			'username' =>$this->input->post('username'),
			'password' =>md5($this->input->post('password')),
			//'company_name' => $this->input->post('company_name'),
			//'designation' => $this->input->post('designation'),
            'mobile_no' => $this->input->post('mobile_no'),
			'email' => $this->input->post('email'),
			'address' => $this->input->post('address'),
			'origional_pass' =>$origional_pass,
			'email_confirm_code' =>$confirm_code,
			'user_photo' =>$file_name1,
			'user_verify_status'=>'1',
            'admin_verify_status'=>'1',
			'user_type'=>'executive',
			//'user_file'=>$file_name,
			'date'=>date('Y-m-d')
		);
		
	$result = $this->adminmodel->data_insert('fis_users',$data);
	

	//$msg = array('msg' =>'<strong>Success!</strong> Your Account is created.','res' => 1);
	
	if($result){
	$emailid = $this->input->post('email');
	$username = $this->input->post('username');
  $origional_pass =$this->input->post('password');

	if(!empty($emailid)){
				$config['mailtype'] = 'html';
				   $config['charset'] = 'iso-8859-1';
				   $config['priority'] = 1;
				   $this->email->initialize($config);
				   $this->email->clear();
				   $message="<html>
						<head>
								<title>Verify email id</title>
								</head>
								<body>";
							$message .= "Hello ".$username."<br/><br/>
							
						Your login credentials are: username=".$username."<br/>
							password=".$origional_pass."<br/><br/>";
														
							$message .="</body></html>";
							$this->email->from('info@fiscon.in', 'Fiscon Consultant PVT LTD');
							$this->email->to($emailid);
							$this->email->message($message);
							$this->email->subject('Fiscon Consultant PVT LTD:Sign Up');
							
	
	if($this->email->send()){
								//echo "email sent";
			/*$msg='Link has been sent to your emaild Please verify email id and login ';
			echo "<script type='text/javascript'>
			alert('$msg');
			 window.location.href='http://fiscon.in/fiscon2/admin/user/manageuser'
			</script>";*/
			
			$msg='Link has been sent to your emaild Please verify email id and login ';
			echo "<script type='text/javascript'>
			alert('$msg');
			 window.location.href='http://fiscon.in/fiscon2/admin/login/manageexecutive'
			</script>";
						
			}
											
			else{
			$msg='email not sent ';
			echo "<script type='text/javascript'>
			alert('$msg');
			 window.location.href='http://fiscon.in/fiscon2/admin/login/addexecutive'
			</script>";
			}
			
			
       }
	
    }
  }
	
}




public function admininbox(){
$this->load->view('admin/admininbox');
 
}

public function resetpassword()
{
$this->load->view('admin/resetpassword');
}
	
public function update_pass(){
		
	
	$emails =$this->uri->segment(4) ? $this->uri->segment(4) : 0;

	     $USER ='fis_users';
	     $where  = "where email_confirm_code ='$emails'  ";
		 //$where = array('email_confirm_code'=>$code1);
	     $data['email'] = $this->adminmodel->select($USER,$where);	
		
		$email1 = $data['email'][0]['email_confirm_code'];
		
		if($email1==$emails){
		
		$pass =  array('password'=>md5($_POST['newpassword']));
		$result = $this->adminmodel->data_update(array("email_confirm_code"=>$emails),'fis_users',$pass);
			//echo 	$result;die;
		$msg='Your Password change Successfully';
		echo "<script type='text/javascript'>
		alert('$msg');
		window.location.href='http://fiscon.in/fiscon2/login/index'
		</script>";														
			}
			
		else{
		$msg='Your Password Not Change  ';
		echo "<script type='text/javascript'>
		alert('$msg');
		window.location.href='http://fiscon.in/fiscon2/login/index'
		</script>";														
			}
			
	}
	
	
	
public function deleteuser($id)
{  	
$id = $this->uri->segment(4) ? $this->uri->segment(4) : 0;	
$this->db->where('id', $id);
$this->db->delete('fis_users');
$this->session->set_flashdata('message', 'Your data deleted Successfully..');
redirect('admin/login/manageexecutive');
}	
	
	

/*public function forgot_password_verify()
	{
        $email = $this->input->post('email');
	    $USER =  'fis_users';
		$where  = "where email = '$email' ";
	    $data['forgot'] = $this->adminmodel->select($USER,$where);	
		//$this->load->view('admin/partners',$data);
		//print_r($data);
		if(!empty($data)){ 
		
		//foreach($data as $value){
		$emailid= $data['forgot'][0]['email'];
		$code= $data['forgot'][0]['email_confirm_code'];

		//echo $emailid;
		if(!empty($emailid)){
		
		
		$config['mailtype'] = 'html';
						   $config['charset'] = 'iso-8859-1';
						   $config['priority'] = 1;
						   $this->email->initialize($config);
						   $this->email->clear();
						   $message="<html>
								<head>
								<title>Forgot password</title>
								</head>
								<body>";
							$message .= "Hello, "."<br/><br/>
							Please follow link below and choose your new password.<br/><br/>";
							$message .='<a href="http://fiscon.in/fiscon2/admin/login/resetpassword/'.$code.'" target="_blank">http://fiscon.in/fiscon2/admin/login/resetpassword/'.$code.'</a> 
								<br/><br/>';
								
							$message .="</body></html>";
							$this->email->from('info@fiscon.in', 'Fiscon Consultant PVT LTD ');
							$this->email->to($emailid);
							$this->email->message($message);
							$this->email->subject('Fiscon Consultant:Forgot Password');
							if($this->email->send()){
								
$msg='Reset password link has been sent to your emaild ';

echo "<script type='text/javascript'>
alert('$msg');
 window.location.href='http://fiscon.in/fiscon2/admin/login/forgotpassword'
</script>";														
}
								
else{								
$msg='email not sent ';
echo "<script type='text/javascript'>
alert('$msg');
 window.location.href='http://fiscon.in/fiscon2/admin/login/forgotpassword'
</script>";								
}
		
}
else{
		//echo "email id doesn't exist";		
$msg='email id doesn t exist ';
echo "<script type='text/javascript'>
alert('$msg');
 window.location.href='http://fiscon.in/fiscon2/admin/login/forgotpassword'
</script>";
			
  }
}
		
else{
		//echo "data not found";
$msg='data not found ';
echo "<script type='text/javascript'>
alert('$msg');
window.location.href='http://fiscon.in/fiscon2/admin/login/forgotpassword'
</script>";
	
}

//http://fiscon.in/admin/login/forgotpassword

		
}//end
*/


 function logout(){
	 
  $this->session->sess_destroy();
   redirect('http://localhost/fiscon_admin/');
 
  //$this->load->view('admin/index');
 }



 /*function signin(){

  $email= trim($this->input->post('email'));
  $password= trim($this->input->post('password'));
  
  $query = $this->adminmodel->processLogin($email,$password);

  $this->form_validation->set_rules('email', 'EmailId', 'required|callback_validateUser[' . $query->num_rows() . ']');
  $this->form_validation->set_rules('password', 'Password', 'required');

  $this->form_validation->set_error_delimiters('<div class="error">', '</div>');
  $this->form_validation->set_message('required', 'Enter %s');

  if($this->form_validation->run() == FALSE){
   $this->load->view('admin/index');
  }
  
  else{
  
   if($query){
    $query = $query->result();
	
    $user = array(
     'id' => $query[0]->id,
     'email' => $query[0]->email,
	  'user_type' => $query[0]->user_type,
    // 'EMAIL' => $query[0]->EMAIL,
     //'FIRST_NAME' => $query[0]->FIRST_NAME,
     //'LAST_NAME' => $query[0]->LAST_NAME
    );

   $data= $this->session->set_userdata($user);
	  //$this->successpage();
	   //$this->load->view('admin/successpage');
	     // $this->load->view('admin/header');

   redirect('admin/login/admininbox');
  
   
   }
  }
 }*/

 /** Custom Validation Method*/
 /*public function validateUser($email,$recordCount){
  if ($recordCount != 0){
   return TRUE;
  }else{
   $this->form_validation->set_message('validateUser', 'Invalid %s or Password');
   return FALSE;
  }
 }*/
}
?>