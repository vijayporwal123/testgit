<div class="container"> 
  
  <!--main section starts-->
  <div class="main-col">
    <div class="row">
      
      <div class="col-md-12 col-sm-12 col-xs-12"> 
        <!--most selling products-->
        <div class="product-section cart-page">
          
         <!--  <div class="products-detail">
                <div class="row">
                <div class="col-md-6 cart-page-title">
                                <h3>SHOPPING CART</h3>
                </div>
                <div class="col-md-6 text-right">
                        <a href="<?php echo site_url();?>home/checkout" class="btn add-cart">PROCEED TO CHECKOUT</a>
                        </div>
            </div>
          </div> -->
          
          <div class="cart-table">
                <div class="table-responsive cart-table">
                <form name="frm" method="post" action="<?php echo base_url(); ?>cart/update_cart">
                <table class="table-bordered" style="width: 100%;">
                        <thead>
                        <tr>
                       <!--  <th>Product Image</th> -->
                            <th>Product Name</th>
                            <!--<th>Edit</th>-->
                            <th>Unit Price</th>
                            <th>Quantity</th>
                            <th>Subtotal</th>
                            <th>Delete</th>
                        </tr>
                    </thead>
                    <?php print_r($this->cart->contents());
                                         foreach ($this->cart->contents() as $items): ?>
                    <tbody>
                        <tr class="each_product">
                               <!--  <td><?php if(!empty($items['image'])){?><img src="<?php echo base_url(); ?>uploads/products/<?php echo  $items['image'];?>" width="100px"><?php } ?></td> -->
                            <td><?php echo $items['name']; ?></td>
                           <!-- <td><a href="#"><i class="fa fa-pencil-square-o"></i></a></td>-->
                            <td id="punit-price"><i class="fa fa-inr"></i> <?php echo $items['price']; ?></td>
                            <td><input id="product-qnt" type="number" name="qty[]" value="<?php echo $items['qty']; ?>" min="1"/><input type="hidden" name="rowid[]" value="<?php echo $items['rowid']; ?>" min="1"/></td>
                            <td id="ptotal-price"><i class="fa fa-inr"></i><span> <?php echo $this->cart->format_number($items['subtotal']); ?></span></td>
                            <td><a href="<?php echo site_url();?>cart/delete_item/<?php echo  $items['rowid'];?>/0" onclick="return confirm('Are You Sure?');" ><i class="fa fa-times"></i>delete</a></td>
                        </tr>
                    </tbody>
                    <?php endforeach; ?> 
                    <tfoot>
                        <tr>
                                <td colspan="7">
                                <a href="<?php echo site_url();?>index" class="add-cart add-cart-1">CONTINUE SHOPPING</a>
                                <button type="submit"  class="add-cart add-cart-2">UPDATE SHOPPING CART</button>
                                <a href="<?php echo site_url();?>cart/destroy" class="add-cart add-cart-3">CLEAR SHOPPING CART</a>
                            </td>
                        </tr>
                    </tfoot>
                    
                </table>
                </form>
            </div>
          </div>
          
          <div class="row">
                
            <div class="col-md-6">
                <!--<div class="shipping-col">
                        <h4>ESTIMATE SHIPPING AND TAX</h4>
                        <div class="ship-text">Enter your destination to get a shipping estimate.</div>
                    
                    <form method="post" action="#">
                    <div class="select-country">
                        <label>Select Country</label>
                        <select class="cs-select cs-skin-border">
                            <option value="" disabled selected>Select Country</option>
                            <option value="1">India</option>
                            <option value="2">Armenia</option>
                            <option value="3">Australia</option>
                            <option value="4">Austria</option>
                            <option value="5">Bangladesh</option>
                            <option value="6">Belgium</option>
                            <option value="7">Bhutan</option>
                            <option value="8">Bolivia</option>
                            <option value="1">Canada</option>
                            <option value="2">Denmark</option>
                            <option value="3">Finland</option>
                            <option value="4">France</option>
                            <option value="5">Germany</option>
                            <option value="6">Hong Kong</option>
                            <option value="7">Italy</option>
                            <option value="8">Japan</option>
                        </select>
                    </div>
                    
                    <div class="input-field">
                        <label>State/Province</label>
                        <input type="text" class="form-control">
                    </div>
                    
                    <div class="input-field">
                        <label>Zip/Postal code</label>
                        <input type="text" class="form-control">
                    </div>
                    
                    <div class="input-field">
                        <button class="btn add-cart">GET A QUOTE</button>
                    </div>
                    
                    </form>
                    
                </div>-->
            </div>
            
           <!-- <div class="col-md-4">
                <div class="shipping-col">
                        <h4>DISCOUNT CODES</h4>
                        
                    <form method="post" action="#">
                    
                    <div class="input-field">
                        <label>Enter your coupon code if you have one.</label>
                        <input type="text" class="form-control">
                    </div>
                    
                    <div class="input-field">
                        <button class="btn add-cart">APPLY COUPON</button>
                    </div>
                    
                    </form>
                    
                </div>
            </div>-->
            
            <div class="col-md-6">
                <div class="shipping-col">
                        <h4>TOTAL</h4>
                        <div class="subtotal text-right">SUBTOTAL: <i class="fa fa-inr"></i> <?php echo $this->cart->format_number($this->cart->total()); ?></div>
                    <div class="grandtotal text-right">GRAND TOTAL: <i class="fa fa-inr"></i> <?php echo $this->cart->format_number($this->cart->total()); ?></div>
                    <div class="checkout-btn1 text-right"><a href="<?php echo site_url();?>home/checkout" class="add-cart checkout-btn">PROCEED TO CHECKOUT</a></div>
                    <div class="total-text text-right">Checkout with Multiple Addresses</div>
                    
                </div>
            </div>
          
          </div>
          
        </div>
        <!--most selling products ends--> 
        
      </div>
    </div>
  </div>
  <!--main section complete--> 
  
</div>