<?php
$this->load->view('admin/header');
?>

<?php
$this->load->view('admin/session_check');
?>
<body>

<div id="wrapper">

<!-- Navigation -->
<?php 
$this->load->view('admin/navigation');
?> 
<style>
.error{color:#FF0000;
}
</style>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                                                       <?php include("session_msg.php"); ?>

                
                
                    <h3 class="page-header">Change Password</h3>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                           Change Password
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-6">
                                
<form role="form"  method="post" action="<?php echo base_url(); ?>admin/comment/updatepassword" enctype="multipart/form-data" >
                                    
                                    
          <!--  <?php //if($this->session->flashdata('message')){?>
		  <div class="alert alert-success">  
           <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>    
		    <?php //echo $this->session->flashdata('message')?>
		  </div>
		<?php //} ?>  
        -->
                                        <div class="form-group">
                                            <label>Current Password*</label>
          <input type="password"  name="current_password" id="current_password" class="form-control" required placeholder="Current Password*" maxlength="8">
                                            <?php //echo form_error('title'); ?>   
                                        </div>
                                        
                                        
                                        <div class="form-group">
                                            <label>New Password*</label>
          <input type="password"  name="new_pass" id="new_pass" class="form-control" required placeholder="New Password*" onchange="this.setCustomValidity(this.validity.patternMismatch ? 'Must have at least 6 characters' : ''); if(this.checkValidity()) form.con_pass.pattern = this.value;" pattern=".{6,}">
                                        </div>
                                        
                                        
                                        <div class="form-group">
                                            <label>Confirm Password*</label>
          <input type="password"  name="con_pass" id="con_pass" required class="form-control" placeholder="Confirm Password*" onchange="this.setCustomValidity(this.validity.patternMismatch ? 'Please enter the same Password as above' : '');" pattern=".{6,}">
                                             
                                        </div>
                                        
                                        
                                        <button type="submit"  name="submit" class="btn btn-primary btn-sm">Change Password</button>
                                        <a  href="<?php echo base_url(); ?>admin/login/admininbox"><button type="button" class="btn btn-danger btn-sm">Cancel</button></a> 
                                    </form>
                                    
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                                <!-- /.col-lg-6 (nested) -->
                                
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

<!--<link rel="stylesheet" type="text/css" href="<?php //echo base_url(); ?>assets/lib/css/bootstrap.min.css" />
--><link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/src/bootstrap-wysihtml5.css" />
    <script src="<?php echo base_url(); ?>assets/lib/js/wysihtml5-0.3.0.js"></script>
    <script src="<?php echo base_url(); ?>assets/lib/js/jquery-1.7.2.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/lib/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/src/bootstrap3-wysihtml5.js"></script>

<script>
    $('.textarea').wysihtml5();
</script>

   <style type="text/css" media="screen">
        .btn.jumbo {
            font-size: 20px;
            font-weight: normal;
            padding: 14px 24px;
            margin-right: 10px;
            -webkit-border-radius: 6px;
            -moz-border-radius: 6px;
            border-radius: 6px;
        }
    </style>





    <!-- jQuery -->
    
<!--    <script src="<?php echo base_url(); ?>assets/bower_components/jquery/dist/jquery.min.js"></script>
-->
    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo base_url(); ?>assets/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="<?php echo base_url(); ?>assets/bower_components/metisMenu/dist/metisMenu.min.js"></script>

   
    <!-- Custom Theme JavaScript -->
    <script src="<?php echo base_url(); ?>assets/dist/js/sb-admin-2.js"></script>

    

</body>

</html>
