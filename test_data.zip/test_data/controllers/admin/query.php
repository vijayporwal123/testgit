<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Query extends CI_Controller{

public function __construct(){
parent::__construct();
  
    
$this->load->model('admin/adminmodel');
$this->load->library(array('form_validation','session','email'));
$this->load->helper(array('url','html','form'));
$this->load->library('encrypt');
  
$this->output->set_header('Last-Modified:'.gmdate('D, d M Y H:i:s').'GMT');
$this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate');
$this->output->set_header('Cache-Control: post-check=0, pre-check=0',false);
$this->output->set_header('Pragma: no-cache');	 
 }


public function index(){
		
$id =  $this->uri->segment(4) ? $this->uri->segment(4) : 0;	
$table = 'fis_query';
$where  = "where id = '".$id."'  ";
$data['query_reply'] = $this->adminmodel->select($table,$where);			
$this->load->view('admin/queryreply',$data);
}



public function managequery(){
$where  = " order by id desc ";
$data['show_query'] = $this->adminmodel->select('fis_query',$where);
$this->load->view('admin/manage_query',$data);
}


//download code
function output_file($file, $name, $mime_type='')
{
 if(!is_readable($file)) die('File not found or inaccessible!');
 $size = filesize($file);
 $name = rawurldecode($name);
 
 /* Figure out the MIME type | Check in array */
 $known_mime_types=array(
 	"htm" => "text/html",
	"exe" => "application/octet-stream",
	"zip" => "application/zip",
	"doc" => "application/msword",
	"jpg" => "image/jpg",
	"php" => "text/plain",
	"xls" => "application/vnd.ms-excel",
	"ppt" => "application/vnd.ms-powerpoint",
	"gif" => "image/gif",
	"pdf" => "application/pdf",
 	"txt" => "text/plain",
 	"html"=> "text/html",
 	"png" => "image/png",
	"jpeg"=> "image/jpg"
 );
 
 if($mime_type==''){
	 $file_extension = strtolower(substr(strrchr($file,"."),1));
	 if(array_key_exists($file_extension, $known_mime_types)){
		$mime_type=$known_mime_types[$file_extension];
	 } else {
		$mime_type="application/force-download";
	 };
 };
 
 //turn off output buffering to decrease cpu usage
 @ob_end_clean(); 
 
 // required for IE, otherwise Content-Disposition may be ignored
 if(ini_get('zlib.output_compression'))
 ini_set('zlib.output_compression', 'Off');
 header('Content-Type: ' . $mime_type);
 header('Content-Disposition: attachment; filename="'.$name.'"');
 header("Content-Transfer-Encoding: binary");
 header('Accept-Ranges: bytes');
 
 // multipart-download and download resuming support
 if(isset($_SERVER['HTTP_RANGE']))
 {
	list($a, $range) = explode("=",$_SERVER['HTTP_RANGE'],2);
	list($range) = explode(",",$range,2);
	list($range, $range_end) = explode("-", $range);
	$range=intval($range);
	if(!$range_end) {
		$range_end=$size-1;
	} else {
		$range_end=intval($range_end);
	}

	$new_length = $range_end-$range+1;
	header("HTTP/1.1 206 Partial Content");
	header("Content-Length: $new_length");
	header("Content-Range: bytes $range-$range_end/$size");
 } else {
	$new_length=$size;
	header("Content-Length: ".$size);
 }
 
 /* Will output the file itself */
 $chunksize = 1*(1024*1024); //you may want to change this
 $bytes_send = 0;
 if ($file = fopen($file, 'r'))
 {
	if(isset($_SERVER['HTTP_RANGE']))
	fseek($file, $range);
 
	while(!feof($file) && 
		(!connection_aborted()) && 
		($bytes_send<$new_length)
	      )
	{
		$buffer = fread($file, $chunksize);
		echo($buffer); 
		flush();
		$bytes_send += strlen($buffer);
	}
 fclose($file);
 } else
 //If no permissiion
 die('Error - can not open file.');
 //die
die();
}

//download file
public function download(){
 
$id =$this->uri->segment(4) ? $this->uri->segment(4) : 0;
$table = 'fis_query';
$where = "where id = $id ";
$data['download_file'] = $this->adminmodel->select($table,$where);	

if(!empty($data)){
$userfile=$data['download_file'][0]['file_doc'];
$file_path=base_url();
$file_path="user_file/".$userfile;
//echo $file_path;
$this->output_file($file_path, ''.$userfile.'', 'application/msword');
}
}//end code

//for query reply download 

//download code
function output_files($file, $name, $mime_type='')
{
 if(!is_readable($file)) die('File not found or inaccessible!');
 $size = filesize($file);
 $name = rawurldecode($name);
 
 /* Figure out the MIME type | Check in array */
 $known_mime_types=array(
 	"htm" => "text/html",
	"exe" => "application/octet-stream",
	"zip" => "application/zip",
	"doc" => "application/msword",
	"jpg" => "image/jpg",
	"php" => "text/plain",
	"xls" => "application/vnd.ms-excel",
	"ppt" => "application/vnd.ms-powerpoint",
	"gif" => "image/gif",
	"pdf" => "application/pdf",
 	"txt" => "text/plain",
 	"html"=> "text/html",
 	"png" => "image/png",
	"jpeg"=> "image/jpg"
 );
 
 if($mime_type==''){
	 $file_extension = strtolower(substr(strrchr($file,"."),1));
	 if(array_key_exists($file_extension, $known_mime_types)){
		$mime_type=$known_mime_types[$file_extension];
	 } else {
		$mime_type="application/force-download";
	 };
 };
 
 //turn off output buffering to decrease cpu usage
 @ob_end_clean(); 
 
 // required for IE, otherwise Content-Disposition may be ignored
 if(ini_get('zlib.output_compression'))
 ini_set('zlib.output_compression', 'Off');
 header('Content-Type: ' . $mime_type);
 header('Content-Disposition: attachment; filename="'.$name.'"');
 header("Content-Transfer-Encoding: binary");
 header('Accept-Ranges: bytes');
 
 // multipart-download and download resuming support
 if(isset($_SERVER['HTTP_RANGE']))
 {
	list($a, $range) = explode("=",$_SERVER['HTTP_RANGE'],2);
	list($range) = explode(",",$range,2);
	list($range, $range_end) = explode("-", $range);
	$range=intval($range);
	if(!$range_end) {
		$range_end=$size-1;
	} else {
		$range_end=intval($range_end);
	}

	$new_length = $range_end-$range+1;
	header("HTTP/1.1 206 Partial Content");
	header("Content-Length: $new_length");
	header("Content-Range: bytes $range-$range_end/$size");
 } else {
	$new_length=$size;
	header("Content-Length: ".$size);
 }
 
 /* Will output the file itself */
 $chunksize = 1*(1024*1024); //you may want to change this
 $bytes_send = 0;
 if ($file = fopen($file, 'r'))
 {
	if(isset($_SERVER['HTTP_RANGE']))
	fseek($file, $range);
 
	while(!feof($file) && 
		(!connection_aborted()) && 
		($bytes_send<$new_length)
	      )
	{
		$buffer = fread($file, $chunksize);
		echo($buffer); 
		flush();
		$bytes_send += strlen($buffer);
	}
 fclose($file);
 } else
 //If no permissiion
 die('Error - can not open file.');
 //die
die();
}

//download file
public function download1(){
 
$id =$this->uri->segment(4) ? $this->uri->segment(4) : 0;
$table1 = 'fis_query_ans';
$where1 = "where id = $id ";
$data['download_file1'] = $this->adminmodel->select($table1,$where1);	

if(!empty($data)){
$userfile=$data['download_file1'][0]['doc_file'];
$file_path=base_url();
$file_path="user_file/".$userfile;
//echo $file_path;
$this->output_files($file_path, ''.$userfile.'', 'application/msword');
}
}//end code



public function querysubmit(){
            
$this->form_validation->set_rules('reply', 'Query Reply', 'trim|required|xss_clean');
$qid=$this->input->post('quest_id');
$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
if($this->form_validation->run()==false){			
$this->load->view('admin/query/index/'.$qid);		

}

else{	
$upload_dir = base_url();
$upload_dir= 'user_file/';

	$file_name = $_FILES['attach_file']['name'];
	if(!empty($file_name)){
	$temp_name = $_FILES['attach_file']['tmp_name'];
		
	$ext = @pathinfo($file_name, PATHINFO_EXTENSION);
	$file_name= time().rand(1000,99999).'.'.$ext;
   
	$file_path = $upload_dir.$file_name; 
	@move_uploaded_file($temp_name, $file_path);
	
	}else{
	$file_name = '';
	}
	
	$data = array(
	'quest_id' =>$this->input->post('quest_id'),
	'user_id' =>$this->input->post('user_id'),
	'answer' => $this->input->post('reply'),
	'unique_no' => $this->input->post('unique_no'),
	'reply_type' =>'fiscon',
	'doc_file' =>$file_name,
	'status' =>'0',
	'ans_date'=>date('Y-m-d h:i:s')			
	);
	


$emailid=$this->session->userdata('email');
$username=$this->session->userdata('username');

$uquery=$this->input->post('uquery');
$gun=$this->input->post('unique_no');
if(!empty($emailid)){
	
				   $config['mailtype'] = 'html';
				   $config['charset'] = 'iso-8859-1';
				   $config['priority'] = 1;
				   $this->email->initialize($config);
				   $this->email->clear();
				   $message="<html>
					<head>
				<title>Admin Query Reply</title>
					</head>
					<body>";
$message .= "To user: dear <".$username."> ".$gun." one query is posted on fiscon portal by ".$username."<br/>";
					$message .='<div style="width:100%;margin:0 auto;">
								<table width="80%" border="2" align="center" cellpadding="0" cellspacing="0" bordercolor="#003333" style="border:1px solid #820202">
		
		 <tr>
		    <td width="29%" bgcolor="#E1F8FF"><blockquote><strong>User Query:</strong></blockquote></td>
		    <td height="30" align="left" valign="top" nowrap="nowrap" bgcolor="#E1F8FF"><blockquote>'.$uquery.'</blockquote></td>
		  </tr>
		  
		   <tr>
		    <td width="29%" bgcolor="#E1F8FF"><blockquote><strong>Admin Reply:</strong></blockquote></td>
		    <td height="30" align="left" valign="top" nowrap="nowrap" bgcolor="#E1F8FF"><blockquote>'.$this->input->post('reply').'</blockquote></td>
		  </tr>
		  		 
		  </table>
		  <br/>		
		  			
			<br/>
			Thanks
			<br>
			Fiscon Consultant PVT LTD';
							
			$message .="</body></html>";
			$this->email->from($emailid, 'Fiscon Consultant PVT LTD');
			$this->email->to('vijay.porwal@oxygenwebtech.com');
			$this->email->message($message);
			$this->email->subject('Admin Query Reply from fiscon.in');
			$this->email->send();

}


$result = $this->adminmodel->data_insert('fis_query_ans',$data);
	
$msg= $this->session->set_flashdata('message', 'Your replied Successfully');

$qid=$this->input->post('quest_id');
		
if($result){
redirect('admin/query/index/'.$qid, $msg);
}
}	
}


public function editquery(){
   
	   $id =  $this->uri->segment(4) ? $this->uri->segment(4) : 0;
	
	    $query = 'fis_query';
		$where  = "where id = $id  ";
	    $data['query_data'] = $this->adminmodel->select($query,$where);	

        $this->load->view('admin/editquery',  $data);
	
   
    }


public function updatestatus(){

if($this->input->post()){
	
$this->form_validation->set_rules('status', 'Select Status', 'trim|xss_clean'); 
    
//$this->form_validation->set_rules('title', 'News Title', 'trim|required|xss_clean');       	
		
$this->form_validation->set_error_delimiters('<div class="error">', '</div>');


if($this->form_validation->run()==true){
	

if($_POST){
/*$upload_dir1 = base_url();
$upload_dir1= 'news/';

	$file_name1 = $_FILES['photo']['name'];
	
	if(!empty($file_name1)){
	$temp_name1 = $_FILES['photo']['tmp_name'];
		
	$ext1 = @pathinfo($file_name1, PATHINFO_EXTENSION);
	$file_name1= time().rand(1000,99999).'.'.$ext1;
   
	$file_path1 = $upload_dir1.$file_name1; 
	@move_uploaded_file($temp_name1, $file_path1);
	}		*/
	
	
	 $eid = $this->input->post("eid");
	 $status = $this->input->post("status");
	 $data =array('status'=>$status);	
		//print_r($data); 
	 $query =  'fis_query';
	 $id1 = $this->adminmodel->data_update(array("id"=>$eid),$query,$data);
		//print_r($id1);
    $msg1=$this->session->set_flashdata('message', 'Your data updated Successfully..');
			
		 if($id1){
		    redirect('admin/query/managequery',$msg1);
			
		}
	
	}
	
	}//validation if end
	else{
		
	    $id =$this->uri->segment(4) ? $this->uri->segment(4) : 0;
	    $query1 = 'fis_query';
		$where1  = "where id = $id";
	    $data['query_data'] = $this->adminmodel->select($query1,$where1);	
        $this->load->view('admin/editquery',  $data);

	}
	
	}
	else{
		
	    $id =$this->uri->segment(4) ? $this->uri->segment(4) : 0;
	    $query1 = 'fis_query';
		$where1  = "where id = $id";
	    $data['query_data'] = $this->adminmodel->select($query1,$where1);	
        $this->load->view('admin/editquery',  $data);

	}
	
	
	
}




public function deletequery($id)
{  	
$id = $this->uri->segment(4) ? $this->uri->segment(4) : 0;	
$this->db->where('id', $id);
$this->db->delete('fis_query');
$this->session->set_flashdata('message', 'Your data deleted Successfully..');
redirect('admin/query/managequery');
}	
	
	



}
?>