<?php
$this->load->view('admin/header');
?>
<?php
$this->load->view('admin/session_check');
?>
<?php
if(!empty($newsdata)){
//echo"<pre>";
//print_r($blogdata);
   $id = $newsdata[0]['id'];
   $news = $newsdata[0]['news'];
   $title = $newsdata[0]['title'];
   $image = $newsdata[0]['image'];
   $status = $newsdata[0]['status'];
  
  
}
?>


<body>

<div id="wrapper">

<!-- Navigation -->
<?php 
$this->load->view('admin/navigation');
?> 
<style>
.error{color:#FF0000;
}
</style>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h3 class="page-header">Edit News</h3>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                           News Form
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-6">
                                
                                    <form role="form"  method="post" action="<?php echo base_url(); ?>admin/news/updatenews/<?php echo $id; ?>" enctype="multipart/form-data" >
                                 <input type="hidden" name="eid" value="<?php echo $id; ?>">   
                                 
                                 
                                 
                                 
<div class="form-group">
<label>News Title<span class="error">*</span></label>									
<input class="form-control"  name="title" placeholder="Enter Title*"  type="text" value="<?php echo $title; ?>" >
<?php echo form_error('title'); ?>
</div>			
							
							
							
<div class="form-group">
<label>Upload image</label>										
<input type="file" class="form-control"  name="photo" onChange="ValidateSingleInput(this);">

	<?php
    if(!empty($image)){?>
    <image src="<?php echo base_url();?>news/<?php echo $image; ?>" style="width:100px; height:100px;" >      
    <?php
    }else{?>                
    <image src="<?php echo base_url();?>user_photo/default.png" style="width:100px; height:100px;" type="image/jpg">
    <?php
    }
    ?>
    
</div>						 
								 
			                                                                 
<div class="form-group">
<label>News Description<span class="error">* </span></label>
<!--<textarea class="form-control" id="txtEditor" name="desc" rows="3"></textarea>-->
<textarea class="form-control" placeholder="Enter News ..."  name="news" ><?php echo $news;?></textarea>

<?php echo form_error('news'); ?>   

</div>
                                                                                
                                       <div class="form-group">
                                            <label>Status</label>
                                            <select class="form-control" name="status">

                                           <option value="0"<?php if($status=='0'){
												echo 'selected="selected" ';
												}?>>De-Active</option>

                                               <option value="1"<?php if($status=='1'){
												echo 'selected="selected" ';
												}?>>Active</option>
                                                
                                            </select>
                                            
                                           <?php //echo form_error('tags'); ?>   
                                        </div> 
                                        
                                        <button type="submit"  name="submit" class="btn btn-primary btn-sm">Update</button>
                                        <a  href="<?php echo base_url(); ?>admin/news/index"><button type="button" class="btn btn-danger btn-sm">Cancel</button></a> 
                                    </form>
                                    
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                                <!-- /.col-lg-6 (nested) -->
                                
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

<!--<link rel="stylesheet" type="text/css" href="<?php //echo base_url(); ?>assets/lib/css/bootstrap.min.css" />
--><link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/src/bootstrap-wysihtml5.css" />
    <script src="<?php echo base_url(); ?>assets/lib/js/wysihtml5-0.3.0.js"></script>
    <script src="<?php echo base_url(); ?>assets/lib/js/jquery-1.7.2.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/lib/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/src/bootstrap3-wysihtml5.js"></script>

<script>
    $('.textarea').wysihtml5();
</script>

   <style type="text/css" media="screen">
        .btn.jumbo {
            font-size: 20px;
            font-weight: normal;
            padding: 14px 24px;
            margin-right: 10px;
            -webkit-border-radius: 6px;
            -moz-border-radius: 6px;
            border-radius: 6px;
        }
    </style>





    <!-- jQuery -->
    
<!--    <script src="<?php echo base_url(); ?>assets/bower_components/jquery/dist/jquery.min.js"></script>
-->
    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo base_url(); ?>assets/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="<?php echo base_url(); ?>assets/bower_components/metisMenu/dist/metisMenu.min.js"></script>

   
    <!-- Custom Theme JavaScript -->
    <script src="<?php echo base_url(); ?>assets/dist/js/sb-admin-2.js"></script>

     <script>
	//[".jpg", ".jpeg", ".gif", ".png", ".mp4", ".3gp", ".ogg", ".avi", ".mkv", ".mpeg"]
 var _validFileExtensions1 = [".jpg", ".jpeg", ".gif", ".png", ".mp4", ".3gp", ".ogg", ".avi", ".mkv", ".mpeg"];    
function ValidateSingleInput1(oInput) {
    if (oInput.type == "file") {
        var sFileName = oInput.value;
         if (sFileName.length > 0) {
            var blnValid = false;
            for (var j = 0; j < _validFileExtensions1.length; j++) {
                var sCurExtension = _validFileExtensions1[j];
                if (sFileName.substr(sFileName.length - sCurExtension.length, sCurExtension.length).toLowerCase() == sCurExtension.toLowerCase()) {
                    blnValid = true;
                    break;
                }
            }
             
            if (!blnValid) {
                alert("Sorry, " + sFileName + " is invalid file extension, allowed file type extensions are only: " + _validFileExtensions1.join(", "));
                oInput.value = "";
                return false;
            }
        }
    }
    return true;
}
 
 
 
 </script>




<script>
 var _validFileExtensions = [".jpg", ".jpeg", ".png",".JPEG"];    
function ValidateSingleInput(oInput) {
    if (oInput.type == "file") {
        var sFileName = oInput.value;
         if (sFileName.length > 0) {
            var blnValid = false;
            for (var j = 0; j < _validFileExtensions.length; j++) {
                var sCurExtension = _validFileExtensions[j];
                if (sFileName.substr(sFileName.length - sCurExtension.length, sCurExtension.length).toLowerCase() == sCurExtension.toLowerCase()) {
                    blnValid = true;
                    break;
                }
            }
             
            if (!blnValid) {
                alert("Sorry, " + sFileName + " is invalid file extension, allowed file type extensions are only: " + _validFileExtensions.join(", "));
                oInput.value = "";
                return false;
            }
        }
    }
    return true;
}
 
 
 
 </script>












</body>

</html>
