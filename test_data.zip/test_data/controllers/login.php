<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Login extends CI_Controller {

public function __construct(){
  parent::__construct();
  $this->load->model('user_model');
  $this->load->library(array('form_validation','session','email'));
  $this->load->helper(array('url','html','form')); 
  $this->load->helper('download');
  $this->load->library('pagination');

  
$this->output->set_header('Last-Modified:'.gmdate('D, d M Y H:i:s').'GMT');
$this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate');
$this->output->set_header('Cache-Control: post-check=0, pre-check=0',false);
$this->output->set_header('Pragma: no-cache');			
 }
 
	
public function index()
{
$this->load->view('login');		
}


public function forgotpassword()
{
$this->load->view('forgotpass');		
}


public function forgot_password_verify()
{
	
        $email = $this->input->post('email');
	    $USER =  'fis_users';
		$where  = "where email = '$email' ";
	    $data['forgot'] = $this->user_model->select($USER,$where);	
		//$this->load->view('admin/partners',$data);
		//print_r($data);
		if(!empty($data)){ 
		
		//foreach($data as $value){
		$emailid= $data['forgot'][0]['email'];
		$code= $data['forgot'][0]['email_confirm_code'];

		//echo $emailid;
		if(!empty($emailid)){
		
		
		$config['mailtype'] = 'html';
						   $config['charset'] = 'iso-8859-1';
						   $config['priority'] = 1;
						   $this->email->initialize($config);
						   $this->email->clear();
						   $message="<html>
								<head>
								<title>Forgot password</title>
								</head>
								<body>";
							$message .= "Hello, "."<br/><br/>
							Please follow link below and choose your new password.<br/><br/>";
							$message .='<a href="http://fiscon.in/fiscon2/admin/login/resetpassword/'.$code.'" target="_blank">http://fiscon.in/fiscon2/admin/login/resetpassword/'.$code.'</a> 
								<br/><br/>';
								
							$message .="</body></html>";
							$this->email->from('info@fiscon.in', 'Fiscon Consultant PVT LTD ');
							$this->email->to($emailid);
							$this->email->message($message);
							$this->email->subject('Fiscon Consultant:Forgot Password');
							if($this->email->send()){
								
$msg='Reset password link has been sent to your emaild ';

echo "<script type='text/javascript'>
alert('$msg');
 window.location.href='http://fiscon.in/fiscon2/login/forgotpassword'
</script>";														
}
								
else{								
$msg='email not sent ';
echo "<script type='text/javascript'>
alert('$msg');
 window.location.href='http://fiscon.in/fiscon2/login/forgotpassword'
</script>";								
}
		
}
else{
		//echo "email id doesn't exist";		
$msg='email id doesn t exist ';
echo "<script type='text/javascript'>
alert('$msg');
 window.location.href='http://fiscon.in/fiscon2/login/forgotpassword'
</script>";
			
  }
}
		
else{
		//echo "data not found";
$msg='data not found ';
echo "<script type='text/javascript'>
alert('$msg');
window.location.href='http://fiscon.in/fiscon2/login/forgotpassword'
</script>";
	
}

//http://fiscon.in/admin/login/forgotpassword
		
}//end




public function userdoc(){   
$id =  $this->session->userdata('id');	
$data['user_data'] = $this->user_model->result_userfiles($id);
$this->load->view('user_doc',$data);	
}


public function managequery($offset=0)
{	

//echo $userid=$this->session->userdata('id');	

$config['total_rows'] = $this->user_model->totalQuery();
$config['base_url'] = base_url()."login/managequery";
$config['per_page'] = 5;
$config['uri_segment']='3';
  

$config['full_tag_open'] = "<ul class='pagination'>";
$config['full_tag_close'] ="</ul>";
$config['num_tag_open'] = '<li>';
$config['num_tag_close'] = '</li>';
$config['cur_tag_open'] = "<li class='disabled'><li class='active'><a href='#'>";
$config['cur_tag_close'] = "<span class='sr-only'></span></a></li>";
$config['next_tag_open'] = "<li>";
$config['next_tagl_close'] = "</li>";
$config['prev_tag_open'] = "<li>";
$config['prev_tagl_close'] = "</li>";
$config['first_tag_open'] = "<li>";
$config['first_tagl_close'] = "</li>";
$config['last_tag_open'] = "<li>";
$config['last_tagl_close'] = "</li>";



  $this->pagination->initialize($config);
   
  $query = $this->user_model->getQuery(5,$this->uri->segment(3));
  
  $data['show_query'] = null;
  
  if($query){
   $data['show_query'] =  $query;
  }

  $this->load->view('querylist', $data);


//$a=$this->session->userdata('id');		
//echo $a;
//$where  = "where user_id='".$a."' order by id desc";
//$data['show_query'] = $this->user_model->select('fis_query',$where);	
//$this->load->view('querylist',$data);		
}


public function queryreply(){
		
$id =  $this->uri->segment(3) ? $this->uri->segment(3) : 0;	
$table = 'fis_query';
$where  = "where id = '".$id."'  ";
$data['query_reply'] = $this->user_model->select($table,$where);			
$this->load->view('queryreply',$data);
}


public function submitquery(){
            
$this->form_validation->set_rules('reply', 'Query Reply', 'trim|required|xss_clean');
$qid=$this->input->post('quest_id');
$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
if($this->form_validation->run()==false){			
$this->load->view('login/queryreply/'.$qid);		
//$this->load->view('admin/queryreply'); 
//redirect('admin/addusers');
}

else{	
$upload_dir = base_url();
$upload_dir= 'user_file/';

	$file_name = $_FILES['attach_file']['name'];
	if(!empty($file_name)){
	$temp_name = $_FILES['attach_file']['tmp_name'];
		
	$ext = @pathinfo($file_name, PATHINFO_EXTENSION);
	$file_name= time().rand(1000,99999).'.'.$ext;
   
	$file_path = $upload_dir.$file_name; 
	@move_uploaded_file($temp_name, $file_path);
	
	}else{
	$file_name = '';
	}

//upload photo	
		 
	$data = array(
	'quest_id' =>$this->input->post('quest_id'),
	'user_id' =>$this->input->post('user_id'),
	'answer' => $this->input->post('reply'),
	'unique_no' => $this->input->post('unique_no'),
	'reply_type' =>'user',
	'doc_file' =>$file_name,
	'status' =>'0',
	'ans_date'=>date('Y-m-d h:i:s')
	);
		

$emailid=$this->session->userdata('email');
$username=$this->session->userdata('username');
$uquery=$this->input->post('uquery');
$gun=$this->input->post('unique_no');
if(!empty($emailid)){
	
				   $config['mailtype'] = 'html';
				   $config['charset'] = 'iso-8859-1';
				   $config['priority'] = 1;
				   $this->email->initialize($config);
				   $this->email->clear();
				   $message="<html>
					<head>
				<title>User Query Reply</title>
					</head>
					<body>";
					//$message .= "hello sir, GUN ".$gun."<br/>";
					$message .= "To admin: dear <".$username."> ".$gun." one query is posted on fiscon portal by ".$username."<br/>";
					
					$message .='<div style="width:100%;margin:0 auto;">
								<table width="80%" border="2" align="center" cellpadding="0" cellspacing="0" bordercolor="#003333" style="border:1px solid #820202">
		
		 <tr>
		    <td width="29%" bgcolor="#E1F8FF"><blockquote><strong>User Query:</strong></blockquote></td>
		    <td height="30" align="left" valign="top" nowrap="nowrap" bgcolor="#E1F8FF"><blockquote>'.$uquery.'</blockquote></td>
		  </tr>
		  
		   <tr>
		    <td width="29%" bgcolor="#E1F8FF"><blockquote><strong>Query Reply:</strong></blockquote></td>
		    <td height="30" align="left" valign="top" nowrap="nowrap" bgcolor="#E1F8FF"><blockquote>'.$this->input->post('reply').'</blockquote></td>
		  </tr>
		  		 
		  </table>
		  <br/>					
					<br/>
					Thanks
					<br>
					Fiscon Consultant PVT LTD';
					
							
							$message .="</body></html>";
							$this->email->from($emailid, 'Fiscon Consultant PVT LTD');
							$this->email->to('vijay.porwal@oxygenwebtech.com');
							$this->email->message($message);
							$this->email->subject('User Query Reply from fiscon.in');
                            $this->email->send();

}




$result = $this->user_model->data_insert('fis_query_ans',$data);
	
$msg= $this->session->set_flashdata('message', 'Your replied Successfully');

$qid=$this->input->post('quest_id');
		
if($result){
redirect('login/queryreply/'.$qid, $msg);
}
}	
}

//download code
function output_file($file, $name, $mime_type='')
{
 if(!is_readable($file)) die('File not found or inaccessible!');
 $size = filesize($file);
 $name = rawurldecode($name);
 
 /* Figure out the MIME type | Check in array */
 $known_mime_types=array(
 	"htm" => "text/html",
	"exe" => "application/octet-stream",
	"zip" => "application/zip",
	"doc" => "application/msword",
	"jpg" => "image/jpg",
	"php" => "text/plain",
	"xls" => "application/vnd.ms-excel",
	"ppt" => "application/vnd.ms-powerpoint",
	"gif" => "image/gif",
	"pdf" => "application/pdf",
 	"txt" => "text/plain",
 	"html"=> "text/html",
 	"png" => "image/png",
	"jpeg"=> "image/jpg"
 );
 
 if($mime_type==''){
	 $file_extension = strtolower(substr(strrchr($file,"."),1));
	 if(array_key_exists($file_extension, $known_mime_types)){
		$mime_type=$known_mime_types[$file_extension];
	 } else {
		$mime_type="application/force-download";
	 };
 };
 
 //turn off output buffering to decrease cpu usage
 @ob_end_clean(); 
 
 // required for IE, otherwise Content-Disposition may be ignored
 if(ini_get('zlib.output_compression'))
 ini_set('zlib.output_compression', 'Off');
 header('Content-Type: ' . $mime_type);
 header('Content-Disposition: attachment; filename="'.$name.'"');
 header("Content-Transfer-Encoding: binary");
 header('Accept-Ranges: bytes');
 
 // multipart-download and download resuming support
 if(isset($_SERVER['HTTP_RANGE']))
 {
	list($a, $range) = explode("=",$_SERVER['HTTP_RANGE'],2);
	list($range) = explode(",",$range,2);
	list($range, $range_end) = explode("-", $range);
	$range=intval($range);
	if(!$range_end) {
		$range_end=$size-1;
	} else {
		$range_end=intval($range_end);
	}

	$new_length = $range_end-$range+1;
	header("HTTP/1.1 206 Partial Content");
	header("Content-Length: $new_length");
	header("Content-Range: bytes $range-$range_end/$size");
 } else {
	$new_length=$size;
	header("Content-Length: ".$size);
 }
 
 /* Will output the file itself */
 $chunksize = 1*(1024*1024); //you may want to change this
 $bytes_send = 0;
 if ($file = fopen($file, 'r'))
 {
	if(isset($_SERVER['HTTP_RANGE']))
	fseek($file, $range);
 
	while(!feof($file) && 
		(!connection_aborted()) && 
		($bytes_send<$new_length)
	      )
	{
		$buffer = fread($file, $chunksize);
		echo($buffer); 
		flush();
		$bytes_send += strlen($buffer);
	}
 fclose($file);
 } else
 //If no permissiion
 die('Error - can not open file.');
 //die
die();
}

//download file
public function download(){
 
$id =$this->uri->segment(3) ? $this->uri->segment(3) : 0;
$table = 'fis_query_ans';
$where = "where id = $id ";
$data['download_file'] = $this->user_model->select($table,$where);	

if(!empty($data)){
$userfile=$data['download_file'][0]['doc_file'];
$file_path=base_url();
$file_path="user_file/".$userfile;
//echo $file_path;
$this->output_file($file_path, ''.$userfile.'', 'application/msword');
}
}//end code


public function user_download(){

$id =  $this->uri->segment(3) ? $this->uri->segment(3) : 0;
$files = 'fis_files';
$where = "where id = $id ";
$data['download_file'] = $this->user_model->select($files,$where);	
//$this->load->view('admin/edituser',$data);

if(!empty($data)){
$userfile=$data['download_file'][0]['file_name'];
$file_path=base_url();
$file_path="files/".$userfile;
//echo $file_path;
$this->output_file($file_path, ''.$userfile.'', 'application/msword');
}

}



public function addquery()
{
$this->load->view('queryform');		
}


public function userinbox(){
$this->load->view('userinbox'); 
}


function logout(){
$this->session->sess_destroy();
redirect('http://localhost/fiscon_admin/');
}



 function signin(){

  $email= trim($this->input->post('email'));
  $password= trim($this->input->post('password'));
  $userstatus= '1';
  $adminstatus='1';
  
  $query = $this->user_model->processLogin($email,$password,$userstatus,$adminstatus);

  $this->form_validation->set_rules('email', 'E-mail', 'required|callback_validateUser[' . $query->num_rows() . ']');
  $this->form_validation->set_rules('password', 'Password', 'required');

  $this->form_validation->set_error_delimiters('<div class="error">', '</div>');
  $this->form_validation->set_message('required', 'Enter %s');

  if($this->form_validation->run() == FALSE){
   $this->load->view('login');
  }
  
  else{
  
if($query){
$query = $query->result();
$user_type=$query[0]->user_type;
	
if($user_type=='admin'){
		
    $user = array(
     'id' => $query[0]->id,
	 'username' => $query[0]->username,
     'email' => $query[0]->email,
	  'user_type' => $query[0]->user_type,
    );

$data['login_user']= $this->session->set_userdata($user);
redirect('admin/login/admininbox',$data);

}else if($user_type=='user'){

$user = array(
     'id' => $query[0]->id,
	 'username' => $query[0]->username,
     'email' => $query[0]->email,
	  'user_type' => $query[0]->user_type,
    );

$data['login_user']=$this->session->set_userdata($user);
redirect('login/userinbox',$data);
}

else if($user_type=='executive'){

$user = array(
     'id' => $query[0]->id,
	 'username' => $query[0]->username,
     'email' => $query[0]->email,
	  'user_type' => $query[0]->user_type,
    );

$data['login_user']= $this->session->set_userdata($user);
redirect('admin/login/admininbox',$data);
}

else{
}
  
}
}
}


 /** Custom Validation Method*/
 public function validateUser($email,$recordCount){
  if ($recordCount != 0){
   return TRUE;
  }else{
   $this->form_validation->set_message('validateUser', 'Invalid %s or Password');
   return FALSE;
  }
 }


//add comment
public function querysubmit(){
error_reporting(0);
$this->form_validation->set_rules('subject', 'Subject', 'trim|required|xss_clean');
$this->form_validation->set_rules('query', 'Query', 'trim|required|xss_clean');    
$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
if($this->form_validation->run()==true){

$upload_dir = base_url();
$upload_dir= 'user_file/';

	$file_name = $_FILES['attach']['name'];
	if(!empty($file_name)){
	$temp_name = $_FILES['attach']['tmp_name'];
		
	$ext = @pathinfo($file_name, PATHINFO_EXTENSION);
	$file_name= time().rand(1000,99999).'.'.$ext;
   
	$file_path = $upload_dir.$file_name; 
	@move_uploaded_file($temp_name, $file_path);
	
	}else{
	$file_name = '';
	}



$data = array(
'subject' =>$this->input->post('subject'),
'query' =>$this->input->post('query'),
'user_id' =>$this->input->post('user_id'),
'file_doc' =>$file_name,
'unique_no' =>mt_rand(100000, 999999),
'create_date'=>date('Y-m-d h:i:s'),
'status'=>'0',
);


$emailid=$this->session->userdata('email');
$username=$this->session->userdata('username');

$gun=mt_rand(100000, 999999);
if(!empty($emailid)){
	
				   $config['mailtype'] = 'html';
				   $config['charset'] = 'iso-8859-1';
				   $config['priority'] = 1;
				   $this->email->initialize($config);
				   $this->email->clear();
				   $message="<html>
					<head>
				<title>User Query</title>
					</head>
					<body>";
$message .= "To admin: dear <".$username."> ".$gun." one query is posted on fiscon portal by ".$username."<br/>";

					$message .='<div style="width:100%;margin:0 auto;">
								<table width="80%" border="2" align="center" cellpadding="0" cellspacing="0" bordercolor="#003333" style="border:1px solid #820202">
		
		 <tr>
		    <td width="29%" bgcolor="#E1F8FF"><blockquote><strong>Subject:</strong></blockquote></td>
		    <td height="30" align="left" valign="top" nowrap="nowrap" bgcolor="#E1F8FF"><blockquote>'.$this->input->post('subject').'</blockquote></td>
		  </tr>
		  
		   <tr>
		    <td width="29%" bgcolor="#E1F8FF"><blockquote><strong>Query:</strong></blockquote></td>
		    <td height="30" align="left" valign="top" nowrap="nowrap" bgcolor="#E1F8FF"><blockquote>'.$this->input->post('query').'</blockquote></td>
		  </tr>
		  
		  
		 
		  </table>
		  <br/>					
					<br/>
					Thanks
					<br>
					Fiscon Consultant PVT LTD';
					
							
							$message .="</body></html>";
							$this->email->from($emailid, 'Fiscon Consultant PVT LTD');
							$this->email->to('vijay.porwal@oxygenwebtech.com');
							$this->email->message($message);
							$this->email->subject('User Query from fiscon.in');
                            $this->email->send();

}


$result = $this->user_model->data_insert('fis_query',$data);	
$msg= $this->session->set_flashdata('message', 'Your query submitted Successfully..');	
if($result){
redirect('login/managequery', $msg);
}
}
		  
else{
$this->load->view('queryform'); 
}
	
}



}//contoller  end

