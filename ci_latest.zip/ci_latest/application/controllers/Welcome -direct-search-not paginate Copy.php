<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {


public function __construct(){
parent::__construct();
$this->load->library('pagination');
}

public function index()
{
$this->load->view('welcome_message');
}




public function users()
{
//echo "IDS1:".$id=$this->uri->segment(3);
//echo "IDS2:".$id=$this->uri->segment(4);
//echo "IDS3:".$id=$this->uri->segment(5);
//echo "IDS4:".$id=$this->uri->segment(6);
//$this->load->view('welcome_message');


$segs = $this->uri->segment_array();

foreach ($segs as $segment)
{
        echo $segment;
        echo '<br />';
}

}

public function create_form()
{
$this->load->view('create_form');
}

public function insert()
{
//$this->load->view('create_form');
//print_r($_POST);
$data = array(
'email' => $this->input->post('email'),
'password' => $this->input->post('password')
);

$result=$this->productmodel->insert('user',$data);
//echo $result."success";
redirect('welcome/select');
}


public function select(){

		$config['base_url'] = base_url()."welcome/select";
        $config['total_rows'] = $this->productmodel->totalusers();

        $config['per_page'] = "2";
        $config["uri_segment"] = 3;
        $choice = $config["total_rows"] / $config["per_page"];
        $config["num_links"] = floor($choice);

        //config for bootstrap pagination class integration
        $config['full_tag_open'] = '<ul class="pagination">';
        $config['full_tag_close'] = '</ul>';
        $config['first_link'] = false;
        $config['last_link'] = false;
        $config['first_tag_open'] = '<li>';
        $config['first_tag_close'] = '</li>';
        $config['prev_link'] = '&laquo';
        $config['prev_tag_open'] = '<li class="prev">';
        $config['prev_tag_close'] = '</li>';
        $config['next_link'] = '&raquo';
        $config['next_tag_open'] = '<li>';
        $config['next_tag_close'] = '</li>';
        $config['last_tag_open'] = '<li>';
        $config['last_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="active"><a href="#">';
        $config['cur_tag_close'] = '</a></li>';
        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';

        $this->pagination->initialize($config);
        $data['page'] = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;

        //call the model function to get the department data
        $data['results'] = $this->productmodel->select('user',$config["per_page"], $data['page']);           

        $data['pagination'] = $this->pagination->create_links();

        //load the department_view
        $this->load->view('userlist',$data);
    }


public function search()
{

print_r($_POST);
$email=$this->input->post('email');

if(!empty($email)){
$data['results']=$this->productmodel->search_data($email);

$data['page']='';
 $data['pagination']='';

 $this->load->view('userlist',$data);
}else{
	redirect($this->select());
}





	}


public function edituser(){
echo $id=$this->uri->segment(3);
//print_r($data);
$data['result']=$this->productmodel->find_id('user' ,$id);
//print_r($data);
$this->load->view('editform',$data);
}


public function update()
{
$id =  $this->input->post('user_id');
 //die;
$data = array(
'email' => $this->input->post('email'),
'password' => $this->input->post('password')
);
$where = array('id'=>$id);
//$this->productmodel->where('id'=$id);
$result['data']=$this->productmodel->update('user',$where,$data);
//echo $result."success";
$msg1=$this->session->set_flashdata('message', 'Your data updated Successfully..');

redirect('welcome/select',$msg1);
}




public function deleteuser(){
$id1=$this->uri->segment(3);
$id = array('id'=>$id1);
$data['response']=$this->productmodel->delete('user' ,$id);
//print_r($data);
//echo "success";
redirect('welcome/select');
//$this->load->view('userlist',$data);
}



}
