<?php
$smsg = $this->session->userdata('msg');
$eres = $this->session->userdata('res');
if($smsg!='') { ?>  
<div class="<?php if($eres==0) {  echo $h= 'alert alert-danger fade in'; }
if($eres==1){ echo $h='alert alert-success fade in'; } ?>"><?php if(! is_null($smsg)) echo "<a href='#' class='close' data-dismiss='alert'>&times;</a>"; echo $smsg; 
$this->session->unset_userdata('msg');
$this->session->unset_userdata('res'); ?></div>
<?php  } ?>
<?php if(validation_errors()) { ?>
      <div class="alert alert-warning"> <?php echo validation_errors(); ?> </div>
      <?php } ?>

