<?php $this->load->view('header');?>
<div class="tp-page-header"> 
  <!-- full page header -->
  <div class="container">
    <div class="row">
      <div class="col-md-7">
        <div class=""> 
          <!-- page header  -->
          <br>
          <h2>Career Form</h2>
        </div>
        <!-- page header  --> 
      </div>
    </div>
  </div>
</div>
<!-- /.full page header-->
<div class="tp-breadcrumb">
  <div class="container">
    <div class="row">
      <div class="col-md-8">
        <ol class="breadcrumb">
          <li><a href="<?php echo base_url(); ?>front/index">Home</a></li>
          <li class="active">Career Form</li>
        </ol>
      </div>
      <div class="col-md-4">
        
      </div>
    </div>
  </div>
</div>
<!-- /.breadcrumb -->

<style>
.error{color:#FF0000;
}
</style>

<div class="main-container" id="main-container"> 
  <!--Main container start-->
  <div class="tp-career-form" id="tp-career-form"><!--career-form-->
    <div class="container">
      <div class="row">
        <div class="col-md-12 tp-title">
        </div>
        <div class="col-md-offset-1 col-md-10 career-form">
          <form class="form" method="post" action="<?php echo base_url();?>front/careersubmit" enctype="multipart/form-data">
          
<p><span class="error">* required field.</span></p>     
          
            <div class="col-md-6">
              <label class="control-label" for="firstname">First Name<span class="error">* </span></label>
              <input  type="text"  id="firstname" name="firstname" class="form-control" placeholder="First Name"  value="<?php echo set_value('firstname'); ?>">
              
<?php echo form_error('firstname'); ?>
            </div>
            
            <div class="col-md-6">
              <label class="control-label" for="lastname">Last Name<span class="error">* </span></label>
              <input  type="text"  id="lastname" name="lastname" class="form-control" placeholder="last Name" value="<?php echo set_value('lastname'); ?>">
<?php echo form_error('lastname'); ?>

            </div>
            
            <div class="col-md-6">
              <label class="control-label" for="email">E-mail<span class="error">* </span></label>
              <input  type="email"  id="email" name="email" class="form-control" placeholder="E-mail ID" value="<?php echo set_value('email'); ?>">
<?php echo form_error('email'); ?>

            </div>
            
             <div class="col-md-6">
              <label class="control-label" for="city">Mobile Number<span class="error">* </span></label>
<input  type="text"  id="mobile_no" name="mobile_no" class="form-control" placeholder="Mobile Number" value="<?php echo set_value('mobile_no'); ?>">
<?php echo form_error('mobile_no'); ?>

            </div>
            
            
            <div class="col-md-6">
              <label class="control-label" for="city">Qualification</label>
<input  type="text"  id="quali" name="quali" class="form-control" placeholder="Qualification" value="<?php echo set_value('quali'); ?>">

<?php echo form_error('quali'); ?>

            </div>
            
<div class="col-md-6">
<label class="control-label" for="city">Applied For<span class="error">* </span></label>
<input  type="text"  id="applied_for" name="applied_for" class="form-control" placeholder="Applied For" value="<?php echo set_value('applied_for'); ?>">

  <?php echo form_error('applied_for'); ?>
            </div>
            
<div class="col-md-6">
<label class="control-label" for="city">Upload Resume(Allow only doc,pdf file)<span class="error">* </span></label>
<input type="file" class="form-control" name="cv"   onChange="ValidateSingleInput(this);"   required>
 <?php //echo form_error('cv'); ?>

</div>
            
            
<div class="col-md-6">
<label class="control-label" for="city">Captcha<span class="error">* </span></label>
<div class="g-recaptcha" data-sitekey="6LcntyUTAAAAAMiyaegXBpvPB4OhAcMFGm4mm9AE"></div>
  <?php echo form_error('g-recaptcha-response'); ?>
</div> 
            
<div class="col-md-12">
<button type="submit"  name="submit" class="btn tp-btn tp-btn-orange">Submit </button>
</div>
            
          </form>
        </div>
      </div>
    </div>
  </div>
  <!--/.career-form--> 
</div>
<!-- /.Main container start-->
<?php /*?><div class="tp-newsletter"> 
  <!-- Newsletter -->
  <div class="container">
    <div class="row">
      <div class="col-md-5 news-title"> 
        <!-- section title -->
        <h2><i class="fa fa-envelope-o"></i>Register to Peace Newsletter</h2>
      </div>
      <div class="col-md-7 newsletter"><!-- Newsletter form -->
        <form method="post" action="newsletter.php">
          <div class="input-group">
            <label class="sr-only control-label" for="newsletter">Newsletter</label>
            <input type="email" id="newsletter" name="newsletter" class="form-control" placeholder="E-mail Address">
            <span class="input-group-btn">
            <button class="btn tp-btn-orange" type="submit">Submit</button>
            </span> </div>
        </form>
        <!-- /input-group --> 
        </div>
      <!-- Newsletter form --> 
    </div>
  </div>
</div><?php */?>
<?php  $this->load->view('footer');?>
<script>
 var _validFileExtensions = [".doc", ".docx", ".pdf" ];    
function ValidateSingleInput(oInput) {
    if (oInput.type == "file") {
        var sFileName = oInput.value;
         if (sFileName.length > 0) {
            var blnValid = false;
            for (var j = 0; j < _validFileExtensions.length; j++) {
                var sCurExtension = _validFileExtensions[j];
                if (sFileName.substr(sFileName.length - sCurExtension.length, sCurExtension.length).toLowerCase() == sCurExtension.toLowerCase()) {
                    blnValid = true;
                    break;
                }
            }
             
            if (!blnValid) {
                alert("Sorry, " + sFileName + " is invalid file extension, allowed extensions are only: " + _validFileExtensions.join(", "));
                oInput.value = "";
                return false;
            }
        }
    }
    return true;
}
 
 </script>