<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

function ago($timestamp){
if(empty($timestamp))
 return false;
 
 $time = time();
 if($time > $timestamp)
  $difference = time() - $timestamp;
  else
   $difference = $timestamp - time();
   
  $periods = array('second', 'minute', 'hour', 'day', 'week', 'month', 'years', 'decade');
  $lengths = array('60', '60', '24', '7', '4.35', '12', '10');

  for($j = 0; $difference >= $lengths[$j]; $j++) $difference /= $lengths[$j];

  $difference = round($difference);
  if($difference != 1) $periods[$j] .= "s";

  return "$difference $periods[$j] ago";
}

function dob_age($timestamp){
if(empty($timestamp))
 return false;
   $difference = abs(time() - $timestamp);
  return $years = floor($difference/(60*60*24*365));
}

function getUserDetails($id = ''){
        $CI = & get_instance();
        $CI->load->model('admin/adminmodel');
		if(empty($id)){
		   $id = $CI->session->userdata('id');
		}
				
		$where = "where id = '".$id."'";
	    $result = $CI->adminmodel->select('fis_users',$where);
        return $result;
}

function srtingucwords($words){
    return ucwords($words);
}
function getCofigrationVariable(){
        $CI = & get_instance();
        $CI->load->database();
				
	 $sql = "select * from cofigration_setting";
	 $query = $CI->db->query($sql);
	 if($query->num_rows()>0)
	 {
	   $result = $query->result_array();
	   return $result = $result[0];
	 }else{
	    return false; 
	 }
}

function ImagesCheck($imagesName,$imageDir){

  $avatar_images_url =  config_item('avatar_images_url');
if($imageDir == 'images_url'){
  $avatar_images_url =  config_item('images_url');
}else if($imageDir == 'category_icon_url'){
  $avatar_images_url =  config_item('category_icon_url');
}else if($imageDir == 'subscription_images_url'){
  $avatar_images_url =  config_item('subscription_images_url');
}else if($imageDir == 'vImage_url'){
  $avatar_images_url =  config_item('vImage_url');
}else if($imageDir == 'banner_url'){
  $avatar_images_url =  config_item('banner_url');
}
  if(@getimagesize($avatar_images_url.''.$imagesName)){
     return $imagesName;
  }else{
    $imagesName = 'default.jpeg';
    return $imagesName;
  }
}

function getCompanyVariable(){
        $CI = & get_instance();
        $CI->load->database();
				
	 $sql = "select * from company_profile";
	 $query = $CI->db->query($sql);
	 if($query->num_rows()>0)
	 {
	   $result = $query->result_array();
	   return $result = $result[0];
	 }else{
	    return false; 
	 }
}

function durations($id = ''){
 $CI = & get_instance();
 $CI->load->database();
				
	 $sql = "select * from durations";
	 if(!empty($id)){
	   $sql .= ' where id = '.$id;
	 }
	 $query = $CI->db->query($sql);
	 if($query->num_rows()>0)
	 {
	   $result = $query->result_array();
	   return $result = $result;
	 }else{
	    return false; 
	 }
}

// function to get voucher coupons image
	function voucherImage($cid = '')
	{
		$CI = & get_instance();
 		$CI->load->database();
				
	 	$sql = "select * from voucher";
	 	if(!empty($cid))
	 	{
	   	$sql .= ' where catId = '.$cid;
	 	}
	 	$query = $CI->db->query($sql);
	 	if($query->num_rows()>0)
	 	{
	   	$result = $query->result_array();
	   	return $result = $result;
	 	}else{
	    	return false; 
	 		}
	}

// function to get voucher coupons image
	function services($sid = '')
	{
		$CI = & get_instance();
 		$CI->load->database();
				
	 	$sql = "select * from services";
	 	if(!empty($sid))
	 	{
	   	$sql .= ' where sid = '.$sid;
	 	}
	 	$query = $CI->db->query($sql);
	 	if($query->num_rows()>0)
	 	{
	   	$result = $query->result_array();
	   	return $result = $result;
	 	}else{
	    	return false; 
	 		}
	}

// function to get voucher coupons image
	function getUserName($id = '')
	{
		$CI = & get_instance();
 		$CI->load->database();
				
	 	$sql = "select * from user";
	 	if(!empty($id))
	 	{
	   	$sql .= ' where id = '.$id;
	 	}
	 	$query = $CI->db->query($sql);
	 	if($query->num_rows()>0)
	 	{
	   	$result = $query->result_array();
	   	return $result = $result;
	 	}else{
	    	return false; 
	 		}
	}
//varsha

function selectCountup(){
        $CI = & get_instance();
        $CI->load->database();
        $USER =  config_item('USER');
$time =  time();
        $sql = "SELECT * FROM $USER WHERE createTime>(SELECT updateTime FROM $USER WHERE superAdmin='admin') AND superAdmin!='admin'";
		
		$query =$CI->db->query($sql);
        if($query->num_rows()>0)
        {
            return $query->num_rows();
        }else{
            return 0;
        }
    }
	
	function selectCountpartners(){
        $CI = & get_instance();
        $CI->load->database();
        $USER =  config_item('USER');
$time =  time();
        $sql = "SELECT * FROM $USER WHERE createTime>(SELECT updateTime FROM $USER WHERE superAdmin='admin') AND superAdmin!='admin' AND superAdmin='partners'";
		
		$query =$CI->db->query($sql);
        if($query->num_rows()>0)
        {
            return $query->num_rows();
        }else{
            return 0;
        }
    }
	
	
	
	
//count comment	
	
function selectCountcomment(){
        $CI = & get_instance();
        $CI->load->database();
       // $USER =  config_item('USER');
//$time =  time();
        $sql = "SELECT * FROM comment";		
		$query =$CI->db->query($sql);
        if($query->num_rows()>0)
        {
            return $query->num_rows();
        }else{
            return 0;
        }
    }	
	
	
	
//count users	
	
function selectCountuser(){
        $CI = & get_instance();
        $CI->load->database();
       // $USER =  config_item('USER');
//$time =  time();
        $sql = "SELECT * FROM fis_users where user_type='user' ";		
		$query =$CI->db->query($sql);
        if($query->num_rows()>0)
        {
            return $query->num_rows();
        }else{
            return 0;
        }
    }	
	
	
	
	//count blog	
	
function selectCountblog(){
        $CI = & get_instance();
        $CI->load->database();
       // $USER =  config_item('USER');
//$time =  time();
        $sql = "SELECT * FROM fis_blog";		
		$query =$CI->db->query($sql);
        if($query->num_rows()>0)
        {
            return $query->num_rows();
        }else{
            return 0;
        }
    }	
	
	
	
//count open query		
function Count_openquery(){
        $CI = & get_instance();
        $CI->load->database();
      
        $sql = "SELECT * FROM fis_query where status='0'";		
		$query =$CI->db->query($sql);
        if($query->num_rows()>0)
        {
            return $query->num_rows();
        }else{
            return 0;
        }
    }			
	
		
//count close query		
function Count_closequery(){
        $CI = & get_instance();
        $CI->load->database();
       // $USER =  config_item('USER');
//$time =  time();
        $sql = "SELECT * FROM fis_query where status='1' ";		
		$query =$CI->db->query($sql);
        if($query->num_rows()>0)
        {
            return $query->num_rows();
        }else{
            return 0;
        }
    }			
	
	
	
	
	
	
//count category	
	
function selectCountcategory(){
        $CI = & get_instance();
        $CI->load->database();
       // $USER =  config_item('USER');
//$time =  time();
        $sql = "SELECT * FROM fis_blog";		
		$query =$CI->db->query($sql);
        if($query->num_rows()>0)
        {
            return $query->num_rows();
        }else{
            return 0;
        }
    }		
	
	
	
	
	function selectCountusers(){
        $CI = & get_instance();
        $CI->load->database();
        $USER =  config_item('USER');
$time =  time();
        $sql = "SELECT * FROM $USER WHERE createTime>(SELECT updateTime FROM $USER WHERE superAdmin='admin') AND superAdmin!='admin' AND superAdmin='users'";
		
		$query =$CI->db->query($sql);
        if($query->num_rows()>0)
        {
            return $query->num_rows();
        }else{
            return 0;
        }
    }
	
	
	
	
	function errorMsg(){
           $manage['error'][] = Array(
    'message' => 'invalid request token',
 'Timestamp' => date('l jS \of F Y h:i:s A'));
     
 $manage = json_encode($manage); 
 print_r($manage); 
     die;
}

function loggenrate($data)
	{
	$CI = & get_instance();
    $CI->load->database();
	$LOGMANAGER =  config_item('LOGMANAGER');
		
	$time =  time();
		$ipaddres = $_SERVER['REMOTE_ADDR'];
	$sessionId = $CI->session->userdata('id');
	
		$action = $data['action']; 
		$id = $data['id'];
		 if(!empty($action) && !empty($id)){
		    $sql = "insert into logManager($action,ipAddress,createTime,sessionId)values('$id','$ipaddres','$time','$sessionId')";
			$query = $CI->db->query($sql);
		 }
	}

?>