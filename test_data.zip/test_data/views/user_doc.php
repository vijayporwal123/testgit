<?php $this->load->view('user_header');?>

<div class="tp-page-header"><!-- full page header -->
  <div class="container">
    <div class="row">
      <div class="col-md-7">
        <div class=""><!-- page header  -->
        <br>
          <h2>User Document</h2>
          <p class="lead"></p>
        </div>
        <!-- page header  --> 
      </div>
     <!-- <div class="col-md-5 header-pic"><!-- page header pic --> 
       <!-- <img src="images/page-head-agent.jpg" alt="" class="img-responsive"> </div>-->
      <!-- page header pic --> 
    </div>
  </div>
</div>
<!-- /.full page header-->
<div class="tp-breadcrumb">
  <div class="container">
    <div class="row">
      <div class="col-md-8">
        <ol class="breadcrumb">
          <li><a href="<?php echo base_url(); ?>login/userinbox">Home</a></li>
          <!--<li><a href="#">Agent search</a></li>
          <li class="active">Agent Listing</li>-->
        </ol>
      </div>
      <!--<div class="col-md-4">
        <div class="font-option"> Select font size : <a href="#" id="incfont">A+</a><a href="#" id="decfont">A-</a></div>
      </div>-->
    </div>
  </div>
</div>

<div class="main-container" id="main-container"><!--Main container start-->
  <div class="tp-agent-result" id="tp-agent-result"><!-- agent result section -->
    <div class="container">
      <div class="row">
      
      
<?php 
if(!empty($user_data)){
$i= 1;
foreach($user_data as $key =>$val){
?>   

<div class="col-md-3 agent-thumb"><!-- agent-thumb -->
<div class="agent-pic"><!-- agent pic --> 
<!--<a href="#"><img src="images/agent.jpg" class="" alt=""></a>    -->        
<?php  
$file_name=$val['file_name'];
$tmp = explode('.', $file_name);
$file_extension = end($tmp); 
  
if($file_extension=="gif" || $file_extension=="jpeg" || $file_extension=="png" || $file_extension=="jpg"){
?>                  
<a href="<?php echo base_url(); ?>login/user_download/<?php echo $val['id']; ?>"><img src="<?php echo base_url();?>files/<?php echo $val['file_name']; ?>" class="" alt="">
<i class="fa fa-download" aria-hidden="true"></i></a>           
<?php
}else if($file_extension=="doc" || $file_extension=="docx"){
?>
<a href="<?php echo base_url(); ?>login/user_download/<?php echo $val['id']; ?>"><img src="<?php echo base_url();?>files/word_icon.png" class="" alt="">
<i class="fa fa-download" aria-hidden="true"></i></a>                      
<?php
}else if($file_extension=="pdf"){
?>  
<a href="<?php echo base_url(); ?>login/user_download/<?php echo $val['id']; ?>"><img src="<?php echo base_url();?>files/pdf-icon.png" class="" alt="">
<i class="fa fa-download" aria-hidden="true"></i></a>                    
<?php
}else{?>          
<a href="#"><img src="<?php echo base_url();?>files/imageNotFound.jpg" class="" alt=""></a>                     
<?php
}
?>                                                       
</div>
<!-- /.agent pic -->
<div class="agent-info"><!-- agent-info -->
<h2><a href="#"><?php echo substr($val['title'],0,60); ?></a></h2>
<!--<ul>
<li>6422 Grovedale Dr Suite,</li>
<li>North side 102B Alexandria,</li>
<li>VA 22310</li>
</ul>-->
<!--<p class="call"><i class="fa fa-phone-square"></i> +1 907-123-5678</p>
<a href="#" class="btn tp-btn tp-btn-orange">View Details</a>--> </div>
<!-- /.agent-info --> 
</div>
<!-- /.agent-thumb -->
<?php
}
}else{
?>
<div>No File Found</div>
<?php
}
?>       
                
</div><!--row end-->      
</div>
</div>
<!-- agent result section --> 
</div>
<!-- /.Main container start--> 
<!-- /.Main container start-->
<?php /*?><div class="tp-newsletter"><!-- Newsletter -->
  <div class="container">
    <div class="row">
      <div class="col-md-5 news-title"><!-- section title -->
        <h2><i class="fa fa-envelope-o"></i> Register to Peace Newsletter</h2>
      </div>
      <div class="col-md-7 newsletter"><!-- Newsletter form -->
        <div class="input-group">
          <input type="text" class="form-control" placeholder="E-mail Address">
          <span class="input-group-btn">
          <button class="btn tp-btn-orange" type="button">Submit</button>
          </span> </div>
        <!-- /input-group --> 
        
      </div>
      <!-- Newsletter form --> 
    </div>
  </div>
</div><?php */?>
<!-- Newsletter -->
<?php  $this->load->view('user_footer');?>
