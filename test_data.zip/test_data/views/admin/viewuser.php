<?php
$this->load->view('admin/header');
?>
<?php
$this->load->view('admin/session_check');
?>
<?php
if(!empty($userdetails)){
//echo"<pre>";
//print_r($blogdata);

    $id = $userdetails[0]['id'];
    $username = $userdetails[0]['username'];
    $email = $userdetails[0]['email'];
    $mobile_no = $userdetails[0]['mobile_no'];
    $company_name = $userdetails[0]['company_name'];
    $designation = $userdetails[0]['designation'];
    $address = $userdetails[0]['address'];
   $user_verify_status = $userdetails[0]['user_verify_status'];
    $user_file = $userdetails[0]['user_file'];  
    $regdate = $userdetails[0]['date']; 
   //$code=$userdetails[0]['email_confirm_code ']; 
}
?>


<body>

<div id="wrapper">

<!-- Navigation -->
<?php 
$this->load->view('admin/navigation');
?> 
<style>
.error{color:#FF0000;
}
</style>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h3 class="page-header">View User Details</h3>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                           View Form
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-10">
                                
                                
<form role="form"  method="post" action="<?php echo base_url(); ?>admin/user/resend_email/<?php echo $id; ?>" enctype="multipart/form-data" >
                                        
<!--<input type="hidden" name="uid" value="<?php //echo $id; ?>">                                               
-->                                           
<!-- <fieldset class="form-group col-sm-4"><label></label>
<?php
        //if(!empty($photo)){
		?>
        <img src="gurukul-school/<?php //echo $photo;?>"  style="height:100px; width:100px;"/>
        <?php
		//}else{
		?>
	<img src="photo/profile_pic.png"  style="height:100px; width:100px;"/>
    <?php
		//}
		?> 
</fieldset>-->

<fieldset class="form-group col-sm-3"><label for="name">Username:&nbsp;</label>
  <?php echo    $username ;?></fieldset>

<fieldset class="full form-group col-sm-3"> <label for="Designation">Designation:</label>
<?php echo $designation;?>
  </fieldset>

<fieldset class="full form-group col-sm-3"><label for="Mobile">Mobile No.</label>
  <?php echo $mobile_no;?>
    </fieldset>
    
<fieldset class="full form-group col-sm-3"><label for="Company">Company Name:</label>
      <?php echo $company_name;?>
  </fieldset>
  
 <fieldset class="full form-group col-sm-3"><label for="Email">Email:</label>
   <?php echo $email;?>
   
   
    </fieldset>
 


   <fieldset class="full form-group col-sm-3"> <label for="contact">Reg Date:</label>
      <?php echo $regdate; ?>
  </fieldset>
  
  
  <fieldset class="full form-group col-sm-3"> <label for="contact">Address:</label>
      <?php echo $address; ?>
  </fieldset>
    
  
  
   <fieldset class="full form-group col-sm-3"> <label for="contact">Verified?:</label>
      <?php if($user_verify_status=='1'){ 
                                    ?>
                                    <span class="label label-sm label-success">Email verified</span>
                                    <?php
                                    }else{
                                    ?>
                                    <span class="label label-sm label-danger">Not Email Verified</span>
                                    <?php
                                    }
                                    ?>
</fieldset>
<br><br>
<fieldset class="full form-group col-sm-3" style="float:right"> </fieldset>
<fieldset class="full form-group col-sm-3" > </fieldset>

<fieldset class="full form-group col-sm-3" style="float:right"> 
<button type="submit"  name="submit" class="btn btn-primary btn-sm">Resend Verification Mail</button>
 
 </fieldset> 
</form>
                                    
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                                <!-- /.col-lg-6 (nested) -->
                                
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

<!--<link rel="stylesheet" type="text/css" href="<?php //echo base_url(); ?>assets/lib/css/bootstrap.min.css" />
--><link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/src/bootstrap-wysihtml5.css" />
    <script src="<?php echo base_url(); ?>assets/lib/js/wysihtml5-0.3.0.js"></script>
    <script src="<?php echo base_url(); ?>assets/lib/js/jquery-1.7.2.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/lib/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/src/bootstrap3-wysihtml5.js"></script>

<script>
    $('.textarea').wysihtml5();
</script>

   <style type="text/css" media="screen">
        .btn.jumbo {
            font-size: 20px;
            font-weight: normal;
            padding: 14px 24px;
            margin-right: 10px;
            -webkit-border-radius: 6px;
            -moz-border-radius: 6px;
            border-radius: 6px;
        }
    </style>


    <!-- jQuery -->
    
<!--    <script src="<?php echo base_url(); ?>assets/bower_components/jquery/dist/jquery.min.js"></script>
-->
    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo base_url(); ?>assets/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="<?php echo base_url(); ?>assets/bower_components/metisMenu/dist/metisMenu.min.js"></script>
   
    <!-- Custom Theme JavaScript -->
    <script src="<?php echo base_url(); ?>assets/dist/js/sb-admin-2.js"></script>

<script>
 var _validFileExtensions1 = [".doc", ".docx", ".pdf"];    
function ValidateSingleInput1(oInput) {
    if (oInput.type == "file") {
        var sFileName = oInput.value;
         if (sFileName.length > 0) {
            var blnValid = false;
            for (var j = 0; j < _validFileExtensions1.length; j++) {
                var sCurExtension = _validFileExtensions1[j];
                if (sFileName.substr(sFileName.length - sCurExtension.length, sCurExtension.length).toLowerCase() == sCurExtension.toLowerCase()) {
                    blnValid = true;
                    break;
                }
            }
             
            if (!blnValid) {
                alert("Sorry, " + sFileName + " is invalid file extension, allowed file type extensions are only: " + _validFileExtensions1.join(", "));
                oInput.value = "";
                return false;
            }
        }
    }
    return true;
}
 
 </script>

</body>
</html>