<?php
$this->load->view('admin/header');
?>
<?php
$this->load->view('admin/session_check');
?>
<?php
$userDetails = getUserDetails($this->session->userdata('id'));
if(!empty($userDetails)){
	$userDetails = $userDetails[0];
	$user_id = $userDetails['id'];
	$user_name =$userDetails['username'];
	$user_type =$userDetails['user_type'];
}
?>
<body>
<div id="wrapper">
<!-- Navigation -->
<?php 
$this->load->view('admin/navigation');
?> 
<style>
.error{color:#FF0000;
}
</style>

<div id="page-wrapper">
<div class="row">
<div class="col-lg-12">
<h3 class="page-header">Upload User Data</h3>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                           Upload User Data
                        </div>
                        <div class="panel-body">
                            <div class="row">
                          <div class="col-lg-6">
                                
<form role="form"  method="post" action="<?php echo base_url(); ?>admin/user/upload_userdata" enctype="multipart/form-data" >

<?php if($this->session->flashdata('message')){?>
<div class="alert alert-success">  
<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>    
<?php echo $this->session->flashdata('message')?>
</div>
<?php } ?>

<input type="hidden" name="uid" value="<?php echo  $this->uri->segment(4) ? $this->uri->segment(4) : 0; ?>" >

        <p><span class="error">* required field.</span></p>  
                                   
        <div class="form-group">
        <label>File Title <span class="error">* </span></label>
        <input class="form-control"  name="title_name[]" placeholder="Enter File Title*"  type="text"  required>
        </div>                                        
                                        
                                        
        <div class="form-group">
        <label>Upload Multiple Attachment File<span class="error">* </span></label>
        <p><span class="error">You can upload maximum 6 files at a time only.</span></p>  

        <div class="field_wrapper">
        <div>
        
        <p>
        <input type="file" name="userfile[]" id="img" class="form-control" style="margin:5px;" required onChange="return ValidateSingleInput(this),validateImage1();"/>
        <span style="float:right;"><a href="javascript:void(0);" class="add_button" title="attach more file"><img src="<?php echo base_url(); ?>assets/images/add-icon.png"/></a></span></p><br>
        </div>
        </div>   
        </div>                                    

<button type="submit"  name="fileSubmit" class="btn btn-primary btn-sm">Submit</button>
<a  href="<?php echo base_url(); ?>admin/user/manageuser"><button type="button" class="btn btn-danger btn-sm">Cancel</button></a> 
</form>                  
</div>
</div>
<!-- /.row (nested) -->            
<br><br>    

<div class="row">
<div class="col-lg-12">
<h3 class="page-header"> User Documents</h3>
</div>
<?php 
if(!empty($user_data)){
$i= 1;
foreach($user_data as $key =>$val){
?>
   
<div class="col-lg-3 col-md-4 col-xs-6 thumb">
<?php  
$file_name=$val['file_name'];
$tmp = explode('.', $file_name);
$file_extension = end($tmp); 
  
if($file_extension=="gif" || $file_extension=="jpeg" || $file_extension=="png" || $file_extension=="jpg"){
?> 

<?php
if($user_type=='admin'){?>
<a  href="<?php echo base_url(); ?>admin/user/deletefiles/<?php echo $val['id']; ?>" title="delete file " onClick="return confirm('Are you sure you want to delete this file?');">
<i class="fa fa-times" aria-hidden="true" ></i></a> 
<?php
}else{
}?>
 
<a class="thumbnail" href="<?php echo base_url(); ?>admin/user/user_download/<?php echo $val['id']; ?>">
<img class="img-responsive" src="<?php echo base_url();?>files/<?php echo $val['file_name']; ?>" alt="">

<i class="fa fa-download" aria-hidden="true"></i>
<div class='text-right'>
<small class='text-muted'><?php echo substr($val['title'],0,60); ?></small>
</div>
</a>

<?php
}else if($file_extension=="doc" || $file_extension=="docx"){
?>

<?php
if($user_type=='admin'){?>
<a  href="<?php echo base_url(); ?>admin/user/deletefiles/<?php echo $val['id']; ?>" title="delete file " onClick="return confirm('Are you sure you want to delete this file?');">
<i class="fa fa-times" aria-hidden="true" ></i></a> 
<?php
}else{
}?>
<a class="thumbnail" href="<?php echo base_url(); ?>admin/user/user_download/<?php echo $val['id']; ?>">
<img class="img-responsive" src="<?php echo base_url();?>files/word_icon.png" alt="" >
<i class="fa fa-download" aria-hidden="true"></i><div class='text-right'>
<small class='text-muted'><?php echo substr($val['title'],0,60); ?></small>
</div></a>
<?php
}else if($file_extension=="pdf"){
?>
<?php
if($user_type=='admin'){?>
<a  href="<?php echo base_url(); ?>admin/user/deletefiles/<?php echo $val['id']; ?>" title="delete file " onClick="return confirm('Are you sure you want to delete this file?');">
<i class="fa fa-times" aria-hidden="true" ></i></a>
<?php
}else{
}?>

<a class="thumbnail" href="<?php echo base_url(); ?>admin/user/user_download/<?php echo $val['id']; ?>">
<img class="img-responsive" src="<?php echo base_url();?>files/pdf-icon.png" alt="" >
<i class="fa fa-download" aria-hidden="true"></i><div class='text-right'>
<small class='text-muted'><?php echo substr($val['title'],0,60); ?></small>
</div></a>
<?php
}else{?>
<!--<a  href="<?php echo base_url(); ?>admin/user/deletefiles/<?php echo $val['id']; ?>" title="delete file " onClick="return confirm('Are you sure you want to delete this file?');">
<i class="fa fa-times" aria-hidden="true" ></i></a>--> 
<a class="thumbnail" href="#">
<img class="img-responsive" src="<?php echo base_url();?>files/imageNotFound.jpg" alt="" >
</a>
<?php
}
?> 
</div>
<?php
}
}else{
?>
<div>No File Found</div>
<?php
}
?>        
          
            
            
</div>

   
 <!-- row / end -->
          
                            
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->
     

                     
<!--<link rel="stylesheet" type="text/css" href="<?php //echo base_url(); ?>assets/lib/css/bootstrap.min.css" />
--><link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/src/bootstrap-wysihtml5.css" />
    <script src="<?php echo base_url(); ?>assets/lib/js/wysihtml5-0.3.0.js"></script>
    <script src="<?php echo base_url(); ?>assets/lib/js/jquery-1.7.2.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/lib/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/src/bootstrap3-wysihtml5.js"></script>

<script>
    $('.textarea').wysihtml5();
</script>

   <style type="text/css" media="screen">
        .btn.jumbo {
            font-size: 20px;
            font-weight: normal;
            padding: 14px 24px;
            margin-right: 10px;
            -webkit-border-radius: 6px;
            -moz-border-radius: 6px;
            border-radius: 6px;
        }
    </style>



<!-- gallery css  -->

<!--<script src="<?php echo base_url(); ?>assets/bower_components/jquery/dist/jquery.min.js"></script>
-->
    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo base_url(); ?>assets/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="<?php echo base_url(); ?>assets/bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="<?php echo base_url(); ?>assets/dist/js/sb-admin-2.js"></script>




<script type="text/javascript">
function validateImage1(){
    var formData = new FormData();
    var file = document.getElementById("img").files[0];
    formData.append("Filedata", file);
    if (file.size > 2048000) {
        alert('Max Upload size is 2MB only');
        document.getElementById("img").value = '';
        return false;
    }
    return true;
}
</script>



<script type="text/javascript">
function validateImage(id){
    var formData = new FormData();
    var file = document.getElementById(id).files[0];
    formData.append("Filedata", file);
   
    if (file.size > 2048000) {
        alert('Max Upload size is 2MB only');
        document.getElementById(id).value = '';
        return false;
    }
    return true;
}
</script>


<script>
 var _validFileExtensions = [".jpg", ".jpeg", ".png",".JPEG",".doc",".docx",".pdf"];    
function ValidateSingleInput(oInput) {
    if (oInput.type == "file") {
        var sFileName = oInput.value;
		

		
         if (sFileName.length > 0) {
            var blnValid = false;
            for (var j = 0; j < _validFileExtensions.length; j++) {
                var sCurExtension = _validFileExtensions[j];
                if (sFileName.substr(sFileName.length - sCurExtension.length, sCurExtension.length).toLowerCase() == sCurExtension.toLowerCase()) {
                    blnValid = true;
                    break;
                }
				
            }
			
			
            if (!blnValid) {
                alert("Sorry, is invalid file extension, allowed file type extensions are only:  " + _validFileExtensions.join(", "));
                oInput.value = "";
                return false;
            }
        }
    }
	
    return true;
}
 
</script>
<!--add multiple field-->
<!--<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
-->
<!--<script src="<?php //echo base_url(); ?>assets/js/jquery.js"></script>-->
<script type="text/javascript">
$(document).ready(function(){
	var maxField = 6; //Input fields increment limitation
	var addButton = $('.add_button'); //Add button selector
	var wrapper = $('.field_wrapper'); //Input field wrapper
	var fieldHTML = '<div><input type="text" name="title_name[]" class="form-control"  placeholder="Enter File Title*" required/><br><input type="file" name="userfile[]"  id="img1"  class="form-control"  style="margin:3px;" required onChange="return ValidateSingleInput(this),validateImage(id);"/><a href="javascript:void(0);" class="remove_button" title="Remove field" style="float:right;"><img src="<?php echo base_url(); ?>assets/images/remove-icon.png"/></a></div>'; //New input field html 
	var x = 1; //Initial field counter is 1
	$(addButton).click(function(){ //Once add button is clicked
		if(x < maxField){ //Check maximum number of input fields
			x++; //Increment field counter
			$(wrapper).append(fieldHTML); // Add field html
		}
	});
$(wrapper).on('click', '.remove_button', function(e){ //Once remove button is clicked
		e.preventDefault();
		$(this).parent('div').remove(); //Remove field html
		x--; //Decrement field counter
	});
});
</script>

<style type="text/css">
input[type="text"]{height:35px; vertical-align:top;}
.field_wrapper div{ margin-bottom:10px;}
.add_button{ margin-top:10px; margin-left:10px;vertical-align: text-bottom;}
.remove_button{ margin-top:10px; margin-left:10px;vertical-align: text-bottom;}
</style>
<!--end code-->

</body>
</html>
