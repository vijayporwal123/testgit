<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Fiscon Consultant PVT LTD ">
<meta name="keywords" content="Fiscon Consultant,Fiscon Consultant PVT LTD">
<link rel="shortcut icon" href="<?php echo base_url(); ?>assets/front_end/images/fiscon_fev.ico" type="image/x-icon">
<title>Fiscon Consultants PVT. LTD. </title>
<link href="<?php echo base_url(); ?>assets/front_end/css/bootstrap.min.css" rel="stylesheet">
<link href='http://fonts.googleapis.com/css?family=Roboto+Slab:400,300,100,700' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic' rel='stylesheet' type='text/css'>
<link href="<?php echo base_url(); ?>assets/front_end/css/style.css" rel="stylesheet">
<link href="<?php echo base_url(); ?>assets/front_end/css/owl.carousel.css" rel="stylesheet">
<link href="<?php echo base_url(); ?>assets/front_end/css/owl.theme.css" rel="stylesheet">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/front_end/css/font-awesome.min.css">
<script src='https://www.google.com/recaptcha/api.js'></script>

<!--<script type = "text/javascript" >
   function preventBack(){window.history.forward();}
    setTimeout("preventBack()", 0);
    window.onunload=function(){null};
</script>-->

</head>
<body>

<gcse:search></gcse:search>
<div class="search-open">
  <div class="container">
    <div class="col-md-offset-2 col-md-8">
      <div class="input-group">
        <input type="text" class="form-control">
        <span class="input-group-btn">
        <button class="btn tp-btn-orange" type="button">Search</button>
        </span> </div>
    </div>
  </div>
</div>

<div class="tp-header" id="tp-header">
  <div class="container">
   <div class="row">
   
      <div class="col-md-4"> <a class="navbar-brand" href="<?php echo base_url(); ?>front/index"><img src="<?php echo base_url(); ?>assets/front_end/images/logo_fiscon.png"    alt="Fiscon Consultants PVT. LTD." class="img-responsive" ></a> </div>
      <div class="col-md-8 cta-box text-right"><span class="call">Call: +91 98260 98751</span> 
      <div class="btn-group" >
  <a href="#" class="btn tp-btn tp-btn-orange dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
    Login <span class="caret"></span>
  </a>
  
  <ul class="dropdown-menu" role="menu">
<li> <a href="<?php echo base_url(); ?>login/index"><i class="fa fa-user"></i>Login</a></li>
<!--<li> <a href="life-land.html"><i class="fa fa-heart"></i> Life Insurance</a></li>
<li> <a href="business-land.html"> <i class="fa fa-envelope"></i>Business Insurance</a></li>
<li> <a href="travel-land.html"> <i class="fa fa-plane"></i>Travel Insurance</a></li>
<li> <a href="home-land.html"> <i class="fa fa-home"></i>Home Insurance</a></li>-->
  </ul>
</div>
      
<!--<a href="<?php echo base_url(); ?>login/index" class="btn tp-btn tp-btn-blue"></a>--> <a href="#" class="btn search tp-search-btn"><i class="fa fa-search"></i></a> </div>
    </div>
    
    
  </div>
</div>

<div class="tp-navbar">
  <nav class="navbar navbar-default">
    <div class="container"> 
    <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
      </div>
      <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
        <ul class="nav navbar-nav">
          <li class=""><a href="<?php echo base_url(); ?>front/index"  role="button" aria-expanded="false">Home</a>
            <ul class="dropdown-menu" role="menu">
                       </ul>
          </li>
          
          <li class=""> <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">About us</a>
            <ul class="dropdown-menu" role="menu">
            </ul>
            
          </li>
          <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Services<i class="fa fa-angle-down"></i></a>
            <ul class="dropdown-menu" role="menu">
              <li><a href="#">Retail Assets Consumer Loan</a></li>
              <li><a href="#">Working Capital Services</a></li>
              <li><a href="#">Project Finance</a></li>
              <li><a href="#">Agricultire Loan</a></li>
              <li><a href="#">Government Subsidies and Schemes</a></li>
              <li><a href="#">Land allotment</a></li>
              <li><a href="#">Others</a></li>
            </ul>
                        
          </li>
          <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Career<i class="fa fa-angle-down"></i></a>
            <ul class="dropdown-menu" role="menu">
              <li><a href="<?php echo base_url(); ?>front/careerform">Application form</a></li>
              <li><a href="">Work Culture</a></li>
            </ul>
          </li>
          
          <li><a href="<?php echo base_url(); ?>front/blog">Blog</a></li>
         <li><a href="<?php echo base_url(); ?>front/contactform">Contact us</a></li>
          <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Share +<i class="fa fa-angle-down"></i></a>
            <ul class="dropdown-menu social-menu" role="menu">
            
              <li><a href="https://www.facebook.com/sharer/sharer.php?u=http://fiscon.in/fiscon2" target="_blank"><i class="fa fa-facebook-square facebook"></i>Facebook</a></li>
              <li><a href="https://plus.google.com/share?url=http://fiscon.in/fiscon2" target="_blank"><i class="fa fa-google-plus-square google"></i>Google +</a></li>
              <li><a href="https://twitter.com/home?status=http://fiscon.in/fiscon2" target="_blank"><i class="fa fa-twitter-square twitter"></i>Twitter </a></li>
              
            </ul>
          </li>
        </ul>
      </div>
      
         </div>
     </nav>
</div>