<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Common extends CI_Model {

/* insert the register form in datebase */
	public function data_insert($table,$data)
	{		
		   $query = $this->db->insert($table, $data); 
		   $id = $this->db->insert_id();
		   return $id;			
	}
  
  
  
  
  
  
  
  public function data_delete($attribute_name, $attribute_value, $table_name){
		$this->db->where($attribute_name, $attribute_value);
		$this->db->delete($table_name);
		return true;
	}
	
  public function data_update($whereArray, $table, $update_array){
		
		if(is_array($whereArray)){
			foreach ($whereArray as $key => $value){
				$this->db->where($key, $value);
			}
		} 
		$this->db->update($table, $update_array);
		return true;
/*		if($this->db->affected_rows())
			return true;
		else
			return false;	 
*/	}

/* select query */
     function select($table, $where ='')
     {
        $sql = "SELECT * FROM $table";
		if(!empty($where)){
		   $sql .= " $where";
		}
		
		$query = $this->db->query($sql);
        if($query->num_rows()>0)
        {
            return $query->result_array();
        }
        else{
            return false;
        }
    }



function login($username, $password)
{
$this -> db -> select('*');
$this -> db -> from('register');
$this -> db -> where('name = ' . "'" . $username . "'");
$this -> db -> where('password = ' . "'" .$password . "'");
$this -> db -> limit(1);

$query = $this -> db -> get();

if($query -> num_rows() == 1)
{
return $query->result();
}
else
{
return false;
}
}













 function login33($data) {

$condition = "email =" . "'" . $data['email'] . "' AND " . "password =" . "'" . $data['password'] . "'";
$this->db->select('*');
$this->db->from('register');
$this->db->where($condition);
//$this->db->limit(1);
$query = $this->db->get();

if ($query->num_rows() == 1) {
return true;
} else {
return false;
}
}

public function read_user_information($email) {

$condition = "email =" . "'" . $email . "'";
$this->db->select('*');
$this->db->from('register');
$this->db->where($condition);
$this->db->limit(1);
$query = $this->db->get();

if ($query->num_rows() == 1) {
return $query->result();
} else {
return false;
}
}












    /* image select query */
    function select_image($table, $where ='')
    {

      $sql = "SELECT avatar FROM $table";
			if(!empty($where))
			{
		   	$sql .= " $where";
			}
		
			$query = $this->db->query($sql);

        if($query->num_rows()>0)
        {
        	
          return $query->result_array();
        }
        else{
            return false;
        }
    }
	
/* select query */
     function selectJson($table, $where ='')
     {
        $sql = "SELECT * FROM $table";
		if(!empty($where)){
		   $sql .= " $where";
		}
		
		$query = $this->db->query($sql);
        if($query->num_rows()>0)
        {
            $models_list = $query->result();
			 $json = json_encode($models_list);
          print_r($json);
          die;
				 
        }
        else{
            return false;
        }
    }
	
/* select count */	
	function selectCount($table, $where)
     {
        $sql = "SELECT * FROM $table";
		if(!empty($where)){
		   $sql .= " $where";
		}
		$query = $this->db->query($sql);
        if($query->num_rows()>0)
        {
            return $query->num_rows();
        }else{
            return false;
        }
    }
	
function login11($email,$password)
{
$this->db->where("email",$email);
$this->db->where("password",md5($password));
$query=$this->db->get("users");
if($query->num_rows()>0)
{
$row=$query->row();
$userdata = array(
'user_id'  => $row->id,
'username'  => $row->username,
'email'    => $row->email,
);

$this->session->set_userdata($userdata);
return true;
}
return false;
}
	
	
	
	
	
	
	
	
	
/* login check */ 
	 function login_check($data,$USER)
     {
	 
	     $user_name = $data['username'];
	     $password = $data['password'];
	     if(!empty($data['user_type']))
	     {
	     	$user_type = $data['user_type'];
	     }
	    
		 $active = 'yes';	
		 
	     $this->db->select('*');
		 
	    
	     if(!empty($user_type))
	     {
	     	$this->db->where('userName',$user_name);
	     	$this->db->where('superAdmin',$user_type);
	     }else{
	     	$this->db->where('userName',$user_name);
	     }
	     $this->db->where('password',$password);
		 $query = $this->db->get($USER);
		if($query->num_rows()>0){
		  return $data =  $query->row();
		}else{
		  return false;
		}
	 } 
	
/* check login user */
	function check_login()
	{
		if($this->session->userdata('id') == FALSE )
		{
			$this->session->sess_destroy();
			$admin_url = $this->config->item('admin_url');
			redirect($admin_url);
			exit();
		}
	}
	

  function result_getall()
  { 
   $this->db->select('*');  
   $this->db->from('user as u');
   $this->db->join('tbl_product as tp', 'u.id = tp.userId', 'INNER');  
   $query = $this->db->get();
   return  $query->result_array();
  }
  
  
  function store_getall()
  { 
   $this->db->select('s.id ,s.store_name,s.store_address,s.latitude,s.longitude,s.status,u.id as uid,u.firstName,u.lastName');  
   $this->db->from('store as s');
   $this->db->join('user as u', 's.PId = u.id', 'LEFT');  
   $query = $this->db->get();
   return  $query->result_array();
  }
  
  
 function result_store($id)
  { 
  $sql = "select *, s.id,s.store_name,s.store_address,s.latitude,s.longitude,s.status, u.firstName,u.lastName from store  as s  left join user  as u  on s.PId=u.id  where s.id = $id";
  $query = $this->db->query($sql);
   if($query->num_rows() > 0)
    {
      return $query->result_array();
	}else{
	    return false;
	}
  }
  
  
  
  
  function result_product_vouchers($id)
  { 
  $sql = "select v.additional_info,v.catId,v.vdiscount,v.stdate,v.exdate,v.vImage,v.disc,tp.* from tbl_product as tp LEFT JOIN voucher as v on tp.id=v.pId where tp.id = $id";
  $query = $this->db->query($sql);
   if($query->num_rows() > 0)
    {
      return $query->result_array();
	}else{
	    return false;
	}
  }

  public function count_rows($table)
  {
  	  $sql = "select * from user where active = 'yes' AND superAdmin = 'partners' ORDER BY createTime DESC";
  	  $query = $this->db->query($sql);
  	  if($query->num_rows() > 0)
  	  {
  	  	return $query->num_rows();
  	  }else{
  	  	 return false;
  	  }
  }

  public function get_partners($limit, $start) 
  {
	 $this->db->limit($limit, $start);
	 $this->db->select('*');
	 $this->db->where('active','yes');
	 $this->db->where('superAdmin','partners');
	 $query = $this->db->get('user');
	 if ($query->num_rows() > 0) {
	     foreach ($query->result() as $row) {
		 $data[] = $row;
	}
	return $data;
	}
	return false;
  }

	public function get_categories($limit, $start)
	{
	 	$this->db->limit($limit, $start);
	 	$this->db->select('*');
	 	$query = $this->db->get('category');
	 	if ($query->num_rows() > 0)
	 	{
	    foreach ($query->result() as $row) 
	    {
			 	$data[] = $row;
			}
			return $data;
		}
		return false;
	}
	
	
}