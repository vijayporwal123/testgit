<?php
$this->session->set_userdata();
if($this->session->userdata('id') && $this->session->userdata('id')!==''){
}
else{
echo redirect('http://localhost/fiscon_admin/login/index');
//echo redirect('http://fiscon.in/fiscon2/');
}

?>