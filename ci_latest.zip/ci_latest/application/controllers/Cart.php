<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cart extends CI_Controller {

 
public function index(){
//$data['results']=$this->productmodel->select('product');
//print_r($data);
$this->load->view('cart');
}


public function add(){
$id=$this->uri->segment(3);
//print_r($_GET);
$this->db->select('*');
$this->db->from('product');
$this->db->where('product_id',$id);
$query=$this->db->get();
 //$res=$query->result();
//print_r($res);
$row = $query->row();

		$data = array(
			   'id'  => 'sku_'.$row->product_id,
			   'pid'=>$row->product_id,
	           'qty'     => 1,
	           'price'   => $row->product_price, 
	           'name'    => $row->name
			   //'image' => $_GET['image']);
	       );
	    $this->cart->insert($data);

//print_r($this->cart->contents());
	  //  $this->session->set_flashdata('success','Product added in your cart');
	    redirect('cart/index');
	}




public function update_cart()
	{
		$row=$_POST['rowid'];
		$qty=$_POST['qty'];
		$i=0;
		foreach($row as $id){
		$data = array(
			'rowid'   => $id,
			'qty'     => $qty[$i]
		);
		$i++;
        $this->cart->update($data); 
		}
		 redirect('cart/index');
		
	}



public function delete_item($rowid,$qty)
	{
		
		$data = array(
			'rowid'   => $rowid,
			'qty'     => $qty
		);
        $this->cart->update($data); 
		 redirect('cart/index');
		
	}


public function destroy()
	{
		$this->cart->destroy();
		 redirect('index/index');
	}







}
