<?php
$this->load->view('admin/header');
?>

<?php
$this->load->view('admin/session_check');
?>
<body>

<div id="wrapper">

<!-- Navigation -->
<?php 
$this->load->view('admin/navigation');
?> 
<style>
.error{color:#FF0000;
}
</style>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
            <?php //include("session_msg.php"); ?>
          <h3 class="page-header">Add Executive</h3>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                           Add Executive
                        </div>
                        
                        <div class="panel-body">
                            <div class="row">
                          <div class="col-lg-6">
                                
<form role="form"  method="post" action="<?php echo base_url(); ?>admin/login/executivesubmit" enctype="multipart/form-data" >
                                        
                                   <p><span class="error">* required field.</span></p>     
                                        <div class="form-group">
                                            <label>User Name <span class="error">* </span></label>
              <input class="form-control"  name="username" placeholder="Enter Username*"  type="text" value="<?php echo set_value('username'); ?>" title="Enter username with space">
              
                                            <?php echo form_error('username'); ?>
                                        </div>                                        
                                        
                                        
                                        <div class="form-group">
                                            <label>Password(UpperCase, LowerCase, Number/SpecialChar and min 8 Chars)<span class="error">* </span></label>
              <input class="form-control"  name="password" placeholder="Enter Password*"  type="password" value="<?php echo set_value('password'); ?>" title="Enter 8 digit password" pattern="(?=^.{8,}$)((?=.*\d)|(?=.*\W+))(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$">
                                            <?php echo form_error('password'); ?>
                                        </div>                                        
                                        
                                        
                                        <div class="form-group">
                                         <label>Upload Photo  [Allowed Only jpg, jpeg, png image]</label>
                                            <input type="file" name="photo" onChange="ValidateSingleInput(this);">
                                        </div>
                                        
                                        
                                        
                                          <div class="form-group">
                                            <label>Mobile Number<span class="error">* </span></label>
              <input class="form-control"  name="mobile_no" placeholder="Enter Mobile No*"  type="text" value="<?php echo set_value('mobile_no'); ?>" title="Enter 10 digit Mobile No.">
                                            <?php echo form_error('mobile_no'); ?>
                                        </div>
                                        
                                        
                                         <div class="form-group">
                                            <label>Email ID.<span class="error">* </span></label>
              <input class="form-control"  name="email" placeholder="Enter Email ID*"  type="text" value="<?php echo set_value('email'); ?>">
                                        <?php echo form_error('email'); ?>
                                        </div>
                                        
                                        
                                        <!--<div class="form-group">
                                            <label>Address</label>
<textarea class="form-control" placeholder="Enter Address ..."  name="address" style="height:100px" ><?php //echo set_value('address'); ?></textarea>
                                            <?php //echo form_error('address'); ?> 
                                              
                                        </div>-->
                                                                                
                                        <!--<div class="form-group">
                                         <label>Upload Data  [Allowed Only Doc, Pdf, Excel File]</label>
                                            <input type="file" name="file_name" onChange="ValidateSingleInput1(this);">
                                        </div>-->
                                        
                                        <button type="submit"  name="submit" class="btn btn-primary btn-sm">Submit</button>
    <a  href="<?php echo base_url(); ?>admin/login/manageexecutive"><button type="button" class="btn btn-danger btn-sm">Cancel</button></a> 
                                        
                                    </form>
                                    
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                                <!-- /.col-lg-6 (nested) -->
                                
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

<!--<link rel="stylesheet" type="text/css" href="<?php //echo base_url(); ?>assets/lib/css/bootstrap.min.css" />
--><link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/src/bootstrap-wysihtml5.css" />
    <script src="<?php echo base_url(); ?>assets/lib/js/wysihtml5-0.3.0.js"></script>
    <script src="<?php echo base_url(); ?>assets/lib/js/jquery-1.7.2.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/lib/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/src/bootstrap3-wysihtml5.js"></script>

<script>
    $('.textarea').wysihtml5();
</script>

   <style type="text/css" media="screen">
        .btn.jumbo {
            font-size: 20px;
            font-weight: normal;
            padding: 14px 24px;
            margin-right: 10px;
            -webkit-border-radius: 6px;
            -moz-border-radius: 6px;
            border-radius: 6px;
        }
    </style>





    <!-- jQuery -->
    
<!--    <script src="<?php echo base_url(); ?>assets/bower_components/jquery/dist/jquery.min.js"></script>
-->
    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo base_url(); ?>assets/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="<?php echo base_url(); ?>assets/bower_components/metisMenu/dist/metisMenu.min.js"></script>

   
    <!-- Custom Theme JavaScript -->
    <script src="<?php echo base_url(); ?>assets/dist/js/sb-admin-2.js"></script>



    <script>
 var _validFileExtensions1 = [".doc", ".docx", ".pdf", ".xlsx"];    
function ValidateSingleInput1(oInput) {
    if (oInput.type == "file") {
        var sFileName = oInput.value;
         if (sFileName.length > 0) {
            var blnValid = false;
            for (var j = 0; j < _validFileExtensions1.length; j++) {
                var sCurExtension = _validFileExtensions1[j];
                if (sFileName.substr(sFileName.length - sCurExtension.length, sCurExtension.length).toLowerCase() == sCurExtension.toLowerCase()) {
                    blnValid = true;
                    break;
                }
            }
             
            if (!blnValid) {
                alert("Sorry, " + sFileName + " is invalid file extension, allowed file type extensions are only: " + _validFileExtensions1.join(", "));
                oInput.value = "";
                return false;
            }
        }
    }
    return true;
}
 
 
 
 </script>




<script>
 var _validFileExtensions = [".jpg", ".jpeg", ".png",".JPEG"];    
function ValidateSingleInput(oInput) {
    if (oInput.type == "file") {
        var sFileName = oInput.value;
         if (sFileName.length > 0) {
            var blnValid = false;
            for (var j = 0; j < _validFileExtensions.length; j++) {
                var sCurExtension = _validFileExtensions[j];
                if (sFileName.substr(sFileName.length - sCurExtension.length, sCurExtension.length).toLowerCase() == sCurExtension.toLowerCase()) {
                    blnValid = true;
                    break;
                }
            }
             
            if (!blnValid) {
                alert("Sorry, " + sFileName + " is invalid file extension, allowed file type extensions are only: " + _validFileExtensions.join(", "));
                oInput.value = "";
                return false;
            }
        }
    }
    return true;
}
 
 
 
 </script>












</body>

</html>
