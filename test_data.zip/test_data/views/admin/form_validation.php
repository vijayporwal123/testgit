<!DOCTYPE html>
<html lang="en">
<head>
 <meta charset="utf-8">
 <title>Form Validation In CodeIgniter</title>
 <style type="text/css">
 .warpper{
  width: 100%;
 }
 .warpper table{
  margin: 50px auto;
  text-align: center;
 }
 h1{
  text-align: center;
 }
 .error{
  color: red;
 }
 </style>
</head>
<body>
 <div class="warpper">
  <h1>Form Validation In CodeIgniter</h1>
  <?php echo form_open('http://localhost/codeig/admin/user/check_validation');?>
   <table border=1 cellpadding=5 cellspaceing=5>
    <tr>
     <td>Name</td>
     <td>
      <?php echo form_input('name',set_value('name'));?>
      <?php echo form_error('name');  ?>
     </td>
    </tr>
    <tr>
     <td>Email Id</td>
     <td>
      <?php echo form_input('email',set_value('email'));?>
      <?php echo form_error('email');  ?>
     </td>
    </tr>
    <tr><td>Password</td>
     <td>
      <?php echo form_password('password',set_value('password'));?>
      <?php echo form_error('password');  ?>
     </td>
    </tr>
    <tr><td>Confrim password</td>
     <td>
      <?php echo form_password('cpassword',set_value('cpassword'));?>
      <?php echo form_error('cpassword');  ?>
     </td>
    </tr>
    <tr><td>website url</td>
     <td>
      <?php echo form_input('website_url',set_value('website_url'));?>
      <?php echo form_error('website_url');  ?>
     </td>
    </tr>
    <tr colspan="2"><td><input type="submit"/></td></tr>
   </table>
  <?php echo  form_close();?>
 </div>
</body>
</html>